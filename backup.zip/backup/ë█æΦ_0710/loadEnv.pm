#!C:\Perl64\bin\perl 

package LoadEnv;

use warnings;
use base Exporter;
our(@EXPORT) = qw(loadEnv);

my $env_file = 'C:\Apache\Apache24\www\html\constant.env';
my $err_file = 'C:\Apache\Apache24\www\html\error.tmpl';
#----------------------------------------------------
#ENVデータのハッシュ化
# 引数：なし
#
# 戻り値：ENVデータ
#   %env：ENVデータのハッシュ
# 備考：
#----------------------------------------------------
sub loadEnv(){
    if(open(IN, "<", "$env_file")){
        my @list = <IN>;
        close(IN);
         
        my %env;
        foreach my $line(@list){
            chomp $line;
            if($line){
                my ($key, $value) = split(/\s+/, $line);
                $env{$key} = $value;
            }
        }     
        return %env;
    }else{
        my $template_err = HTML::Template->new(filename => "$err_file");
        $template_err->param(ERROR => "Can't open this file.");
        print $template_err->output;
        exit;
    }
}

1;