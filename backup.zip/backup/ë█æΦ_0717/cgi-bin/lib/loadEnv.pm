
package loadEnv;

#use strict;
use warnings;
use Log::Log4perl;
use base Exporter;
our(@EXPORT) = qw(loadEnv);

our $env_file = 'C:\Apache\Apache24\www\html\cgi-bin\env\constant.env';
our $err_file = 'C:\Apache\Apache24\www\html\cgi-bin\tmplt\error.tmpl';
our $log_conf = 'C:\Apache\Apache24\www\html\cgi-bin\logs\log4perl.conf';

# log設定ファイルの読み込み
Log::Log4perl::init($log_conf); 

# log設定ファイルに定義したloggerを生成
my $logger = Log::Log4perl::get_logger("mylogger");
my $logMsg = "";

my $template_err;
eval{ $template_err = HTML::Template->new(filename => "$err_file"); };
if($@){
    $logMsg = sprintf('%s at line %s.', $@, __LINE__);
	$logger->debug("$logMsg");
}



#----------------------------------------------------
#ENVデータのハッシュ化
# 引数：なし
#
# 戻り値：ENVデータ
#   %env：ENVデータのハッシュ
# 備考：
#----------------------------------------------------
sub loadEnv(){
    if(open(IN, "<", "$env_file")){
        my @list = <IN>;
        close(IN);
         
        my %env;
        foreach my $line(@list){
            chomp $line;
            if($line){
                if($line !~ /^\S+\s+.*$/){
                    $logMsg = sprintf("Format does not match. at line %s.", __LINE__);
                    $logger->debug("$logMsg");
                    
                    $template_err->param(ERROR => "The data format of the env-file is wrong.");
                    print $template_err->output;
                    exit;   
                }
                my ($key, $value) = split(/\s+/, $line);
                $env{$key} = $value;
            }
        }     
        return %env;
    }else{
        $logMsg = sprintf("Can't open env file at line %s.", __LINE__);      
        $logger->debug("$logMsg");
        
        $template_err->param(ERROR => "Can't open env file.");
        print $template_err->output;
        exit;
    }
}

1;