#!C:\Perl64\bin\perl 

use warnings;

#----------------------------------------------------
#ENV�f�[�^�̃n�b�V����
# �����F�Ȃ�
#
# �߂�l�FENV�f�[�^
#   %env�FENV�f�[�^�̃n�b�V��
# ���l�F
#----------------------------------------------------
sub loadEnv(){
    if(open(IN, "<", 'C:\Apache\Apache24\www\html\constant.env')){
        my @list = <IN>;
        close(IN);
         
        my %env;
        foreach my $line(@list){
            chomp $line;
            if($line){
                my ($key, $value) = split(/\s+/, $line);
                $env{$key} = $value;
            }
        }     
        return %env;
    }else{
        my $template_err = HTML::Template->new(filename => 'C:\Apache\Apache24\www\html\error.tmpl');
        $template_err->param(ERROR => "Can't open this file.");
        print $template_err->output;
        exit;
    }
}

1;