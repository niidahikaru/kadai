#!C:\Perl64\bin\perl 

package loadEnv;

use warnings;
use output_log;
use base Exporter;
our(@EXPORT) = qw(loadEnv);

my $env_file = 'C:\Apache\Apache24\www\html\cgi-bin\env\constant.env';
my $err_file = 'C:\Apache\Apache24\www\html\cgi-bin\tmplt\error.tmpl';

my $template_err;
eval{ $template_err = HTML::Template->new(filename => "$err_file"); };
if($@){
    my $err_msg = $@;
    output_log($err_msg, __FILE__, __LINE__);
}

#----------------------------------------------------
#ENVデータのハッシュ化
# 引数：なし
#
# 戻り値：ENVデータ
#   %env：ENVデータのハッシュ
# 備考：
#----------------------------------------------------
sub loadEnv(){
    if(open(IN, "<", "$env_file")){
        my @list = <IN>;
        close(IN);
         
        my %env;
        foreach my $line(@list){
            chomp $line;
            if($line){
                if($line !~ /^\S+\s+.*$/){
                    my $err_msg = "Format does not match.";
                    output_log($err_msg, __FILE__, __LINE__);
                    
                    $template_err->param(ERROR => "The data format of the env-file is wrong.");
                    print $template_err->output;
                    exit;   
                }
                my ($key, $value) = split(/\s+/, $line);
                $env{$key} = $value;
            }
        }     
        return %env;
    }else{
        my $err_msg = "Can't open env file.";      
        output_log($err_msg, __FILE__, __LINE__);
        
        $template_err->param(ERROR => "Can't open env file.");
        print $template_err->output;
        exit;
    }
}

1;