#!C:\Perl64\bin\perl 

use warnings;
package formCheck;
use base Exporter;
our(@EXPORT) = qw(formCheck);

#----------------------------------------------------
#入力フォームのエラーチェック
# 引数：$q：cgiオブジェクト
#
# 戻り値：%form：エラーチェック結果
# 備考：
#--------------------------------------------------
sub formCheck($){
    my $q = $_[0];
    
    #名前・メアド・性別・年齢・好きな食べ物・メッセージのフォーム値取得
    my $name = $q->param('name');
    my $email = $q->param('email');
    my $sex = $q->param('sex');
    my $old = $q->param('old');
    my @ary = $q->multi_param('ary');
    my $msg = $q->param('msg');
    
    my %form;
    
    if(!$name){
        $form{'frmerr_name'} = '1';
    }
    if(!$sex){
        $form{'frmerr_sex'} = '1';
    }
    if(!$old){
        $form{'frmerr_old'} = '1';
    }
    
    my $checked=0;
    foreach $foods(@ary){    
        if($foods eq "ラーメン"){
            $checked = 1;
        }elsif($foods eq "カレー"){
            $checked = 1;
        }elsif($foods eq "焼肉"){
            $checked = 1;
        }elsif($foods eq "牛丼"){
            $checked = 1;
        }      
    }
    if($checked != 1){
        $form{'frmerr_food'} = '1';
    }
    
    if(defined $email && $email =~ /^([a-z0-9\-_]+)(\.[a-z0-9]+)*@([a-z0-9]+)\.?[a-z]+$/i ||
       defined $email && $email =~ /^([a-z0-9\-_]+)(\.[a-z0-9]+)*@([a-z0-9]+)(\.[a-z0-9]+)\.?[a-z]+$/i){
    }else{
        $form{'frmerr_email'} = '1';
    }
    
    return %form;    
}

1;