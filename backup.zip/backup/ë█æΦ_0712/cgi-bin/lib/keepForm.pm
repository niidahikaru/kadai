#!C:\Perl64\bin\perl 

use warnings;
package keepForm;
use base Exporter;
our(@EXPORT) = qw(keepForm);
#----------------------------------------------------
#フォーム状態維持
# 引数：$q：cgiオブジェクト
#       $template：htmlテンプレート(入力画面)
#
# 戻り値：なし
# 備考：
#--------------------------------------------------
sub keepForm($$){
    my ($q, $template) = @_;
	
    #名前・メアド・性別・年齢・好きな食べ物・メッセージのフォーム値取得
    my $name = $q->param('name');
    my $email = $q->param('email');
    my $sex = $q->param('sex') || 'default value';
    my $old = $q->param('old') || 'default value';
    my @ary = $q->multi_param('ary');
    my $msg = $q->param('frmMsg');
	
	#テンプレートに名前・メアド・メッセージのフォーム値設定
	$template->param(NAME => $name);
	$template->param(EMAIL => $email);		
	$template->param(MSG => $msg);
	
	#テンプレートに性別のフォーム値設定
	if($sex eq "男"){
		$template->param(MAN => "checked");
	}elsif($sex eq "女"){
		$template->param(WOMAN => "checked");
	}
	
	#テンプレートに年齢のフォーム値設定
	my ($ck1, $ck2, $ck3, $ck4, $ck5, $ck6, $ck7, $ck8, $ck9, $ck10) = (0,0,0,0,0,0,0,0,0,0); 
	if($old eq "0~9歳"){
		$ck1 = "selected";
	}elsif($old eq "10~19歳"){
		$ck2 = "selected";
	}elsif($old eq "20~29歳"){
		$ck3 = "selected";
	}elsif($old eq "30~39歳"){
		$ck4 = "selected";
	}elsif($old eq "40~49歳"){
		$ck5 = "selected";
	}elsif($old eq "50~59歳"){
		$ck6 = "selected";
	}elsif($old eq "60~69歳"){
		$ck7 = "selected";
	}elsif($old eq "70~79歳"){
		$ck8 = "selected";
	}elsif($old eq "80~89歳"){
		$ck9 = "selected";
	}else{
		$ck10 = "selected";
	}
	my $oldlist = [
	                {VALUE => '0~9歳', CHECK => "$ck1", TEXT =>'0歳以上9歳未満'},
	                {VALUE => '10~19歳', CHECK => "$ck2", TEXT =>'10歳以上19歳未満'},
	                {VALUE => '20~29歳', CHECK => "$ck3", TEXT =>'20歳以上29歳未満'},
	                {VALUE => '30~39歳', CHECK => "$ck4", TEXT =>'30歳以上39歳未満'},
	                {VALUE => '40~49歳', CHECK => "$ck5", TEXT =>'40歳以上49歳未満'},
	                {VALUE => '50~59歳', CHECK => "$ck6", TEXT =>'50歳以上59歳未満'},
	                {VALUE => '60~69歳', CHECK => "$ck7", TEXT =>'60歳以上69歳未満'},
	                {VALUE => '70~79歳', CHECK => "$ck8", TEXT =>'70歳以上79歳未満'},
	                {VALUE => '80~89歳', CHECK => "$ck9", TEXT =>'80歳以上89歳未満'},
	                {VALUE => '90~99歳', CHECK => "$ck10", TEXT =>'90歳以上99歳未満'}
	              ];	             
	$template->param(SELECT_OLD => $oldlist);

	#テンプレートに好きな食べ物のフォーム値設定
	foreach $foods(@ary){
		if($foods eq "ラーメン"){
			$template->param(NOODLE => "checked");
		}elsif($foods eq "カレー"){
			$template->param(CURRY => "checked");
		}elsif($foods eq "焼肉"){
			$template->param(MEAT => "checked");
		}elsif($foods eq "牛丼"){
			$template->param(GYUDON => "checked");
		}  
	}

}

1;