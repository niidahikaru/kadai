var msg = {};

msg.AMKM_I001 = "AMKM-I001";
msg.AMKM_I002 = "AMKM-I002";
msg.AUHK_I400 = "AUHK-I400";
msg.BWEO_W001 = "BWEO-W001";
msg.FLAD_I400 = "FLAD-I400";
msg.HKTV_E001 = "HKTV-E001";
msg.HKTV_E002 = "HKTV-E002";
msg.HKTV_E003 = "HKTV-E003";
msg.HKTV_E004 = "HKTV-E004";
msg.HKTV_E005 = "HKTV-E005";
msg.HKTV_E006 = "HKTV-E006";
msg.HKTV_E007 = "HKTV-E007";
msg.HKTV_E008 = "HKTV-E008";
msg.HKTV_E009 = "HKTV-E009";
msg.HKTV_I001 = "HKTV-I001";
msg.HKTV_W001 = "HKTV-W001";
msg.HKTV_W002 = "HKTV-W002";
msg.MSG_FAILED_LOGIN = "MESG-E001";
msg.MSG_NOT_ENOUGH_AUTHORITY = "MESG-E002";
msg.MSG_INVALID_USER = "MESG-E003";
msg.MSG_CANNOT_GET_USER = "MESG-E004";
msg.MSG_FAILED_IDENTIFICATION = "MESG-E005";
msg.MESG_E006 = "MESG-E006";
msg.MESG_E007 = "MESG-E007";
msg.MESG_E008 = "MESG-E008";
msg.MESG_E009 = "MESG-E009";
msg.MESG_E010 = "MESG-E010";
msg.MESG_E011 = "MESG-E011";
msg.MESG_E012 = "MESG-E012";
msg.MESG_E013 = "MESG-E013";
msg.MESG_E014 = "MESG-E014";
msg.MESG_E015 = "MESG-E015";
msg.MESG_E016 = "MESG-E016";
msg.MESG_E017 = "MESG-E017";
msg.MESG_E018 = "MESG-E018";
msg.MSG_TAI_ENTRY_USER = "MESG-E019";
msg.MSG_PLEASE_ENTER = "MESG-E100";
msg.MSG_NO_CHANGED = "MESG-E101";
msg.MSG_MUST_BE_LATER_THAN_TODAY = "MESG-E102";
msg.MSG_MUST_BE_BEFORE_THAN = "MESG-E103";
msg.MSG_VALIDATE_KANA = "MESG-E104";
msg.MSG_VALIDATE_NUMBER = "MESG-E105";
msg.MSG_VALIDATE_MAXLENGTH = "MESG-E106";
msg.MSG_VALIDATE_MINLENGTH = "MESG-E107";
msg.MSG_VALIDATE_DATE = "MESG-E108";
msg.MSG_VALIDATE_MAX_BYTE_LENGTH = "MESG-E109";
msg.MSG_VALIDATE_MIN_BYTE_LENGTH = "MESG-E110";
msg.MSG_VALIDATE_NICKNAME_KIGOU = "MESG-E111";
msg.MSG_VALIDATE_JISX0208 = "MESG-E112";
msg.MSG_VALIDATE_NO_HANKAKU_KANA = "MESG-E113";
msg.MSG_VALIDATE_TEL_NO = "MESG-E114";
msg.MSG_VALIDATE_CORP_TEL_NO = "MESG-E115";
msg.MSG_VALIDATE_DECIMAL = "MESG-E116";
msg.MSG_VALIDATE_DECIMAL_SIZE = "MESG-E117";
msg.MSG_PLEASE_SELECT = "MESG-E118";
msg.MSG_VALIDATE_YM = "MESG-E119";
msg.MSG_MUST_BE_BEFORE_THAN_YM = "MESG-E120";
msg.MSG_VALIDATE_ASCII = "MESG-E121";
msg.MSG_VALIDATE_EISU = "MESG-E122";
msg.MSG_VALIDATE_FIX_BYTE_LENGTH = "MESG-E123";
msg.MSG_VALIDATE_MIN_NUMBER = "MESG-E124";
msg.MSG_VALIDATE_MAX_NUMBER = "MESG-E125";
msg.MSG_VALIDATE_MAIL_ADDRESS = "MESG-E126";
msg.MSG_VALIDATE_FIX_LENGTH = "MESG-E127";
msg.MSG_VALIDATE_FILE_FORMAT = "MESG-E128";
msg.MSG_VALIDATE_WRONG_PREFECTURE = "MESG-E129";
msg.MSG_VALIDATE_OUT_OF_RANGE = "MESG-E130";
msg.MSG_VALIDATE_DUPLICATE = "MESG-E131";
msg.MSG_VALIDATE_HIRAGANA = "MESG-E132";
msg.MSG_VALIDATE_KANA_ATTR = "MESG-E133";
msg.MSG_VALIDATE_ATTR = "MESG-E134";
msg.MSG_VALIDATE_EIGOHYOKI = "MESG-E135";
msg.MSG_VALIDATE_CAPITAL_AND_NUM = "MESG-E136";
msg.MSG_VALIDATE_EIJI = "MESG-E137";
msg.MSG_INVALID_MAIL_DOMAIN = "MESG-E150";
msg.MSG_NOT_MATCH = "MESG-E151";
msg.MESG_E152 = "MESG-E152";
msg.MESG_E153 = "MESG-E153";
msg.MESG_E160 = "MESG-E160";
msg.MESG_E161 = "MESG-E161";
msg.MESG_E162 = "MESG-E162";
msg.MESG_E163 = "MESG-E163";
msg.MESG_E164 = "MESG-E164";
msg.MESG_E165 = "MESG-E165";
msg.MESG_E166 = "MESG-E166";
msg.MESG_E167 = "MESG-E167";
msg.MESG_E168 = "MESG-E168";
msg.MESG_E169 = "MESG-E169";
msg.MESG_E170 = "MESG-E170";
msg.MESG_E171 = "MESG-E171";
msg.MESG_E172 = "MESG-E172";
msg.MESG_E173 = "MESG-E173";
msg.MESG_E174 = "MESG-E174";
msg.MESG_E175 = "MESG-E175";
msg.MESG_E176 = "MESG-E176";
msg.MESG_E177 = "MESG-E177";
msg.MESG_E178 = "MESG-E178";
msg.MESG_E179 = "MESG-E179";
msg.MESG_E180 = "MESG-E180";
msg.MESG_E181 = "MESG-E181";
msg.MESG_E182 = "MESG-E182";
msg.MESG_E183 = "MESG-E183";
msg.MESG_E184 = "MESG-E184";
msg.MESG_E185 = "MESG-E185";
msg.MESG_E186 = "MESG-E186";
msg.MESG_E187 = "MESG-E187";
msg.MESG_E188 = "MESG-E188";
msg.MESG_E189 = "MESG-E189";
msg.MESG_E190 = "MESG-E190";
msg.MSG_VALIDATE_TRUE = "MESG-E191";
msg.MSG_VALIDATE_FALSE = "MESG-E192";
msg.MSG_VALIDATE_EQUALS = "MESG-E193";
msg.MSG_VALIDATE_NOTEQUALS = "MESG-E194";
msg.MSG_VALIDATE_REQUIRED = "MESG-E195";
msg.MSG_VALIDATE_DEPENDSON = "MESG-E196";
msg.MSG_EXCEPTIONPOLICY_VIOLATION = "MESG-E197";
msg.MSG_VALIDATE_KANA_ASCII = "MESG-E198";
msg.MSG_TWO_MAIL_ADDRESS_NOT_MATCH = "MESG-E199";
msg.MSG_CANNOT_SELECTED = "MESG-E200";
msg.MSG_CANNOT_GET = "MESG-E201";
msg.MSG_FAILED_OPERATION = "MESG-E202";
msg.MSG_UPDATED_BY_OTHERS = "MESG-E203";
msg.MSG_FAILED_PROCEDURE_BY_SEARCHERROR = "MESG-E204";
msg.MSG_FAILED_PROCEDURE_BY_CANNOT_FOUND = "MESG-E205";
msg.MSG_FAILED_PROCEDURE_BY_UPDATEERROR = "MESG-E206";
msg.MSG_FAILED_PROCEDURE_BY_NO_UPDATED = "MESG-E207";
msg.MESG_E208 = "MESG-E208";
msg.MESG_E209 = "MESG-E209";
msg.MSG_CANNOT_GET_ZIP_CODE = "MESG-E210";
msg.MESG_E211 = "MESG-E211";
msg.MESG_E212 = "MESG-E212";
msg.MESG_E213 = "MESG-E213";
msg.MESG_E214 = "MESG-E214";
msg.MESG_E215 = "MESG-E215";
msg.MSG_MUST_BE_LATER_THAN_TOMORROW = "MESG-E216";
msg.MESG_E217 = "MESG-E217";
msg.MSG_VALIDATE_KANA_PARENTHESES = "MESG-E218";
msg.MSG_ALREADY_RESERVED = "MESG-E220";
msg.MSG_CANNOT_CONNETCT_API = "MESG-E230";
msg.MESG_E240 = "MESG-E240";
msg.MSG_CANT_CHANGE_ITEM = "MESG-E250";
msg.MESG_E260 = "MESG-E260";
msg.MESG_E270 = "MESG-E270";
msg.MESG_E271 = "MESG-E271";
msg.MESG_E272 = "MESG-E272";
msg.MESG_E300 = "MESG-E300";
msg.MESG_E387 = "MESG-E387";
msg.MESG_E388 = "MESG-E388";
msg.MESG_E389 = "MESG-E389";
msg.MESG_E390 = "MESG-E390";
msg.MESG_E391 = "MESG-E391";
msg.MESG_E392 = "MESG-E392";
msg.MESG_E393 = "MESG-E393";
msg.MESG_E394 = "MESG-E394";
msg.MESG_E395 = "MESG-E395";
msg.MESG_E396 = "MESG-E396";
msg.MESG_E397 = "MESG-E397";
msg.MESG_E398 = "MESG-E398";
msg.MESG_E399 = "MESG-E399";
msg.MESG_E400 = "MESG-E400";
msg.MESG_E401 = "MESG-E401";
msg.MESG_E402 = "MESG-E402";
msg.MESG_E403 = "MESG-E403";
msg.MESG_E404 = "MESG-E404";
msg.MESG_E405 = "MESG-E405";
msg.MESG_E406 = "MESG-E406";
msg.MESG_E407 = "MESG-E407";
msg.MESG_E408 = "MESG-E408";
msg.MESG_E409 = "MESG-E409";
msg.MSG_INVALID_CONNECTION_STATUS = "MESG-E410";
msg.MESG_E411 = "MESG-E411";
msg.MESG_E412 = "MESG-E412";
msg.MSG_FAILED_MACAFEE_UPDATE = "MESG-E420";
msg.MSG_INVALID_MATCHING_SEARCH = "MESG-E430";
msg.MESG_E440 = "MESG-E440";
msg.MESG_E441 = "MESG-E441";
msg.MESG_E442 = "MESG-E442";
msg.MESG_E443 = "MESG-E443";
msg.MESG_E444 = "MESG-E444";
msg.MESG_E445 = "MESG-E445";
msg.MESG_E446 = "MESG-E446";
msg.MSG_NOT_EDITABLE = "MESG-E447";
msg.MSG_SEARCH_KEYWARD_SHORT = "MESG-E448";
msg.MESG_E449 = "MESG-E449";
msg.MESG_E450 = "MESG-E450";
msg.MESG_E451 = "MESG-E451";
msg.MESG_E452 = "MESG-E452";
msg.MESG_E453 = "MESG-E453";
msg.MESG_E454 = "MESG-E454";
msg.MESG_E455 = "MESG-E455";
msg.MESG_E456 = "MESG-E456";
msg.MESG_E457 = "MESG-E457";
msg.MESG_E458 = "MESG-E458";
msg.MESG_E459 = "MESG-E459";
msg.MESG_E460 = "MESG-E460";
msg.MESG_E500 = "MESG-E500";
msg.MESG_E501 = "MESG-E501";
msg.MESG_E502 = "MESG-E502";
msg.MESG_E503 = "MESG-E503";
msg.MESG_E504 = "MESG-E504";
msg.MESG_E505 = "MESG-E505";
msg.MESG_E506 = "MESG-E506";
msg.MESG_E507 = "MESG-E507";
msg.MESG_E508 = "MESG-E508";
msg.MESG_E509 = "MESG-E509";
msg.MESG_E510 = "MESG-E510";
msg.MESG_E511 = "MESG-E511";
msg.MESG_E512 = "MESG-E512";
msg.MESG_E513 = "MESG-E513";
msg.MESG_E514 = "MESG-E514";
msg.MESG_E515 = "MESG-E515";
msg.MESG_E516 = "MESG-E516";
msg.MESG_E517 = "MESG-E517";
msg.MESG_E518 = "MESG-E518";
msg.MESG_E519 = "MESG-E519";
msg.MESG_E520 = "MESG-E520";
msg.MESG_E521 = "MESG-E521";
msg.MESG_E522 = "MESG-E522";
msg.MESG_E523 = "MESG-E523";
msg.MESG_E524 = "MESG-E524";
msg.MESG_E525 = "MESG-E525";
msg.MESG_E526 = "MESG-E526";
msg.MESG_E527 = "MESG-E527";
msg.MESG_E528 = "MESG-E528";
msg.MESG_E529 = "MESG-E529";
msg.MESG_E530 = "MESG-E530";
msg.MESG_E531 = "MESG-E531";
msg.MESG_E532 = "MESG-E532";
msg.MESG_E533 = "MESG-E533";
msg.MESG_E534 = "MESG-E534";
msg.MESG_E535 = "MESG-E535";
msg.MESG_E536 = "MESG-E536";
msg.MESG_E537 = "MESG-E537";
msg.MESG_E538 = "MESG-E538";
msg.MESG_E539 = "MESG-E539";
msg.MESG_E540 = "MESG-E540";
msg.MESG_E541 = "MESG-E541";
msg.MESG_E542 = "MESG-E542";
msg.MESG_E543 = "MESG-E543";
msg.MESG_E544 = "MESG-E544";
msg.MESG_E545 = "MESG-E545";
msg.MESG_E546 = "MESG-E546";
msg.MESG_E547 = "MESG-E547";
msg.MESG_E548 = "MESG-E548";
msg.MESG_E549 = "MESG-E549";
msg.MESG_E550 = "MESG-E550";
msg.MESG_E551 = "MESG-E551";
msg.MESG_E701 = "MESG-E701";
msg.MESG_E702 = "MESG-E702";
msg.MESG_E703 = "MESG-E703";
msg.MESG_E704 = "MESG-E704";
msg.MESG_E705 = "MESG-E705";
msg.MESG_E706 = "MESG-E706";
msg.MESG_E707 = "MESG-E707";
msg.MESG_E708 = "MESG-E708";
msg.MESG_E709 = "MESG-E709";
msg.MESG_E710 = "MESG-E710";
msg.MESG_E711 = "MESG-E711";
msg.MESG_E712 = "MESG-E712";
msg.MESG_E713 = "MESG-E713";
msg.MESG_E714 = "MESG-E714";
msg.MESG_E715 = "MESG-E715";
msg.MESG_E716 = "MESG-E716";
msg.MESG_E717 = "MESG-E717";
msg.MESG_E718 = "MESG-E718";
msg.MESG_E719 = "MESG-E719";
msg.MESG_E720 = "MESG-E720";
msg.MESG_E721 = "MESG-E721";
msg.MESG_E722 = "MESG-E722";
msg.MESG_E723 = "MESG-E723";
msg.MESG_E724 = "MESG-E724";
msg.MESG_E725 = "MESG-E725";
msg.MESG_E726 = "MESG-E726";
msg.MESG_E727 = "MESG-E727";
msg.MESG_E728 = "MESG-E728";
msg.MESG_E729 = "MESG-E729";
msg.MESG_E730 = "MESG-E730";
msg.MESG_E731 = "MESG-E731";
msg.MESG_E732 = "MESG-E732";
msg.MESG_E733 = "MESG-E733";
msg.MESG_E734 = "MESG-E734";
msg.MSTM_E800 = "MSTM-E800";
msg.MSTM_E801 = "MSTM-E801";
msg.MSTM_E805 = "MSTM-E805";
msg.MSTM_E809 = "MSTM-E809";
msg.MSTM_E810 = "MSTM-E810";
msg.MSTM_E811 = "MSTM-E811";
msg.MSTM_E812 = "MSTM-E812";
msg.MSTM_E813 = "MSTM-E813";
msg.MSTM_E814 = "MSTM-E814";
msg.MSTM_E815 = "MSTM-E815";
msg.MSTM_E816 = "MSTM-E816";
msg.MSTM_E817 = "MSTM-E817";
msg.MSTM_E818 = "MSTM-E818";
msg.MSTM_E819 = "MSTM-E819";
msg.MSTM_E820 = "MSTM-E820";
msg.MSTM_E821 = "MSTM-E821";
msg.MSTM_E826 = "MSTM-E826";
msg.MSTM_E827 = "MSTM-E827";
msg.MSTM_E828 = "MSTM-E828";
msg.MSTM_E829 = "MSTM-E829";
msg.MSTM_E830 = "MSTM-E830";
msg.MSTM_E831 = "MSTM-E831";
msg.MSTM_E832 = "MSTM-E832";
msg.MSTM_E833 = "MSTM-E833";
msg.MSTM_E834 = "MSTM-E834";
msg.MSTM_E835 = "MSTM-E835";
msg.MSTM_E836 = "MSTM-E836";
msg.MSTM_E837 = "MSTM-E837";
msg.MSTM_E838 = "MSTM-E838";
msg.MSTM_E839 = "MSTM-E839";
msg.MSTM_E840 = "MSTM-E840";
msg.MSTM_E841 = "MSTM-E841";
msg.MSTM_E842 = "MSTM-E842";
msg.MSTM_E843 = "MSTM-E843";
msg.MSTM_E844 = "MSTM-E844";
msg.MSTM_E845 = "MSTM-E845";
msg.MSTM_E846 = "MSTM-E846";
msg.MSTM_E847 = "MSTM-E847";
msg.MSTM_E848 = "MSTM-E848";
msg.MSTM_E849 = "MSTM-E849";
msg.MSTM_E850 = "MSTM-E850";
msg.MSTM_E861 = "MSTM-E861";
msg.MSTM_E862 = "MSTM-E862";
msg.MSTM_E865 = "MSTM-E865";
msg.MSTM_E866 = "MSTM-E866";
msg.MSTM_E867 = "MSTM-E867";
msg.MSTM_E868 = "MSTM-E868";
msg.MSTM_E869 = "MSTM-E869";
msg.MSTM_E870 = "MSTM-E870";
msg.MSTM_E871 = "MSTM-E871";
msg.MSTM_E872 = "MSTM-E872";
msg.MSTM_E873 = "MSTM-E873";
msg.MSTM_E874 = "MSTM-E874";
msg.MSTM_E875 = "MSTM-E875";
msg.MSTM_E876 = "MSTM-E876";
msg.MSTM_E877 = "MSTM-E877";
msg.MSTM_E878 = "MSTM-E878";
msg.MSTM_E879 = "MSTM-E879";
msg.MSTM_E880 = "MSTM-E880";
msg.MSTM_E881 = "MSTM-E881";
msg.MSTM_E882 = "MSTM-E882";
msg.MSTM_E883 = "MSTM-E883";
msg.MSTM_E884 = "MSTM-E884";
msg.MSTM_E885 = "MSTM-E885";
msg.MSTM_E886 = "MSTM-E886";
msg.MSTM_E887 = "MSTM-E887";
msg.MSTM_E888 = "MSTM-E888";
msg.MSTM_E889 = "MSTM-E889";
msg.MSTM_E890 = "MSTM-E890";
msg.MSTM_E892 = "MSTM-E892";
msg.MSTM_E893 = "MSTM-E893";
msg.MSTM_E894 = "MSTM-E894";
msg.MSTM_E895 = "MSTM-E895";
msg.MSTM_E896 = "MSTM-E896";
msg.MSTM_E897 = "MSTM-E897";
msg.MSTM_E898 = "MSTM-E898";
msg.MSTM_E899 = "MSTM-E899";
msg.MSG_SYSTEMERROR = "MESG-E900";
msg.MSG_CANT_GET_ID_IN_SSO = "MESG-E901";
msg.MSG_SYSTEMINFO_EMPTY = "MESG-E902";
msg.MSG_VALIDATE_LENGTH = "MESG-E903";
msg.MSG_STATIC_PARAM_ERR_1 = "MESG-E904";
msg.MSG_STATIC_PARAM_ERR_2 = "MESG-E905";
msg.MSG_STATIC_PARAM_ERR_3 = "MESG-E906";
msg.MSG_STATIC_PARAM_ERR_4 = "MESG-E907";
msg.MSG_STATIC_PARAM_ERR_5 = "MESG-E908";
msg.MSG_STATIC_PARAM_ERR_6 = "MESG-E909";
msg.MESG_E910 = "MESG-E910";
msg.MSG_STATIC_PARAM_ERR_7 = "MESG-E911";
msg.MSG_STATIC_PARAM_ERR_8 = "MESG-E912";
msg.MESG_E913 = "MESG-E913";
msg.MESG_E914 = "MESG-E914";
msg.MESG_E915 = "MESG-E915";
msg.MESG_E916 = "MESG-E916";
msg.MESG_E917 = "MESG-E917";
msg.MESG_E918 = "MESG-E918";
msg.MESG_E919 = "MESG-E919";
msg.MESG_E920 = "MESG-E920";
msg.MESG_E921 = "MESG-E921";
msg.MESG_E922 = "MESG-E922";
msg.MSG_CANNOT_GET_REQIREDINFO = "MESG-F001";
msg.MESG_F002 = "MESG-F002";
msg.MSG_NO_EXISTS_OPTION_CONTENTS = "MESG-I001";
msg.MSG_COMPLETED_REGISTRATION = "MESG-I002";
msg.MSG_SENT_RETRY_URL = "MESG-I003";
msg.MSG_COMPLETED_PASSWORD_RESET = "MESG-I004";
msg.MSG_CAN_ENTRY_FAMILYPACK = "MESG-I005";
msg.MSG_CANNOT_GET_USAGEFEE = "MESG-I006";
msg.MSG_CANNOT_GET_CAMPAIGN = "MESG-I007";
msg.MSG_CANNOT_GET_CHILDUSER = "MESG-I008";
msg.MSG_CANNOT_GET_SONETPOINT = "MESG-I009";
msg.MESG_I010 = "MESG-I010";
msg.MESG_I011 = "MESG-I011";
msg.MESG_I012 = "MESG-I012";
msg.MESG_I013 = "MESG-I013";
msg.MESG_I014 = "MESG-I014";
msg.MESG_I015 = "MESG-I015";
msg.MESG_I016 = "MESG-I016";
msg.MESG_I017 = "MESG-I017";
msg.MSG_CANNOT_GET_CORPORATE = "MESG-I018";
msg.MSG_CONFIRM_DELETE = "MESG-I020";
msg.MESG_I021 = "MESG-I021";
msg.MESG_I400 = "MESG-I400";
msg.MESG_I401 = "MESG-I401";
msg.MESG_I451 = "MESG-I451";
msg.MESG_I452 = "MESG-I452";
msg.MESG_I453 = "MESG-I453";
msg.MESG_I454 = "MESG-I454";
msg.MESG_I456 = "MESG-I456";
msg.MESG_I457 = "MESG-I457";
msg.MESG_I458 = "MESG-I458";
msg.MESG_I459 = "MESG-I459";
msg.MESG_I460 = "MESG-I460";
msg.MESG_I461 = "MESG-I461";
msg.MESG_I462 = "MESG-I462";
msg.MESG_I463 = "MESG-I463";
msg.MESG_I464 = "MESG-I464";
msg.MESG_I465 = "MESG-I465";
msg.MESG_I466 = "MESG-I466";
msg.MESG_I467 = "MESG-I467";
msg.MESG_I468 = "MESG-I468";
msg.MESG_I469 = "MESG-I469";
msg.MESG_I470 = "MESG-I470";
msg.MESG_I471 = "MESG-I471";
msg.MESG_I472 = "MESG-I472";
msg.MESG_I473 = "MESG-I473";
msg.MESG_I474 = "MESG-I474";
msg.MSG_OVER_COUNT_MEMBER_CUSTOMER_SEARCH = "MESG-I476";
msg.MESG_I477 = "MESG-I477";
msg.MESG_I478 = "MESG-I478";
msg.MESG_I479 = "MESG-I479";
msg.MESG_I480 = "MESG-I480";
msg.MESG_I481 = "MESG-I481";
msg.MESG_I482 = "MESG-I482";
msg.MESG_I483 = "MESG-I483";
msg.MESG_I484 = "MESG-I484";
msg.MESG_I485 = "MESG-I485";
msg.MESG_I486 = "MESG-I486";
msg.MESG_I487 = "MESG-I487";
msg.MESG_I489 = "MESG-I489";
msg.MESG_I490 = "MESG-I490";
msg.MESG_I491 = "MESG-I491";
msg.MESG_I492 = "MESG-I492";
msg.MESG_I493 = "MESG-I493";
msg.MESG_I494 = "MESG-I494";
msg.MESG_I495 = "MESG-I495";
msg.MESG_I496 = "MESG-I496";
msg.MESG_I721 = "MESG-I721";
msg.MESG_I722 = "MESG-I722";
msg.MSTM_I802 = "MSTM-I802";
msg.MSTM_I803 = "MSTM-I803";
msg.MSTM_I804 = "MSTM-I804";
msg.MSTM_I823 = "MSTM-I823";
msg.MSTM_I824 = "MSTM-I824";
msg.MSTM_I825 = "MSTM-I825";
msg.MSTM_I891 = "MSTM-I891";
msg.MESG_I900 = "MESG-I900";
msg.MESG_I901 = "MESG-I901";
msg.MESG_I902 = "MESG-I902";
msg.MESG_I903 = "MESG-I903";
msg.MESG_I904 = "MESG-I904";
msg.MESG_I905 = "MESG-I905";
msg.MSG_CHANGED_AUTH_ID = "MESG-W001";
msg.MESG_W002 = "MESG-W002";
msg.MESG_W401 = "MESG-W401";
msg.MESG_W402 = "MESG-W402";
msg.MULTI_SUBMIT_ERROR = "MESG-W440";
msg.MESG_W441 = "MESG-W441";
msg.MESG_W477 = "MESG-W477";
msg.MESG_W480 = "MESG-W480";
msg.MESG_W481 = "MESG-W481";
msg.MSTM_W806 = "MSTM-W806";
msg.MSTM_W807 = "MSTM-W807";
msg.MSTM_W808 = "MSTM-W808";
msg.MSTM_W851 = "MSTM-W851";
msg.MSTM_W852 = "MSTM-W852";
msg.MSTM_W853 = "MSTM-W853";
msg.MSTM_W854 = "MSTM-W854";
msg.MSTM_W855 = "MSTM-W855";
msg.MSTM_W856 = "MSTM-W856";
msg.MSTM_W857 = "MSTM-W857";
msg.MSTM_W858 = "MSTM-W858";
msg.MSTM_W859 = "MSTM-W859";
msg.RNSV_E001 = "RNSV-E001";
msg.RNSV_E002 = "RNSV-E002";
msg.RNSV_E003 = "RNSV-E003";
msg.RNSV_E004 = "RNSV-E004";
msg.RNSV_E005 = "RNSV-E005";
msg.RNSV_E006 = "RNSV-E006";
msg.RNSV_E007 = "RNSV-E007";
msg.RNSV_E008 = "RNSV-E008";
msg.RNSV_E009 = "RNSV-E009";
msg.RNSV_E010 = "RNSV-E010";
msg.RNSV_E011 = "RNSV-E011";
msg.RNSV_E012 = "RNSV-E012";
msg.RNSV_W002 = "RNSV-W002";
msg.RNSV_W003 = "RNSV-W003";
msg.RNSV_W004 = "RNSV-W004";
msg.RNSV_W005 = "RNSV-W005";
msg.RNSV_W006 = "RNSV-W006";
msg.SAEA_I400 = "SAEA-I400";
msg.WMAX_I001 = "WMAX-I001";
msg.MB3G_E001 = "MB3G-E001";
msg.MESG_E601 = "MESG-E601";
msg.MESG_E602 = "MESG-E602";
msg.MESG_E603 = "MESG-E603";
msg.MESG_E604 = "MESG-E604";
msg.MESG_E605 = "MESG-E605";
msg.MESG_E606 = "MESG-E606";
msg.MESG_E607 = "MESG-E607";
msg.MESG_E608 = "MESG-E608";
msg.MESG_E609 = "MESG-E609";
msg.MESG_E610 = "MESG-E610";
msg.MESG_E611 = "MESG-E611";
msg.MESG_E612 = "MESG-E612";
msg.MESG_E613 = "MESG-E613";
msg.MESG_E614 = "MESG-E614";
msg.MESG_E615 = "MESG-E615";
msg.MESG_E616 = "MESG-E616";
msg.MESG_E617 = "MESG-E617";
msg.MESG_E618 = "MESG-E618";
msg.MESG_E619 = "MESG-E619";
msg.MESG_E620 = "MESG-E620";
msg.MESG_E621 = "MESG-E621";
msg.MESG_E622 = "MESG-E622";
msg.MESG_E623 = "MESG-E623";
msg.MESG_E624 = "MESG-E624";
msg.MESG_E625 = "MESG-E625";
msg.MESG_E626 = "MESG-E626";
msg.MESG_E627 = "MESG-E627";
msg.MESG_E628 = "MESG-E628";
msg.MESG_E629 = "MESG-E629";
msg.MESG_E630 = "MESG-E630";
msg.MESG_E631 = "MESG-E631";
msg.MESG_E632 = "MESG-E632";
msg.MESG_E633 = "MESG-E633";
msg.MESG_E634 = "MESG-E634";
msg.MESG_E635 = "MESG-E635";
msg.MESG_E636 = "MESG-E636";
msg.MESG_E637 = "MESG-E637";
msg.MESG_E638 = "MESG-E638";
msg.MESG_E639 = "MESG-E639";
msg.MESG_E640 = "MESG-E640";
msg.MESG_E641 = "MESG-E641";
msg.MESG_E642 = "MESG-E642";
msg.MESG_E643 = "MESG-E643";
msg.MESG_E644 = "MESG-E644";
msg.MESG_E645 = "MESG-E645";
msg.MESG_E646 = "MESG-E646";
msg.MESG_E647 = "MESG-E647";
msg.MESG_E648 = "MESG-E648";
msg.MESG_E649 = "MESG-E649";
msg.MESG_E650 = "MESG-E650";
msg.MESG_E651 = "MESG-E651";
msg.MESG_E652 = "MESG-E652";
msg.MESG_E653 = "MESG-E653";
msg.MESG_E654 = "MESG-E654";
msg.MESG_E655 = "MESG-E655";
msg.MESG_E656 = "MESG-E656";
msg.MESG_E657 = "MESG-E657";
msg.MESG_E658 = "MESG-E658";
msg.MESG_E659 = "MESG-E659";
msg.MESG_E660 = "MESG-E660";
msg.MESG_E661 = "MESG-E661";
msg.MESG_E662 = "MESG-E662";
msg.MESG_E663 = "MESG-E663";
msg.MESG_E664 = "MESG-E664";
msg.MESG_E665 = "MESG-E665";
msg.MESG_E666 = "MESG-E666";
msg.MESG_E667 = "MESG-E667";
msg.TIKI_W001 = "TIKI-W001";
msg.TIKI_W002 = "TIKI-W002";
msg.TIKI_W003 = "TIKI-W003";
msg.TIKI_W004 = "TIKI-W004";
msg.TIKI_W005 = "TIKI-W005";
msg.TIKI_W006 = "TIKI-W006";
msg.TIKI_W007 = "TIKI-W007";
msg.MSG_VALIDATE_URL = "MESG-E138";
msg.MESG_E552 = "MESG-E552";
msg.MESG_E555 = "MESG-E555";
msg.MESG_E556 = "MESG-E556";
msg.MSTM_E796 = "MSTM-E796";
msg.MSTM_E797 = "MSTM-E797";
msg.MSTM_E798 = "MSTM-E798";
msg.MSTM_E799 = "MSTM-E799";
msg.MSTM_E860 = "MSTM-E860";
msg.MESG_I488 = "MESG-I488";
msg.TIKI_W008 = "TIKI-W008";
msg.TIKI_W009 = "TIKI-W009";
msg.TIKI_I010 = "TIKI-I010";
msg.TIKI_I011 = "TIKI-I011";
msg.TIKI_E012 = "TIKI-E012";
msg.TIKI_E013 = "TIKI-E013";
msg.TIKI_E014 = "TIKI-E014";
msg.TIKI_E015 = "TIKI-E015";
msg.TIKI_E016 = "TIKI-E016";
msg.TIKI_E017 = "TIKI-E017";
msg.TIKI_E018 = "TIKI-E018";
msg.TIKI_E019 = "TIKI-E019";
msg.TIKI_E020 = "TIKI-E020";
msg.TIKI_E021 = "TIKI-E021";
msg.MESG_E668 = "MESG-E668";
msg.MESG_E470 = "MESG-E470";
msg.MESG_E471 = "MESG-E471";
msg.MESG_E680 = "MESG-E680";
msg.MESG_E681 = "MESG-E681";
msg.MESG_E682 = "MESG-E682";
msg.MESG_E683 = "MESG-E683";
msg.MESG_E684 = "MESG-E684";
msg.MESG_E472 = "MESG-E472";
msg.MESG_E473 = "MESG-E473";
msg.MESG_E474 = "MESG-E474";
msg.MESG_E475 = "MESG-E475";
msg.MESG_E476 = "MESG-E476";
msg.MESG_E477 = "MESG-E477";
msg.MESG_E478 = "MESG-E478";
msg.MESG_E479 = "MESG-E479";
msg.MESG_E480 = "MESG-E480";
msg.MESG_E669 = "MESG-E669";
msg.MESG_I910 = "MESG-I910";
msg.MESG_I911 = "MESG-I911";
msg.MESG_I912 = "MESG-I912";
msg.MESG_I913 = "MESG-I913";
msg.MESG_I914 = "MESG-I914";
msg.MESG_I915 = "MESG-I915";
msg.MESG_I916 = "MESG-I916";
msg.MESG_I917 = "MESG-I917";
msg.MESG_E557 = "MESG-E557";
msg.MESG_E670 = "MESG-E670";
msg.MESG_E558 = "MESG-E558";
msg.MESG_E671 = "MESG-E671";
msg.MESG_E672 = "MESG-E672";
msg.MESG_E673 = "MESG-E673";
msg.TIKI_E022 = "TIKI-E022";
msg.MESG_E559 = "MESG-E559";
msg.MESG_I918 = "MESG-I918";
msg.MESG_E560 = "MESG-E560";
msg.MESG_E674 = "MESG-E674";
msg.MESG_W690 = "MESG-W690";
msg.MESG_W691 = "MESG-W691";
msg.MESG_W692 = "MESG-W692";
msg.MESG_E561 = "MESG-E561";
msg.MESG_I919 = "MESG-I919";
msg.MESG_W693 = "MESG-W693";
msg.MESG_W694 = "MESG-W694";
msg.MESG_W695 = "MESG-W695";
msg.MESG_W696 = "MESG-W696";
msg.MESG_W697 = "MESG-W697";
msg.MESG_W698 = "MESG-W698";
msg.MESG_E562 = "MESG-E562";
msg.MESG_E563 = "MESG-E563";
msg.MESG_E564 = "MESG-E564";
msg.MESG_E675 = "MESG-E675";
msg.MESG_E676 = "MESG-E676";
msg.MESG_W699 = "MESG-W699";
msg.MESG_I920 = "MESG-I920";
msg.MESG_W700 = "MESG-W700";
msg.MESG_W701 = "MESG-W701";
msg.MESG_W702 = "MESG-W702";
msg.MESG_GET_PLURALITY = "MESG-W703";
msg.MESG_W704 = "MESG-W704";
msg.MESG_W705 = "MESG-W705";
msg.MESG_W706 = "MESG-W706";
msg.MESG_E481 = "MESG-E481";
msg.MESG_E482 = "MESG-E482";
msg.MESG_E483 = "MESG-E483";
msg.MESG_E484 = "MESG-E484";
msg.MSG_USR_MAX_LMTAMT = "MESG-W707";
msg.MSG_CS_MAX_LMTAMT = "MESG-W708";
msg.MESG_W709 = "MESG-W709";
msg.MESG_W710 = "MESG-W710";
msg.MESG_W711 = "MESG-W711";
msg.MESG_E485 = "MESG-E485";
msg.MESG_W403 = "MESG-W403";
msg.MESG_E677 = "MESG-E677";
msg.MESG_E678 = "MESG-E678";
msg.MESG_E679 = "MESG-E679";
msg.MSTM_E794 = "MSTM-E794";
msg.MSTM_E795 = "MSTM-E795";
msg.MESG_E930 = "MESG-E930";
msg.MESG_E931 = "MESG-E931";
msg.MESG_E932 = "MESG-E932";
msg.MESG_E933 = "MESG-E933";
msg.MESG_I934 = "MESG-I934";
msg.MESG_E935 = "MESG-E935";
msg.MESG_E936 = "MESG-E936";
msg.MESG_E937 = "MESG-E937";
msg.MESG_E944 = "MESG-E944";
msg.MESG_E945 = "MESG-E945";
msg.MESG_E946 = "MESG-E946";
msg.MESG_E947 = "MESG-E947";
msg.MESG_E948 = "MESG-E948";
msg.MESG_E590 = "MESG-E590";
msg.MESG_E938 = "MESG-E938";
msg.MESG_E939 = "MESG-E939";
msg.MESG_E940 = "MESG-E940";
msg.MESG_I935 = "MESG-I935";
msg.MESG_E941 = "MESG-E941";
msg.MESG_E942 = "MESG-E942";
msg.MESG_E565 = "MESG-E565";
msg.MESG_E566 = "MESG-E566";
msg.MESG_I921 = "MESG-I921";
msg.MESG_E567 = "MESG-E567";
msg.MESG_E568 = "MESG-E568";
msg.MESG_E569 = "MESG-E569";
msg.MESG_E570 = "MESG-E570";
msg.MESG_E571 = "MESG-E571";
msg.MESG_W943 = "MESG-W943";
msg.MESG_I922 = "MESG-I922";
msg.MESG_I923 = "MESG-I923";
msg.MESG_I924 = "MESG-I924";
msg.MESG_I925 = "MESG-I925";
msg.MESG_I926 = "MESG-I926";
msg.MESG_I927 = "MESG-I927";
msg.MESG_E928 = "MESG-E928";
msg.MESG_E929 = "MESG-E929";
msg.MESG_E572 = "MESG-E572";
msg.MESG_E573 = "MESG-E573";
msg.MESG_E574 = "MESG-E574";
msg.MESG_E575 = "MESG-E575";
msg.MESG_E576 = "MESG-E576";
msg.MESG_E577 = "MESG-E577";
msg.MESG_E578 = "MESG-E578";
msg.MESG_E579 = "MESG-E579";
msg.MESG_E580 = "MESG-E580";
msg.MESG_E581 = "MESG-E581";
msg.MESG_E582 = "MESG-E582";
msg.MESG_E583 = "MESG-E583";
msg.MESG_E584 = "MESG-E584";
msg.MESG_E585 = "MESG-E585";
msg.MESG_E586 = "MESG-E586";
msg.MESG_E587 = "MESG-E587";
msg.MESG_E588 = "MESG-E588";
msg.MESG_E589 = "MESG-E589";
msg.MESG_E591 = "MESG-E591";
msg.MESG_E592 = "MESG-E592";
msg.MESG_E593 = "MESG-E593";
msg.AGTS_I001 = "AGTS-I001";
msg.MESG_E594 = "MESG-E594";
msg.MESG_E595 = "MESG-E595";
msg.MESG_E596 = "MESG-E596";
msg.MESG_E597 = "MESG-E597";
msg.MESG_E598 = "MESG-E598";
msg.MESG_E599 = "MESG-E599";
msg.DVPF_E001 = "DVPF-E001";
msg.MESG_E690 = "MESG-E690";
msg.MESG_E691 = "MESG-E691";
msg.MESG_E692 = "MESG-E692";
msg.MESG_E693 = "MESG-E693";
msg.MESG_E694 = "MESG-E694";
msg.TIKI_E023 = "TIKI-E023";
msg.TIKI_E024 = "TIKI-E024";
msg.TIKI_E025 = "TIKI-E025";
msg.TIKI_E026 = "TIKI-E026";
msg.TIKI_E027 = "TIKI-E027";
msg.MESG_I928 = "MESG-I928";
msg.MESG_E695 = "MESG-E695";
msg.MESG_E696 = "MESG-E696";
msg.MESG_E697 = "MESG-E697";
msg.MESG_E698 = "MESG-E698";
msg.MESG_W944 = "MESG-W944";
msg.PHON_E001 = "PHON-E001";
msg.MESG_E943 = "MESG-E943";
msg.MESG_E750 = "MESG-E750";
msg.MESG_E751 = "MESG-E751";
msg.MESG_E752 = "MESG-E752";
msg.MESG_E753 = "MESG-E753";
msg.MESG_E754 = "MESG-E754";
msg.MESG_E755 = "MESG-E755";
msg.MESG_E756 = "MESG-E756";
msg.MESG_E757 = "MESG-E757";
msg.MESG_E758 = "MESG-E758";
msg.MESG_E759 = "MESG-E759";
msg.MESG_E760 = "MESG-E760";
msg.MESG_E761 = "MESG-E761";
msg.MESG_E762 = "MESG-E762";
msg.MESG_E763 = "MESG-E763";
msg.MESG_E764 = "MESG-E764";
msg.MESG_E765 = "MESG-E765";
msg.MESG_E766 = "MESG-E766";
msg.MESG_E767 = "MESG-E767";
msg.MESG_E768 = "MESG-E768";
msg.MESG_E769 = "MESG-E769";
msg.MESG_E770 = "MESG-E770";
msg.MESG_E771 = "MESG-E771";
msg.MESG_E772 = "MESG-E772";
msg.MESG_E773 = "MESG-E773";
msg.MESG_E950 = "MESG-E950";
msg.MESG_E951 = "MESG-E951";
msg.MESG_E685 = "MESG-E685";
msg.MESG_E952 = "MESG-E952";
msg.MESG_E953 = "MESG-E953";
msg.MESG_E954 = "MESG-E954";
msg.MATI_E101 = "MATI-E101";
msg.MATI_E201 = "MATI-E201";
msg.MATI_E202 = "MATI-E202";
msg.MATI_E203 = "MATI-E203";
msg.MATI_E204 = "MATI-E204";
msg.MATI_E205 = "MATI-E205";
msg.MATI_E207 = "MATI-E207";
msg.MATI_E208 = "MATI-E208";
msg.MATI_E209 = "MATI-E209";
msg.MATI_E210 = "MATI-E210";
msg.MATI_E211 = "MATI-E211";
msg.MATI_E212 = "MATI-E212";
msg.MATI_E213 = "MATI-E213";
msg.MATI_E501 = "MATI-E501";
msg.MATI_E502 = "MATI-E502";
msg.MATI_E503 = "MATI-E503";
msg.MATI_E504 = "MATI-E504";
msg.MATI_E505 = "MATI-E505";
msg.MATI_E506 = "MATI-E506";
msg.MATI_E507 = "MATI-E507";
msg.MATI_E214 = "MATI-E214";
msg.MESG_W712 = "MESG-W712";
msg.MESG_I929 = "MESG-I929";
msg.MESG_I930 = "MESG-I930";
msg.MESG_I931 = "MESG-I931";
msg.MESG_I932 = "MESG-I932";
msg.MESG_I933 = "MESG-I933";
msg.MESG_I937 = "MESG-I937";
msg.MESG_I938 = "MESG-I938";
msg.MESG_E955 = "MESG-E955";
msg.MESG_E956 = "MESG-E956";
msg.MESG_E957 = "MESG-E957";
msg.MESG_E958 = "MESG-E958";
msg.MESG_E959 = "MESG-E959";
msg.MESG_E960 = "MESG-E960";
msg.MESG_E961 = "MESG-E961";
msg.MESG_E962 = "MESG-E962";
msg.MESG_E963 = "MESG-E963";
msg.MESG_E964 = "MESG-E964";
msg.MESG_E965 = "MESG-E965";
msg.MESG_E966 = "MESG-E966";
msg.MESG_E967 = "MESG-E967";
msg.MESG_E968 = "MESG-E968";
msg.MESG_E969 = "MESG-E969";
msg.MESG_E780 = "MESG-E780";
msg.MESG_E781 = "MESG-E781";
msg.MESG_E782 = "MESG-E782";
msg.MESG_E783 = "MESG-E783";
msg.MESG_E784 = "MESG-E784";
msg.MESG_E785 = "MESG-E785";
msg.MSTM_I901 = "MSTM-I901";
msg.MSTM_I902 = "MSTM-I902";
msg.MSTM_E903 = "MSTM-E903";
msg.MESG_E786 = "MESG-E786";
msg.MESG_E787 = "MESG-E787";
msg.MSTM_E904 = "MSTM-E904";
msg.MESG_W788 = "MESG-W788";
msg.RNSV_W007 = "RNSV-W007";
msg.RNSV_W008 = "RNSV-W008";
msg.MSTM_E905 = "MSTM-E905";
msg.MSG_MUST_BE_BEFORE_THAN_TODAY = "MESG-E221";
msg.MSG_MUST_BE_BEFORE_THAN_TODAY_OF_MONTH = "MESG-E222";
msg.MSTM_E906 = "MSTM-E906";
msg.MSTM_E907 = "MSTM-E907";
msg.MSTM_E908 = "MSTM-E908";
msg.MSTM_E909 = "MSTM-E909";
msg.RNSV_E101 = "RNSV-E101";
msg.MESG_W900 = "MESG-W900";
msg.MESG_W901 = "MESG-W901";
msg.MESG_W902 = "MESG-W902";
msg.DVPF_E002 = "DVPF-E002";
msg.MESG_I497 = "MESG-I497";
msg.RSHS_E001 = "RSHS-E001";
msg.MESG_E789 = "MESG-E789";
msg.MESG_E790 = "MESG-E790";
msg.MESG_E791 = "MESG-E791";
msg.MESG_E792 = "MESG-E792";
msg.AGTS_REQUEST_NOT_FOUND = "AGTS-E001";
msg.AGTS_STATUS_UPDATE_INVALID = "AGTS-E002";
msg.AGTS_OLSUID_NOTEXISTS = "AGTS-E003";
msg.MESG_E923 = "MESG-E923";
msg.MESG_E970 = "MESG-E970";
msg.AGTS_WAIT_DOWNLOAD = "AGTS-W001";
msg.MESG_E986 = "MESG-E986";
msg.MESG_E971 = "MESG-E971";
msg.MESG_E972 = "MESG-E972";
msg.MESG_E975 = "MESG-E975";
msg.MESG_E976 = "MESG-E976";
msg.MESG_E977 = "MESG-E977";
msg.MESG_E978 = "MESG-E978";
msg.MESG_E979 = "MESG-E979";
msg.MESG_E980 = "MESG-E980";
msg.MESG_E981 = "MESG-E981";
msg.MESG_E982 = "MESG-E982";
msg.MESG_E983 = "MESG-E983";
msg.MESG_E984 = "MESG-E984";
msg.MESG_E985 = "MESG-E985";
msg.MESG_I936 = "MESG-I936";
msg.MESG_E987 = "MESG-E987";
msg.MESG_E988 = "MESG-E988";
msg.MESG_E989 = "MESG-E989";
msg.MESG_E990 = "MESG-E990";
msg.MESG_W903 = "MESG-W903";
msg.MESG_E991 = "MESG-E991";
msg.MESG_E992 = "MESG-E992";
msg.MESG_E993 = "MESG-E993";
msg.MESG_E994 = "MESG-E994";
msg.MESG_E995 = "MESG-E995";
msg.MESG_I996 = "MESG-I996";
msg.MESG_E997 = "MESG-E997";
msg.MESG_E998 = "MESG-E998";
msg.MESG_E999 = "MESG-E999";
msg.MESG_E1000 = "MESG-E1000";
msg.MESG_E1001 = "MESG-E1001";
msg.MESG_E1002 = "MESG-E1002";
msg.MESG_E1003 = "MESG-E1003";
msg.MESG_E1004 = "MESG-E1004";

msg.messageJson = {
    "AMKM-I001" : "[ご利用開始月について]<br/>下記のいずれか早い時点でご利用開始となり、その月より月額基本料金が発生いたします。<br/>　・ 本サービスと同時にお申し込みいただいた接続コースのサービス開始月<br/>　・ So-net 安心サポート専用ダイヤルに初めてご相談いただいた月<br/>",
    "AMKM-I002" : "既に解約のお手続きを承っております。<br/>継続利用をご希望の場合は、お手数ですが翌月以降に再度お手続きください。<br/>",
    "AUHK-I400" : "「郵便番号」、「電話番号」双方のご入力をお勧めします。「郵便番号」のみでの検索より、正確なエリア検索が可能です。",
    "BWEO-W001" : "プランと機器の組み合わせが正しくありません。<br/>お手数ですが、再度選択しなおしてください。",
    "FLAD-I400" : "NTT固定電話をお持ちでない方は、近隣の電話番号の下3桁を000にして入力してください。",
    "HKTV-E001" : "既にひかりＴＶの契約が2件登録されています。",
    "HKTV-E002" : "お申し込み月中のお手続きとなるため、解約できません。<br/>お手数ですが、翌月以降に再度お手続きください。",
    "HKTV-E003" : "お申し込み月中のお手続きとなるため、解約できません。<br/>お手数ですが、翌月以降に再度お手続きください。",
    "HKTV-E004" : "プラン変更を行った当月のため、解約できません。<br/>お手数ですが、翌月以降に再度お手続きください。",
    "HKTV-E005" : "ご利用可能なひかりTVプランがありません。",
    "HKTV-E006" : "初月無料のプレミアムチャンネルを購入した当月のため、解約できません。<br/>お手数ですが、翌月以降に再度お手続きください。",
    "HKTV-E007" : "初月無料のプレミアムビデオを購入した当月のため、解約できません。<br/>お手数ですが、翌月以降に再度お手続きください。",
    "HKTV-E008" : "キャンペーンが適用されている無料期間中のため、解約できません。<br/>お手数ですが、キャンペーン適用期間終了後に再度お手続きください。",
    "HKTV-E009" : "ひかりTVの料金履歴はありません。",
    "HKTV-I001" : "現在ご利用中のオプションはありません。",
    "HKTV-W001" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "HKTV-W002" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E001" : "ログインできません。",
    "MESG-E002" : "お客さまのご契約内容では、当画面をご利用になれません。",
    "MESG-E003" : "既に退会済か利用停止のため、処理ができません。",
    "MESG-E004" : "入力されたユーザーIDまたはメールアドレスはございません。",
    "MESG-E005" : "ご本人さま確認ができませんでした。",
    "MESG-E006" : "現在サービスのご利用はございません。",
    "MESG-E007" : "現在、お客さまがお申し込み可能なサービスはございません。",
    "MESG-E008" : "現在、お客さまが解約可能なサービスはございません。",
    "MESG-E009" : "お客さまは既にサービスにお申し込みされております。<br/>最初の画面に戻り、再度お申し込みください。",
    "MESG-E010" : "こんてんつコースへ変更申請中のため、選択されたサービスにはお申し込みいただけません。",
    "MESG-E011" : "お客さまが現在お申し込み可能な機器はございません。",
    "MESG-E012" : "現在ご利用状況を確認できる契約情報がございません。",
    "MESG-E013" : "お客さまが現在お申し込み可能なプランはございません。",
    "MESG-E014" : "お客さまが現在お申し込み可能な機器はございません。",
    "MESG-E015" : "ご利用可能な{0}がありません。申し訳ございませんが、本サービスはご利用いただけません。",
    "MESG-E016" : "{0}を再度選択してください。",
    "MESG-E017" : "{0}は{1}を選択してください。",
    "MESG-E018" : "{0}と{1}はどちらか一方に入力してください。",
    "MESG-E019" : "現在退会の申請を承っているため、お申し込みいただけません。<br/>お申し込みいただくためには、退会の申請をキャンセルしていただく必要がございます。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E100" : "{0}を入力してください。",
    "MESG-E101" : "変更箇所がありません。",
    "MESG-E102" : "{0}には本日以降の日付を入力してください。",
    "MESG-E103" : "{0}には、{1}から{2}までの日付を入力してください。",
    "MESG-E104" : "{0}はカタカナで入力してください。",
    "MESG-E105" : "{0}は数値で入力してください。",
    "MESG-E106" : "{0}は{1}文字以内で入力してください。",
    "MESG-E107" : "{0}は{1}文字以上で入力してください。",
    "MESG-E108" : "{0}に正しい日付を入力してください。",
    "MESG-E109" : "{0}は全角{1}文字(半角{2}文字)以内で入力してください。",
    "MESG-E110" : "{0}は全角{1}文字(半角{2}文字)以上で入力してください。",
    "MESG-E111" : "{0}には半角記号「#」「?」「%」「@」「;」「'」「\"」「<」「>」「,」「/」「|」「\\」「&」は使用できません。",
    "MESG-E112" : "{0}には引用符、カンマ、機種依存文字は使用できません。",
    "MESG-E113" : "{0}には半角カタカナは使用できません。",
    "MESG-E114" : "{0}には正しい電話番号を入力してください。",
    "MESG-E115" : "{0}には正しい電話番号を入力してください(フリーダイヤルは使用できません)。",
    "MESG-E116" : "{0}は数値または少数で入力してください。",
    "MESG-E117" : "{0}は小数点以下{1}以下で入力してください。",
    "MESG-E118" : "{0}を選択してください。",
    "MESG-E119" : "{0}に正しい年月を入力してください。",
    "MESG-E120" : "{0}には{1}より{2}までの年月を入力してください。",
    "MESG-E121" : "{0}は英数記号で入力してください。",
    "MESG-E122" : "{0}は英数字で入力してください。",
    "MESG-E123" : "{0}は全角{1}文字(半角{2}文字)で入力してください。",
    "MESG-E124" : "{0}は{1}以上を入力してください。",
    "MESG-E125" : "{0}は{1}以下で入力してください。",
    "MESG-E126" : "{0}は有効なメールアドレスを入力してください。",
    "MESG-E127" : "{0}は{1}文字で入力してください。",
    "MESG-E128" : "取込ファイルは、規定の区切り文字および項目数で入力してください。区切り文字：{0}、項目数：{1}",
    "MESG-E129" : "都道府県名を正しく入力してください（例：○東京都、×東京）。入力値：{0}",
    "MESG-E130" : "{0}の有効範囲内で入力してください。",
    "MESG-E131" : "{0}件目の{1}と重複しています。",
    "MESG-E132" : "{0}は、ひらがなで入力してください。",
    "MESG-E133" : "{0}は、ひらがな、空白、全角記号(、。・ー「」『』)で入力してください。",
    "MESG-E134" : "{0}の文字が正しくありません。",
    "MESG-E135" : "{0}は、英数字、空白、記号（. _-）で入力してください。",
    "MESG-E136" : "{0}は、英大文字、数字で入力してください。",
    "MESG-E137" : "{0}は、英字で入力してください。",
    "MESG-E150" : "接続会員の方は「xxx＠so-net.ne.jp」となるメールアドレスを入力してください。",
    "MESG-E151" : "{0}と{1}（確認用）が一致しません。",
    "MESG-E152" : "{0}に正しい値を入力してください。",
    "MESG-E153" : "連絡先メールアドレスに、So-net のメールアドレスは登録できません。<br/>ご利用されている携帯電話メールアドレスやフリーメールアドレスを、ご入力ください。",
    "MESG-E160" : "必須項目が未入力です。",
    "MESG-E161" : "カタカナで入力してください。",
    "MESG-E162" : "カタカナ・英数記号(引用符、カンマ、機種依存文字を除く)で入力してください。",
    "MESG-E163" : "英数記号で入力してください。",
    "MESG-E164" : "英数字で入力してください。",
    "MESG-E165" : "半角カタカナは使用できません。",
    "MESG-E166" : "数値を入力してください。",
    "MESG-E167" : "{0}以上を入力してください。",
    "MESG-E168" : "{0}以下を入力してください。",
    "MESG-E169" : "小数点以下は{0}桁以内で入力してください。",
    "MESG-E170" : "数値・少数で入力してください。",
    "MESG-E171" : "{0}文字以内で入力してください。",
    "MESG-E172" : "{0}文字で入力してください。",
    "MESG-E173" : "全角{0}文字(半角{1}文字)以内で入力してください。",
    "MESG-E174" : "全角{0}文字(半角{1}文字)で入力してください。",
    "MESG-E175" : "引用符、カンマ、機種依存文字は使用できません。",
    "MESG-E176" : "正しい値を入力してください。",
    "MESG-E177" : "正しい電話番号を入力してください(フリーダイヤルはご使用いただけません)。",
    "MESG-E178" : "正しい電話番号を入力してください。",
    "MESG-E179" : "半角記号「#」「?」「%」「@」「;」「'」「\"」「<」「>」「,」「/」「|」「\\」「&」は使用できません。",
    "MESG-E180" : "有効なメールアドレスを入力してください。",
    "MESG-E181" : "正しい年月を入力してください。",
    "MESG-E182" : "郵便番号は合わせて7桁となるように入力してください。",
    "MESG-E183" : "正しい日付を指定してください。",
    "MESG-E184" : "変更日には{0}から{1}までの日付を指定してください。",
    "MESG-E185" : "市外局番には0から始まる番号を入力してください。",
    "MESG-E186" : "市外局番と市内局番は合わせて6桁となるように入力してください。",
    "MESG-E187" : "電話番号は10桁で入力してください。",
    "MESG-E188" : "カンマ（，）は使用できません。",
    "MESG-E189" : "{0}にはカンマ（，）は使用できません。",
    "MESG-E190" : "コミュファ光提供エリアをご確認ください。コミュファ光提供エリアを確認後、「エリア確認済み」にチェックを入れてください。",
    "MESG-E191" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E192" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E193" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E194" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E195" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E196" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E197" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E198" : "{0}はカタカナ・英数記号(引用符、カンマ、機種依存文字を除く)で入力してください。",
    "MESG-E199" : "「進捗連絡先メールアドレス」と「進捗連絡先メールアドレス（確認用)」のメールアドレスが異なっています。<br/>「進捗連絡先メールアドレス(確認用)」には「進捗連絡先メールアドレス」と同じメールアドレスを入力してください。",
    "MESG-E200" : "検索条件に合致する{0}がありません。",
    "MESG-E201" : "該当の{0}が存在しません。",
    "MESG-E202" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E203" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E204" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E205" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E206" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E207" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E208" : "電話番号は合計で10桁以上11桁以内となるように入力してください。",
    "MESG-E209" : "ひらがなで入力してください。",
    "MESG-E210" : "指定された郵便番号が見つかりません。",
    "MESG-E211" : "ひらがな、空白、全角記号(、。・ー「」『』)で入力してください。",
    "MESG-E212" : "文字が正しくありません。",
    "MESG-E213" : "英数字、空白、記号（. _-）で入力してください。",
    "MESG-E214" : "英大文字、数字で入力してください。",
    "MESG-E215" : "英字で入力してください。",
    "MESG-E216" : "{0}には明日以降の日付を入力してください。",
    "MESG-E217" : "カタカナ、括弧で入力してください。",
    "MESG-E218" : "{0}はカタカナ、括弧で入力してください。",
    "MESG-E220" : "契約者情報の変更予約がされているためお手続きができません。予約を取り消すか、予約内容を変更してお手続きください。",
    "MESG-E230" : "現在、郵便番号検索をご利用いただけません。<br/>お手数ですが、しばらくしてから再度お試しいただくか、住所を直接入力してください。",
    "MESG-E240" : "番地号は左詰めで入力してください。",
    "MESG-E250" : "{0}の場合、{1}できません。",
    "MESG-E260" : "{0}は左詰めで入力してください。",
    "MESG-E270" : "入力された登録キーワードは無効です。はじめから手続きをやり直してください。",
    "MESG-E271" : "登録キーワードに誤りがあります。登録キーワードをご確認のうえ、再度入力してください。",
    "MESG-E272" : "登録キーワードの有効期限が切れています。はじめから手続きをやり直してください。",
    "MESG-E300" : "予約情報反映時にエラーが発生しています。",
    "MESG-E387" : "050から始まるIP電話では、当サービスをご利用いただくことができません。他にご登録いただいている電話番号がある場合は、その番号を入力してください。他にご登録電話番号がない場合は、お手数ですが個人のお客さまは「<a href=\"https://support.so-net.ne.jp/ask_select\" class=\"d-blanklink-mark\" target=\"_blank\">So-net サポートデスク</a>」に、法人のお客さまは「<a href=\"https://www.so-net.ne.jp/business/support/inquiry/form_inq/inquiry0.html\" class=\"d-blanklink-mark\" target=\"_blank\">So-net 法人サポートデスク</a>」にご連絡ください。",
    "MESG-E388" : "入力いただいた電話番号からの発信を、指定時間内に確認することができませんでした。再度お手続きいただくか、お手数ですが個人のお客さまは「<a href=\"https://support.so-net.ne.jp/ask_select\" class=\"d-blanklink-mark\" target=\"_blank\">So-net サポートデスク</a>」に、法人のお客さまは「<a href=\"https://www.so-net.ne.jp/business/support/inquiry/form_inq/inquiry0.html\" class=\"d-blanklink-mark\" target=\"_blank\">So-net 法人サポートデスク</a>」にご連絡ください。",
    "MESG-E389" : "該当ユーザー数が表示上限{0}件を超えました(検索結果は{1}件)。上位{0}件しか表示しておりません。<br/>変更したいユーザーIDが表示されていない場合、お手数ですが個人のお客さまは「<a href=\"https://support.so-net.ne.jp/ask_select\" class=\"d-blanklink-mark\" target=\"_blank\">So-net サポートデスク</a>」に、法人のお客さまは「<a href=\"https://www.so-net.ne.jp/business/support/inquiry/form_inq/inquiry0.html\" class=\"d-blanklink-mark\" target=\"_blank\">So-net 法人サポートデスク</a>」にご連絡ください。",
    "MESG-E390" : "接続用IDとユーザーIDパスワードに同じ文字列は指定できません。",
    "MESG-E391" : "メールアドレスとユーザーIDパスワードに同じ文字列は指定できません。",
    "MESG-E392" : "パスワードに誤りがあります。ご利用可能文字は、半角のアルファベット大文字・小文字、数字、-(ハイフン)と_(アンダーバー)です。",
    "MESG-E393" : "パスワードに誤りがあります。先頭の文字は必ずアルファベットあるいは数字にしてください。",
    "MESG-E394" : "パスワードに誤りがあります。必ずアルファベットと数字を混在させてください。",
    "MESG-E395" : "同日内に既に入会証発行手続きを受け付けています。",
    "MESG-E396" : "パスワードは半角8文字以上、16文字以内で入力してください。",
    "MESG-E397" : "パスワードに誤りがあります。ご利用可能文字は、半角のアルファベット大文字・小文字、数字、-(ハイフン)と_(アンダーバー)です。<br/>先頭の文字は必ずアルファベットあるいは数字にしてください。",
    "MESG-E398" : "ユーザーIDとユーザーIDパスワードに同じ文字列は指定できません。",
    "MESG-E399" : "前回の「ユーザーIDの確認」依頼から24時間が経過していないため、ユーザーIDの再確認はできません。<br/>24時間が経過したのち、再度「ユーザーIDの確認」依頼を行ってください。",
    "MESG-E400" : "認証失敗が規定の回数を超えたため、そのURLはご利用できません。",
    "MESG-E401" : "既に再発行処理が完了しているため、そのURLはご利用できません。",
    "MESG-E402" : "期限切れのため、そのURLはご利用できません。",
    "MESG-E403" : "パスワードが変更されていません。新しいパスワードを入力してください。",
    "MESG-E404" : "クレジットカード決済以外のお客さまはオンラインでのパスワード再発行ができません。",
    "MESG-E405" : "申し込み者が未成年の場合は、親権者の同意を得たうえでお申し込みください。",
    "MESG-E406" : "大変申し訳ございませんが、18歳未満のお客さまの入会は承っておりません。",
    "MESG-E407" : "{0}の「同意する」にチェックを入れてください。",
    "MESG-E408" : "「案件ID」が既に登録されています。再度入力内容をご確認のうえ、入力しなおしてください。",
    "MESG-E409" : "お申し込みいただいたご利用場所電話番号で、既に「So-net ADSL (eA)」コースをお申し込みいただいております。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E410" : "開通状態が正しくありません。",
    "MESG-E411" : "NTT回線工事日の予約が可能か確認できませんでした。<br/>再度確認する場合は、ご契約者(NTTフレッツ光回線)情報がNTT固定電話のご契約者をご確認のうえ、修正後に「次のページへ進む」ボタンをクリックしてください。<br/>NTTからの連絡をご希望される場合は「回線工事の希望日を選択せずに、後日NTTからの電話連絡で工事日を決める」を選択し、「次のページへ進む」ボタンをクリックしてください。",
    "MESG-E412" : "「案件ID」が既に登録されています。新たな案件IDは登録出来ない為、代理店区分・案件IDをクリアしてください。",
    "MESG-E420" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E430" : "ワイルドカードを使用する場合は検索語を4文字以上入力してください。",
    "MESG-E440" : "入力した代理店コードは存在しません。",
    "MESG-E441" : "ご指定のコースはご利用できません。<br/>ご指定のコース以外のコースで提供エリアを確認する場合は、｢次のページへ進む｣ボタンをクリックしてください。",
    "MESG-E442" : "ご指定のコースはご利用できません。",
    "MESG-E443" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E444" : "入力したキャンペーンコードは存在しません。",
    "MESG-E445" : "So-net メンバーズコース for Biz のみをお申し込みいただくことは出来ません。<br/>So-net レンタルサーバーHS もしくは BeautyExplorer(TM) 追加機能サービス と同時にお申込みください。",
    "MESG-E446" : "ご指定された電話番号、郵便番号では、ご利用可能なコースはございません。<br/>電話番号、郵便番号を変更して、｢次のページへ進む｣ボタンをクリックしてください。",
    "MESG-E447" : "変更可能な項目がありません。",
    "MESG-E448" : "ワイルドカードを使用する場合は{0}文字以上の検索語が必要です。",
    "MESG-E449" : "{0}には、固定電話の番号を10桁で入力してください。",
    "MESG-E450" : "{0}の市外局番と市内局番は合わせて6桁となるように入力してください。",
    "MESG-E451" : "郵便番号は合わせて7桁となるように入力してください。",
    "MESG-E452" : "{0}の市外局番には0から始まる番号を入力してください。",
    "MESG-E453" : "号を入力して、「次のページへ進む」ボタンをクリックしてください。",
    "MESG-E454" : "「確認」ボタンをクリックして名称をご確認のうえ、「次のページへ進む」ボタンをクリックしてください。",
    "MESG-E455" : "電話番号・郵便番号の組合せが正しくありません。入力した電話番号・郵便番号をご確認ください。",
    "MESG-E456" : "{0}を入力した場合は、{1}は必ず入力してください。",
    "MESG-E457" : "{0}でご利用可能なコースはございません。<br/>電話番号、郵便番号を入力して、「次のページへ進む」ボタンをクリックしてください。",
    "MESG-E458" : "ご利用のログインIDでは、エリア入力をスキップできません。<br/>電話番号、郵便番号を入力して、「次のページへ進む」ボタンをクリックしてください。",
    "MESG-E459" : "既に経路専用使用コードに値が登録されております。いったん空欄で登録いただき、エスカレーションにてご相談ください。",
    "MESG-E460" : "{0}がシステムメンテナンス中のためお手続きいただけません。しばらくしてから再度実行してください。",
    "MESG-E500" : "お客さまは本オプションをお申込みできません。",
    "MESG-E501" : "無効なオプションサービスが選択されました。",
    "MESG-E502" : "お客さまは既にサービスをお申し込みいただいております。",
    "MESG-E503" : "現在サービスのご利用はございません。",
    "MESG-E504" : "接続コースのお客さまは、こちらのページではお申し込みいただけません。",
    "MESG-E505" : "こんてんつコースのお客さまは、こちらのページではお申し込みいただけません。",
    "MESG-E506" : "サービスのご利用には、クレジットカード情報の登録が必要です。<br/>クレジットカード情報を<a href=\"https://www.so-net.ne.jp/cgi-bin/cc/nsm/registl/regi_make.cgi\" target=\"_blank\">こちら</a>のページよりご登録後、お申し込みください。",
    "MESG-E507" : "このユーザーIDは、現在ご利用いただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E508" : "ご入力いただいたクレジットカード、デビットカード、プリペイドカードはご利用いただけません。",
    "MESG-E509" : "ご登録されているカードは、現在ご利用いただけません。",
    "MESG-E510" : "カード会社との通信にエラーが発生しました。大変申し訳ございませんが、しばらくしてから再度実行してください。",
    "MESG-E511" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E512" : "お客さまは、この画面からマカフィー セキュリティサービスの{0}のお手続きはできません。<br/><a href=\"http://www.so-net.ne.jp/option/security/mcafee/index.html?page=tab_apply\">こちら</a>よりマカフィー セキュリティサービスの手続きをしてください。",
    "MESG-E513" : "いずれかのサービスを選択してください。",
    "MESG-E514" : "{0}のお申し込み手続き中です。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E515" : "お客さまは{0}を解約されているか、解約手続き中です。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E516" : "既に本サービスはキャンセル済みです。",
    "MESG-E517" : "既に本サービスは利用開始済みです。<br/>キャンセルはできません。",
    "MESG-E518" : "ご利用状況に不備があるため現在お手続きができません。",
    "MESG-E519" : "お手続き中に月が変わりましたので、一旦お手続きを中止します。<br/>お手数ですが最初の画面に戻り、再度お手続きください。",
    "MESG-E520" : "お客さまは追加オプションサービスに申し込まれているため、{0}のお手続きができません。",
    "MESG-E521" : "{0}は、現在提供を行っておりません。<br/>お手数ですが、再度選択しなおしてください。",
    "MESG-E522" : "{0}と{1}の組合せが正しくありません。<br/>お手数ですが、再度選択しなおしてください。",
    "MESG-E523" : "お客さまが現在{0}可能な{1}はございません。",
    "MESG-E524" : "現在、WiMAX対応機器の初期不良交換中のため、{0}はお申し込みいただけません。<br/>初期不良交換後、再度お申し込みください。",
    "MESG-E525" : "現在、機器購入のお申し込み手続き中のため、{0}はお申し込みいただけません。<br/>購入機器をお受取後、再度お申し込みください。",
    "MESG-E526" : "現在、端末交換のお申し込み手続き中のため、{0}はお申し込みいただけません。<br/>端末交換完了後、再度お申し込みください。",
    "MESG-E527" : "レンタル機器の{0}は行えません。<br/>現在ご利用中のSo-net モバイル WiMAXを解約後、再度お申し込みください。",
    "MESG-E528" : "現在、「So-net モバイル WiMAX」のお申し込み手続き中、または利用停止中のため、機器交換はお申し込みいただけません。",
    "MESG-E529" : "現在、「So-net モバイル WiMAX」のお申し込み手続き中のため、端末交換はお申し込みいただけません。<br/>「So-net モバイル WiMAX」ご利用開始後、再度お申し込みをください。",
    "MESG-E530" : "お客さまのお申し込みいただいた機器は、既に「So-net モバイル WiMAX」でご利用中です。",
    "MESG-E531" : "お客さまがご利用の固定IPコースでは、現在、固定IPアドレスの在庫がありません。<br/>1週間程で、ＩPアドレスをご用意致しますので、改めてお申し込みください。",
    "MESG-E532" : "提供エリアでは選択可能なコースがありません。サポートデスクまでお問い合わせください。",
    "MESG-E533" : "お客さまのお申し込みコースでは、本オプションはお申し込みいただけません。",
    "MESG-E534" : "お客さまが指定された固定IPサービスは、既に設定が行われています。",
    "MESG-E535" : "固定IPサービスは、ユーザ毎に最大２ＩＤまでしかご利用できません。",
    "MESG-E536" : "セキュリティ対策の一環として、ご入会後の審査を実施させていただいているため、お申し込みいただけません。<br/>審査には、数日かかることがございます。<br/>お手数ですが、数日たってから改めてお申し込みください。",
    "MESG-E537" : "このサービスは、本会員および法人管理者の方のみご利用可能です。",
    "MESG-E538" : "お客さまは、接続コースと同時にマカフィー マルチ デバイス セキュリティをお申し込みいただいております。<br/>ご利用開始前に{0}のお手続きはできません。<a href=\"http://www.so-net.ne.jp/option/security/mcafee/index.html?page=tab_apply#D\">こちら</a>よりご利用開始のお手続きをお申し込みください。",
    "MESG-E539" : "「{0}」は{1}のお客さまのみご利用可能です。{2}のお客さまはお申し込みいただけません。",
    "MESG-E540" : "ファミリーパックをご利用のお客さまは、本会員のみお申し込みいただけます。",
    "MESG-E541" : "月初処理中のためエラーが発生いたしました。<br/>しばらくしてから、再度実行してください。",
    "MESG-E542" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E543" : "現在{0}可能な状態ではございません。",
    "MESG-E544" : "現在{0}可能な状態ではございません。サービス開始後にお申し込みください。",
    "MESG-E545" : "ご利用先の建物では、フレッツ・テレビをご利用できません。",
    "MESG-E546" : "プラン変更の場合は、このオプションはお申し込みできません。",
    "MESG-E547" : "コミュファ光回線のお申し込みをSo-net経由で行わない場合は、このオプションはお申し込みできません。",
    "MESG-E548" : "コース変更と同時にオプションをお申し込みいただく場合、先にお申し込みいただくコースを選択してください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"http://www.so-net.ne.jp/access/\">こちら</a>よりお手続きください。<br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/\">こちら</a>よりお手続きください。",
    "MESG-E549" : "本ページは、個人会員向けのお申し込みページです。お手数ですが、 <a href=\"http://www.so-net.ne.jp/business/\">こちらのページ</a>からお手続きをお願いします。",
    "MESG-E550" : "本ページは、法人会員向けのお申し込みページです。お手数ですが、 <a href=\"http://www.so-net.ne.jp/access/\">こちらのページ</a>からお手続きをお願いします。",
    "MESG-E551" : "「So-net モバイル WiMAX」の解約月は、お申し込みいただけません。<br>翌月以降、再度お申し込みください。",
    "MESG-E701" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E702" : "{0}は必須項目です。",
    "MESG-E703" : "カード種別とカード番号の桁数の組み合わせが正しくありません。",
    "MESG-E704" : "カード種別とカード番号の頭数字の組み合わせが正しくありません。",
    "MESG-E705" : "カード情報に誤りがあります。",
    "MESG-E706" : "カード情報に誤りがあります。",
    "MESG-E707" : "ご入力いただいたクレジットカード、デビットカード、プリペイドカードはご利用いただけません。",
    "MESG-E708" : "携帯電話番号の桁数が正しくありません。",
    "MESG-E709" : "入力された携帯電話番号は登録できません。",
    "MESG-E710" : "ご契約電話番号の桁数が正しくありません。",
    "MESG-E711" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E712" : "「パスワード」と「パスワード（再入力）」が一致しません。",
    "MESG-E713" : "ユーザーIDとユーザーIDパスワードに同じ文字列は指定できません。",
    "MESG-E714" : "入力されたユーザーIDは既に使用されているため、登録できません。",
    "MESG-E715" : "ユーザーIDに誤りがあります。６文字以上、３２文字以内で入力下さい。",
    "MESG-E716" : "市外局番は、6桁以内で入力してください。",
    "MESG-E717" : "{0}は、4桁以内で入力してください。",
    "MESG-E718" : "{0}に携帯電話、PHS、IP電話（010～090で始まる電話番号）を入力する場合、11桁で入力してください。",
    "MESG-E719" : "{0}は、10桁で入力してください。",
    "MESG-E720" : "{0}にはフリーダイヤル（0120、0800で始まる電話番号）を入力できません。",
    "MESG-E721" : "ユーザーIDまたは、ユーザーIDパスワードが正しくありません。",
    "MESG-E722" : "入力されたユーザーIDはご利用になれません。",
    "MESG-E723" : "ユーザーIDに誤りがあります。.(ドット)の連続は指定できません。",
    "MESG-E724" : "ユーザーIDに誤りがあります。最後尾に.(ドット)を指定できません",
    "MESG-E725" : "パスワードに誤りがあります。以下の内容をご確認ください。　文字数：8文字以上、16文字以内　ご利用可能文字：半角のアルファベット大文字・小文字、数字、-(ハイフン)、_(アンダーバー)　　　　　　　　　必ずアルファベットと数字を混在させてください。　　　　　　　　　ユーザーIDと同じ値は指定できません　先頭文字：アルファベットまたは数字",
    "MESG-E726" : "お客さまは現在KDDI請求の申し込み手続き中のため、支払方法の変更はご利用いただけません。",
    "MESG-E727" : "お客さまの現在のご利用状態では、支払方法の変更はご利用いただけません。",
    "MESG-E728" : "お客さまの現在のご利用状態では、NTT請求はお申し込みいただけません。",
    "MESG-E729" : "ユーザーIDに誤りがあります。ご利用可能文字は、半角のアルファベット小文字、数字、-(ハイフン)、_(アンダーバー)と.(ドット)です。",
    "MESG-E730" : "ユーザーIDに誤りがあります。先頭の文字はアルファベット小文字のみご利用可能です。",
    "MESG-E731" : "入力されたログインIDではご利用できません。",
    "MESG-E732" : "{0}が入力・選択されていません。",
    "MESG-E733" : "{0}には{1}以下の整数を入力して下さい。",
    "MESG-E734" : "{0}には整数部：{1}以下、小数部：{2}以下の数値を入力して下さい。",
    "MSTM-E800" : "{0}が存在しません。再度一覧検索から実行して下さい。",
    "MSTM-E801" : "代理店コードは、半角英数字のカンマ区切りで入力してください。",
    "MSTM-E805" : "{0}を入力・選択しない場合は、{1}の入力・選択はできません。",
    "MSTM-E809" : "選択コース:{0}内で表示順が重複しています。",
    "MSTM-E810" : "会員区分料金表示コース変換が重複しています。",
    "MSTM-E811" : "新規登録の場合、会員区分と選択コースは両方入力して下さい。",
    "MSTM-E812" : "検索の場合、会員区分と選択コースは少なくとも一方には入力して下さい。",
    "MSTM-E813" : "選択コースが存在しません。選択コース:{0}",
    "MSTM-E814" : "オプション分類が存在しません。オプション分類:{0}",
    "MSTM-E815" : "登録対象のマスタ情報には、既に予約情報が存在するため登録できません。",
    "MSTM-E816" : "登録対象のマスタ情報には、重複する適用終了日更新済の期間が存在します。",
    "MSTM-E817" : "登録対象のマスタ情報は、既に存在します。",
    "MSTM-E818" : "{0}の登録処理に失敗しました。",
    "MSTM-E819" : "{0}の更新処理に失敗しました。",
    "MSTM-E820" : "{0}の削除処理に失敗しました。",
    "MSTM-E821" : "表示順のみが入力されています。選択コース：{0}",
    "MSTM-E826" : "案件IDをチェックしない場合、代理店区分は選択出来ません。",
    "MSTM-E827" : "選択コースが選択されていません。",
    "MSTM-E828" : "おすすめオプションが選択されていません。",
    "MSTM-E829" : "販路が存在しません。",
    "MSTM-E830" : "選択コースが存在しません。",
    "MSTM-E831" : "オプション分類が存在しません。",
    "MSTM-E832" : "代理店アカウントが存在しません。",
    "MSTM-E833" : "メンテナンス対象が存在しません。",
    "MSTM-E834" : "会員区分が存在しません。",
    "MSTM-E835" : "料金シミュレーション表示コースが存在しません。",
    "MSTM-E836" : "料金シミュレーション用コース基本料金が存在しません。",
    "MSTM-E837" : "料金シミュレーション用オプション基本料金が存在しません。",
    "MSTM-E838" : "選択オプションが存在しません。",
    "MSTM-E839" : "料金シミュレーション用キャリアキャンペーンが存在しません。",
    "MSTM-E840" : "コース分類が存在しません。",
    "MSTM-E841" : "選択コースが存在しません。",
    "MSTM-E842" : "料金シミュレーション表示コースが存在しません。",
    "MSTM-E843" : "会員区分料金表示コース変換が存在しません。",
    "MSTM-E844" : "オプション分類が存在しません。",
    "MSTM-E845" : "選択オプション種別が存在しません。",
    "MSTM-E846" : "選択オプションが存在しません。",
    "MSTM-E847" : "案件IDがチェック済の場合、代理店区分を選択してください。",
    "MSTM-E848" : "販路区分が存在しません。",
    "MSTM-E849" : "支払先が存在しません。",
    "MSTM-E850" : "月額固定有料サービスコンテンツを決済情報なし会員許可ＯＫで登録できません。",
    "MSTM-E861" : "取引先情報が存在しません。",
    "MSTM-E862" : "販路区分が選択されています。",
    "MSTM-E865" : "資本金に0円以外が入力されています。",
    "MSTM-E866" : "年商に0円以外が入力されています。",
    "MSTM-E867" : "社員数に0人以外が入力されています。",
    "MSTM-E868" : "削除対象は支払先マスタに存在します。",
    "MSTM-E869" : "削除対象は代理店マスタに存在します。",
    "MSTM-E870" : "代理店コードが存在しません。",
    "MSTM-E871" : "取扱可能支払方法が存在しません。",
    "MSTM-E872" : "同じログインIDを保持する代理店アカウントが複数存在します。",
    "MSTM-E873" : "パスワードに使用できない文字が含まれています。",
    "MSTM-E874" : "入力した代理店コードは存在しません。{0}",
    "MSTM-E875" : "初期費用の表示順が重複しています。",
    "MSTM-E876" : "月額費用の表示順が重複しています。",
    "MSTM-E877" : "指定ファイルが存在しません。",
    "MSTM-E878" : "指定ファイルのファイル名が{0}文字を超えています。",
    "MSTM-E879" : "指定ファイルの拡張子が{0}ではありません。",
    "MSTM-E880" : "指定ファイルのファイルサイズが{0}を超えています。",
    "MSTM-E881" : "指定ファイルのオープンに失敗しました。",
    "MSTM-E882" : "指定ファイルの読み込みに失敗しました。",
    "MSTM-E883" : "指定ファイルのクローズに失敗しました。",
    "MSTM-E884" : "{0}件目の{1}はその他の{1}と重複しています。",
    "MSTM-E885" : "取込キーワードが一致しません。",
    "MSTM-E886" : "指定ファイルの行数が{0}行を超えています。",
    "MSTM-E887" : "検索の場合、コース分類とキャリアキャンペーン管理番号は少なくとも一方には入力して下さい。",
    "MSTM-E888" : "{0}の取込が正常に完了しました。処理件数：{1}",
    "MSTM-E889" : "代理店権限が検索で案件IDにチェックが入力されています。",
    "MSTM-E890" : "適用期間(from)(to)の前後関係が不正です。",
    "MSTM-E892" : "指定ファイルの行数が{0}行未満です。",
    "MSTM-E893" : "マスタメンテナンスを開始した日付と実行した日付が異なります。検索画面から再度実行してください。",
    "MSTM-E894" : "登録種別が新規の場合、選択コース種別/選択コースを選択してください。",
    "MSTM-E895" : "登録種別が新規の場合、料金シミュレーション表示コース名称を入力してください。",
    "MSTM-E896" : "登録種別が既存の場合、料金シミュレーション表示コースを選択してください。",
    "MSTM-E897" : "金額変動フラグが未チェックの場合は、MAX(金額)に入力できません。",
    "MSTM-E898" : "選択オプション種別内で表示順が重複しています。",
    "MSTM-E899" : "{0}を入力・選択した場合は、{1}の入力・選択はできません。",
    "MESG-E900" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E901" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E902" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E903" : "{0}は{1}文字で入力してください。",
    "MESG-E904" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E905" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E906" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E907" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E908" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E909" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E910" : "カートの有効期限が切れているため、お手続きを継続できません。<br/>お手数ですが最初の画面に戻り、再度お申し込みください。",
    "MESG-E911" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E912" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E913" : "「カード名義人生年月日」には会員の方の生年月日と同じ日付を入力してください。<br/>So-netに登録される生年月日とカード会社に登録されている生年月日は一致している必要があります。",
    "MESG-E914" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E915" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E916" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E917" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E918" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E919" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E920" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E921" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E922" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-F001" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-F002" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-I001" : "ご利用中のオプションサービス、コンテンツサービスはありません。",
    "MESG-I002" : "登録が完了しました。",
    "MESG-I003" : "入力いただいたメールアドレスに再発行URLをお送りいたしました。",
    "MESG-I004" : "パスワードの再設定が完了しました。",
    "MESG-I005" : "本お手続きは、（月額有料）のファミリー会員を追加するお手続きですがよろしいですか？※3名まで無料でユーザーIDを追加できるファミリーパックのお申し込みとは異なります。上記お手続きを行いたい場合は、ファミリーパックをお申し込みください。",
    "MESG-I006" : "利用料金は発生していません。",
    "MESG-I007" : "適用されるキャンペーンはありません。",
    "MESG-I008" : "{0}を契約されていません。",
    "MESG-I009" : "変更ボタンから、お申込サービスを再度選択して下さい。",
    "MESG-I010" : "現在サービスのご利用はございません。",
    "MESG-I011" : "ユーザーID、パスワード、接続やメールに関する情報は後日送付する入会証でご確認ください。",
    "MESG-I012" : "So-net モバイル WiMAXのお申し込みを受け付けました。<br/>So-net モバイル WiMAXをご利用いただくための設定を行いますので、電波状況のよい場所で、設定完了までお待ちください。<br/>※電波状況によっては、多少お時間がかかる場合がございます。",
    "MESG-I013" : "So-net モバイル WiMAXのお申し込みを受け付けました。<br/>・本サービスには最低利用期間があります。詳細はメールにてご連絡いたしますので、ご確認ください。<br/>・WiMAX対応機器を受領されない場合は、自動的にお申し込みをキャンセルといたします。<br/>・WiMAX対応機器お届け時の箱は、ご返却時に必要になりますので、紛失されないよう保管をお願いいたします。",
    "MESG-I014" : "So-net モバイル WiMAXのお申し込みを受け付けました。<br/>・WiMAX対応機器を受領されない場合は、自動的にお申し込みをキャンセルといたします。",
    "MESG-I015" : "・WiMAX対応機器を受領されない場合は、自動的に機器購入のお申し込みをキャンセルといたします。<br/>（So-net モバイル WiMAXは引き続きご利用いただけます。）",
    "MESG-I016" : "＜So-net モバイル WiMAX Flat 年間パスポートをお申し込みのお客さま＞<br/>・1年単位で自動更新されるプランです。<br/>・契約更新月以外で解約される場合は、年間契約違約金を請求いたします。あらかじめご了承ください。",
    "MESG-I017" : "＜キャンペーンの内容確認＞<br/>お申し込みいただいたサービスのキャンペーンは以下のURLでご確認いただけます。<br/>適用キャンペーン確認画面： <a href=\"http://www.so-net.ne.jp/cp/\" target=\"_blank\">http://www.so-net.ne.jp/cp/</a>",
    "MESG-I018" : "会社情報は登録されていません。",
    "MESG-I020" : "以下の{0}を取り消しますが、よろしいですか？",
    "MESG-I021" : "※お支払い方法を「NTT請求でのお支払い」または「KDDI請求でのお支払い」に変更した場合<br/><br/>NTTおよびKDDIでの手続きが完了するまでは、マイページ上では<br/>変更前のお支払い方法が表示されます。あらかじめご承知おきください。",
    "MESG-I400" : "{0}はご利用いただけません。",
    "MESG-I401" : "既に{0}を申し込んでいます。",
    "MESG-I451" : "<p style=\"display: table-cell; vertical-align: middle;\"><img src=\"../img/share/circle.png\" alt=\"お申し込みいただけます\"/></p><p style=\"display: table-cell; vertical-align: middle;\">ご指定の住所で、ご希望のコースをお申し込みいただけます。<br/>下記内容でよろしければ「次のページへ進む」ボタンをクリックしてください。</p>",
    "MESG-I452" : "<p style=\"display: table-cell; vertical-align: middle;\"><img src=\"../img/share/circle.png\" alt=\"お申し込みいただけます\"/></p><p style=\"display: table-cell; vertical-align: middle;\">ご希望のコースをお申し込みいただけます。<br/>下記内容でよろしければ「次のページへ進む」ボタンをクリックしてください。</p>",
    "MESG-I453" : "ご指定の住所では、ご希望のコースをお申し込みいただけません。",
    "MESG-I454" : "<p style=\"display: table-cell; vertical-align: middle;\"><img src=\"../img/share/circle.png\" alt=\"お申し込みいただけます\"/></p><p style=\"display: table-cell; vertical-align: middle;\">ご指定の住所で、ご希望のコースをお申し込みいただけます。<br/>下記内容でよろしければ「次のページへ進む」ボタンをクリックしてください。</p>",
    "MESG-I456" : "新規にフレッツ光回線を申し込む",
    "MESG-I457" : "フレッツ光回線を申し込まない",
    "MESG-I458" : "固定電話番号を持っている",
    "MESG-I459" : "固定電話番号を持っていない",
    "MESG-I460" : "お申し込みには接続コースの選択が必要です。選択したオプションでご利用可能なコースを検索します。",
    "MESG-I461" : "以下の電話番号・郵便番号をもとに、サービス提供状況を表示しています。",
    "MESG-I462" : "{0}を選択した場合は、{1}の選択が必須となります。",
    "MESG-I463" : "{0}の個数を選択してください。",
    "MESG-I464" : "{0}の合計個数は{1}～{2}の範囲内で選択してください。",
    "MESG-I465" : "{0}を選択した場合は、{1}は必ず入力してください。",
    "MESG-I466" : "商品コード{0}は存在しません。",
    "MESG-I467" : "入力された電話番号は登録番号と一致しません。ご確認のうえ、再度入力してください。",
    "MESG-I468" : "入力された電話番号は登録されていないため継続利用できません。",
    "MESG-I469" : "入力された電話番号は、継続してご利用いただけない電話番号です。",
    "MESG-I470" : "選択ずみのサービスはすべて削除されますが、<br/>よろしいですか？",
    "MESG-I471" : "ご利用のエリアでは、auひかり電話がご利用いただけません。",
    "MESG-I472" : "商品コードが重複しています。",
    "MESG-I473" : "選択された接続コースでは、一部のオプションサービスをお申し込みいただけません。<br/>下記の内容をご確認いただき、いずれかの接続コースを選択してください。",
    "MESG-I474" : "選択されたオプションサービスは、お申し込みいただけません。<br/>「OK」ボタンをクリックした後、他のオプションを選択しなおすか、本オプションが利用できるコースを選択しなおした後、改めて本オプションをお申し込みください。",
    "MESG-I476" : "検索結果が上限{0}件を超えました(検索結果は{1}件)。上位{0}件しか表示されていませんので、検索条件を変えて再検索してください。",
    "MESG-I477" : "お客さまは、auひかり電話を2回線ご契約しているため、電話番号の継続利用をお申し込みいただけません。<br/>1番号のみ単独で継続利用でご解約後、再度お申し込みください。",
    "MESG-I478" : "未入力",
    "MESG-I479" : "{0} を取り消すと、{1} が適用されなくなりますが、よろしいですか？",
    "MESG-I480" : "KDDI電話auで着信確認にチェックをしてください。",
    "MESG-I481" : "{0}を選択した場合、{1}のお申し込みはできません。",
    "MESG-I482" : "{0}時点では選択されたサービスの受付が終了しました。<br/>｢変更｣ボタンから、お申し込みサービスを再度選択してください。<br/>【対象サービス：{1}】",
    "MESG-I483" : "{0}時点では選択されたサービスの受付が終了しました。<br/>｢接続コースを選びなおす｣ボタンから、お申し込みサービスを再度選択してください。<br/>【対象サービス：{1}】",
    "MESG-I484" : "ご利用場所の郵便番号と入力された「継続利用する電話番号」の組合せが一致しません。ご確認のうえ、再度入力してください。",
    "MESG-I485" : "割引パックを選択した場合、発信者番号表示サービス／非通知着信拒否サービス／割込電話サービス／迷惑電話拒否サービス／転送電話サービスのお申し込みはできません。",
    "MESG-I486" : "商品コードに「7D」を入力することはできません。",
    "MESG-I487" : "{0}には、{1}が含まれているため、付加サービスのチェックをはずしてください。",
    "MESG-I489" : "入力された電話番号は、電話番号を継続利用できないエリアか、または継続できない電話番号のため、お申し込みいただけません。<br/>新しい電話番号でのお申し込みのみとなります。",
    "MESG-I490" : "番号通知リクエストサービスのご利用には、番号表示サービスへのお申し込みが必要です。",
    "MESG-I491" : "入力された電話番号は登録番号と一致しません。ご確認のうえ、再度入力してください。 (2番号目)",
    "MESG-I492" : "入力された電話番号は登録されていないため継続利用できません。 (2番号目)",
    "MESG-I493" : "入力された電話番号は、継続してご利用いただけない電話番号です。 (2番号目)",
    "MESG-I494" : "ご利用場所の郵便番号と入力された「継続利用する電話番号」の組合せが一致しません。ご確認のうえ、再度入力してください。 (2番号目)",
    "MESG-I495" : "ご利用のエリアでは、auひかり電話がご利用いただけません。 (2番号目)",
    "MESG-I496" : "ご指定の物件は、NTT東日本とオーナー様もしくは管理会社様にて個別サービスを提供中もしくは提供予定となっております。<br />お手数ですが、お申込についてはオーナー様もしくは管理会社様へお問合せいただきますようお願いいたします。",
    "MESG-I721" : "カード認証に成功しました。",
    "MESG-I722" : "入力内容が破棄されますがよろしいですか？",
    "MSTM-I802" : "登録が完了しました。",
    "MSTM-I803" : "更新が完了しました。",
    "MSTM-I804" : "削除が完了しました。",
    "MSTM-I823" : "会員区分が存在しません。会員区分:{0}",
    "MSTM-I824" : "選択オプション種別が存在しません。選択オプション種別:{0}",
    "MSTM-I825" : "入力内容を確認したうえで、「登録」ボタンをクリックしてください。",
    "MSTM-I891" : "内容を確認したうえで、「削除」ボタンをクリックしてください。",
    "MESG-I900" : "<div class=\"warning\">●退会処理が完了しました({0}月末日付け退会)</div><div class=\"d-news-l\">ご利用機器の返却先や退会後のご請求の流れについて、下記ページでご紹介しておりますのでご参照ください。<br/><a href=\"https://www.so-net.ne.jp/support/taikai/after/?SmRint=mp\" class=\"linkBlank\" target=\"_blank\">退会手続き後の流れ</a></div>",
    "MESG-I901" : "<div class=\"warning\">●ユーザーID解約処理が完了しました({0}月末日付け解約)</div><div class=\"d-news-l\">ご利用機器の返却先については下記ページをご参照ください。<br/><a href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000009234\" class=\"linkBlank\" target=\"_blank\">レンタル機器はどこに返却すればよいですか (モデムルーター SIM カード)</a></div>",
    "MESG-I902" : "ご契約全ての退会手続きを{0}月末にて受け付けました。",
    "MESG-I903" : "<div class=\"warning\">●退会のお申し込みを受け付けました（{0}月末日付け退会予定）</div><div class=\"d-news-l\">退会手続き後の流れやご利用機器の返却先について、下記ページでご紹介しておりますのでご参照ください。<br/><a href=\"https://www.so-net.ne.jp/support/taikai/after/?SmRint=mp\" class=\"linkBlank\" target=\"_blank\">退会手続き後の流れ</a></div>",
    "MESG-I904" : "<div class=\"warning\">●ユーザーID解約のお申し込みを受け付けました（{0}月末日付け解約予定）</div><div class=\"d-news-l\">ご利用機器の返却先については下記ページをご参照ください。<br/><a href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000009234\" class=\"linkBlank\" target=\"_blank\">レンタル機器はどこに返却すればよいですか (モデムルーター SIM カード)</a></div>",
    "MESG-I905" : "入力された内容が破棄されます。よろしいですか。",
    "MESG-W001" : "お手続きを継続できません。全てのブラウザを終了させ、再度お手続きください。",
    "MESG-W002" : "アップロードされたファイルのサイズがファイルサイズの上限を超えていました。",
    "MESG-W401" : "お客さまのお名前で既にお申し込みいただいております。新しくお申し込みいただける場合は「申し込む」ボタンをクリックしてください。<br/>お申し込みされた覚えがない、もしくは、入会証がお手元に届いていない場合は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-W402" : "お客さまは{0}をご利用いただけません。",
    "MESG-W440" : "不正な操作が行われました。",
    "MESG-W441" : "入力したキャンペーン適用基準日は前年以前のものです。処理を続けますか。",
    "MESG-W477" : "提供可能エリアがありません。",
    "MESG-W480" : "入力したキャンペーン適用基準日は30日以上前のものです。処理を続けますか。",
    "MESG-W481" : "申し訳ございませんが、料金のご案内ができません。お申し込み手続きは引き続き行えます。",
    "MSTM-W806" : "適用期間の間に空白の期間が作成されます。",
    "MSTM-W807" : "入力内容は即時に適用されます。",
    "MSTM-W808" : "現在適用中の情報は即時に終了します。",
    "MSTM-W851" : "決済情報なし会員許可をＯＫからＮＧに変更します。",
    "MSTM-W852" : "サービス番号が存在しません。",
    "MSTM-W853" : "サービスが既に登録されています。",
    "MSTM-W854" : "サービスが既に更新されています。最新の情報を取得して下さい。",
    "MSTM-W855" : "更新対象が存在しません。最新の情報を取得して下さい。",
    "MSTM-W856" : "グループ番号が存在しません。",
    "MSTM-W857" : "削除対象サービスは現在使用中です。",
    "MSTM-W858" : "削除対象サービスは履歴として使用中です。",
    "MSTM-W859" : "システムエラーが発生しました。",
    "RNSV-E001" : "お客さまのユーザーIDで、レンタルサーバに利用可能なドメインはございません。",
    "RNSV-E002" : "システムメンテナンス中のためお手続きいただけません。<br/>しばらくしても状況が変わらない場合は、So-net法人サポートデスクまでお問い合わせください。",
    "RNSV-E003" : "ドメイン管理（DNS）サービス解約中のため、お客さま指定のドメインではお申し込みいただけません。",
    "RNSV-E004" : "選択されたドメインは既にレンタルサーバサービスでご利用されています。",
    "RNSV-E005" : "ドメイン名に使用できない文字が含まれています。<br/>再度入力してください。",
    "RNSV-E006" : "お客さまのドメインはSo-netに移行できません。",
    "RNSV-E007" : "ご指定いただきましたドメインは、So-netで取得されたドメインです。<br/>前画面に戻り『(A) So-netで取得済みのドメインでレンタルサーバを利用する』<br/>を選択していただきお申し込みください。",
    "RNSV-E008" : "ご指定いただきましたドメインは、無効です。再度入力してください。",
    "RNSV-E009" : "ドメイン管理（DNS）サービス申し込み中のため、ご指定いただきましたドメインではお申し込みいただけません。",
    "RNSV-E010" : "入力されたドメインは使用できません。<br/>お手数ですが、再度ドメイン名を入力して、「検索」ボタンをクリックしてください。",
    "RNSV-E011" : "ドメイン属性を判定できません。",
    "RNSV-E012" : "ドメインを管理するネームサーバがSo-netのサーバでないため、使用できません。<br/>dnss10.so-net.ne.jp/dnss11.so-net.ne.jpを管理するネームサーバに設定してください。",
    "RNSV-W002" : "レンタルサーバのDNS設定に必要なドメインのAレコードが、既に登録されています。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "RNSV-W003" : "レンタルサーバのDNS設定に必要なSMTPのAレコードが、既に登録されております。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "RNSV-W004" : "レンタルサーバのDNS設定に必要なPOPのAレコードが、既に登録されております。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "RNSV-W005" : "レンタルサーバのDNS設定に必要なドメインのMXレコードが、既に登録されています。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "RNSV-W006" : "レンタルサーバのDNS設定に必要なサブドメインのAレコードが、既に登録されております。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "SAEA-I400" : "NTT固定電話をお持ちでない方は、近隣の電話番号の下3桁を000にして入力してください。",
    "WMAX-I001" : "本サービスの解約のお申し込みを承っております。",
    "MB3G-E001" : "{0}にはフリーダイヤル、携帯電話、PHS、IP電話（0120、0800、010～090で始まる電話番号）を入力できません。",
    "MESG-E601" : "選択されたコースへのコース変更はお申し込みいただけません。前のページに戻り、別のコースを選択してください。<br/>※こんてんつコース会員の方は、<a href=\"https://www.so-net.ne.jp/mypage\">「マイページ」</a>の「コース変更手続き」ボタンから別のコースを選択してください。",
    "MESG-E602" : "選択されたコースへのコース変更はお申し込みいただけません。前のページに戻り、別のコースを選択してください。",
    "MESG-E603" : "入力された「ユーザーID」または「ユーザーIDパスワード」が見つかりません。<br/>「ユーザーID」と「ユーザーIDパスワード」をご確認のうえ、再度入力してください。",
    "MESG-E604" : "お客さまのユーザーIDでは、お手続きを申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E605" : "入力されたユーザーIDはご利用になれません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E606" : "入力されたユーザーIDはご利用になれません。",
    "MESG-E607" : "入力されたユーザーIDはご利用になれません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E608" : "入力されたユーザーIDはご利用になれません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E609" : "入力されたユーザーIDは退会の申請を承っております。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E610" : "入力されたユーザーIDは解約の申請を承っております。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E611" : "こんてんつコースへのコース変更のお申し込みを承っておりますので、お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E612" : "アクセスパックをご利用のお客さまのコース変更は受け付けておりません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E613" : "ファミリーパックをご利用のお客さまは、本会員のユーザーIDでお申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E614" : "ファミリーパックをご利用中のため、入力されたユーザーIDでのお申し込みは受け付けできません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E615" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E616" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E617" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E618" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E619" : "お客さまのユーザーIDでは、現在、選択されたサービスをご利用になれません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E620" : "ファミリーパックをご利用中のため、選択されたコースへのコース変更はお申し込みいただけません。<br/>前のページに戻り、別のコースを選択してください。<br/>ファミリーパックに対応していないコースへの変更は、ファミリーパックの利用停止または解約のお手続き後、お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a>",
    "MESG-E621" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E622" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E623" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E624" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E625" : "回線移転のお申し込みを承っているため、お申し込みいただけません。<br/>ご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E626" : "「So-net ADSL (eA)」にて「無線LANカードレンタル」のお申し込みを承っているため、お申し込みいただけません。<br/>お手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E627" : "「So-net ADSL (eA)」の「無線LANカードレンタル」の解約手続き中のため、お申し込みいただけません。<br/>解約手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E628" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E629" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E630" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E631" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E632" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E633" : "「So-net フォン」のお申し込みを承っているため、選択されたコースへの変更をお申し込みいただけません。<br/>So-netフォン開通後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E634" : "「So-net フォン」解約手続き中のため、選択されたコースへの変更をお申し込みいただけません。<br/>So-netフォン解約手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E635" : "現在コース変更のお申し込みを承っているため、お申し込みいただけません。<br/>翌月以降に再度お申し込みください。<br/>当月中にお申し込みされたい場合は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E636" : "「無線LANカードレンタル」サービスのお申し込みを承っているため、お申し込みいただけません。<br/>「無線LANカードレンタル」サービス解約後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E637" : "現在KDDI請求のお申し込みを承っているため、お申し込みいただけません。<br/>お申し込みいただくためには、KDDI請求のお申し込みをキャンセルしていただく必要がございます。<br/>KDDI請求のお申し込みキャンセルをご希望のお客さまは、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E638" : "現在KDDI請求のお申し込みを承っているため、お申し込みいただけません。<br/>お申し込みいただくためには、KDDI請求のお申し込みをキャンセルしていただく必要がございます。<br/>KDDI請求のお申し込みキャンセルをご希望のお客さまは、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E639" : "回線移転のお申し込みを承っているため、お申し込みいただけません。<br/>お手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E640" : "移転元の「So-net 光 (auひかり)」がご利用開始された月は、「So-net 光 (auひかり)」の回線移転をお申し込みいただけません。<br/>翌月以降、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E641" : "移転元の「So-net 光 (auひかり)」がご利用開始されていないため、「So-net 光 (auひかり)」の回線移転をお申し込みいただけません。<br/>お手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E642" : "「So-net 光 (auひかり)」のプラン変更のお申し込みを承っているため、お申し込みいただけません。<br/>お手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E643" : "「So-net 光 (auひかり)」のプラン変更のお申し込みを承っているため、お申し込みいただけません。<br/>お手続き完了後、再度お申し込みください。<br/>ご不明な点は、ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E644" : "お客さまは、「So-net 光 (auひかり)」コースをご利用いただいていません。<br/>プラン変更は、「So-net 光 (auひかり)」コースをご利用中のお客さまのみお申し込みいただけます。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E645" : "以下に該当する場合は、「So-net 光 (auひかり)」のプラン変更をお申し込みいただけません。<br/>・「So-net 光 (auひかり)」コースをお申し込み後、開通手続き中の場合<br/>・「So-net 光 (auひかり)」コースの開通手続き完了月(サービス開始月)の場合（サービス開始月の翌月よりお申し込みいただけます）。<br/>・「So-net 光 (auひかり)」コースを解約手続き中の場合<br/>・「So-net 光 (auひかり)ホームタイプ」でない場合<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E646" : "既に「So-net 光 (auひかり)」コースへのお申し込みを承っております。<br/>開通までは変更を受け付けておりません。開通後に再度お申し込みください。<br/>お申し込みキャンセルをご希望の場合は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E647" : "お客さまは、本ページからのコース変更がお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E648" : "お客さまは、本ページからのコース変更がお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E649" : "お客さまは、本ページからのコース変更がお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E650" : "「auひかり 電話サービス」のお申し込みを承っているため、お申し込みいただけません。<br/>「auひかり 電話サービス」のお申し込みをキャンセルするか、またはお手続き完了後、再度お申し込みください。<br/>お手続きの詳細に関しましては、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E651" : "「auひかり 電話サービス」のお申し込みを承っているため、お申し込みいただけません。<br/>「auひかり 電話サービス」のお申し込みをキャンセルするか、またはお手続き完了後、再度お申し込みください。<br/>お手続きの詳細に関しましては、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E652" : "お客さまは、本ページからのコース変更がお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E653" : "「So-net ADSL (eA)」コースをご利用いただいていないか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E654" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E655" : "お客さまが現在ご利用中のコースは、速度変更をお申し込みいただけません。<br/>他のコースのご利用をご希望の場合は、コース変更をお申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E656" : "入力された「ユーザーID」または「ご利用場所の電話番号」は既に「So-net ADSL (eA)」コースに申し込まれているか、<br/>「So-net ADSL (eA)」コースをご利用中です。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E657" : "「eAccessオプション」をご利用中のため、「So-net ADSL (eA)」へのコース変更はお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E658" : "「So-net ADSL (eA)」コースへのお申し込みを承っております。<br/>開通までは変更を受け付けておりません。開通後に再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E659" : "ファミリーパックをご利用のお客さまは、本会員のユーザーIDでお申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a>",
    "MESG-E660" : "サービスは選択されておりません",
    "MESG-E661" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E662" : "既に他のコースへのコース変更のお申し込みを承っているため、「So-net ADSL (eA)」コースへはお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E663" : "既に他のコースへのコース変更のお申し込みを承っているため、「So-net ADSL (eA)」コースへはお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E664" : "「So-net 光 (UCOM)」コースお申し込み中の方の移転は受け付けておりません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E665" : "既に他のコースへのコース変更のお申し込みを承っているため、「So-net ADSL (eA)」コースへはお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E666" : "お客さまのご契約内容では、ファミリー会員/法人利用者の追加手続きをご利用になれません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E667" : "選択されたコースへのコース変更はお申し込みいただけません。前のページに戻り、別のコースを選択してください。",
    "TIKI-W001" : "ご利用のコースは、こちらのページから退会のお手続きができません。",
    "TIKI-W002" : "「So-net レンタルサーバサービス」をご利用中のため、退会のお手続きができません。",
    "TIKI-W003" : "「ドメイン取得代行サービス」をご利用中のため、退会のお手続きができません。",
    "TIKI-W004" : "「auひかり 電話サービス」番号ポータビリティ手続き中のため、退会のお手続きができません。",
    "TIKI-W005" : "「auひかり 電話サービス」番号ポータビリティ手続き中のため、退会のお手続きが出来ません。",
    "TIKI-W006" : "「auひかり 電話サービス」を複数回線利用中のため、退会のお手続きができません。",
    "TIKI-W007" : "以下に表示されている利用者のご利用コースを解約後、再度お申し込み下さい。<br />{0}",
    "MESG-E138" : "{0}は有効なURLを入力してください。",
    "MESG-E552" : "ご指定のお申し込み条件では、２４時間出張修理のお申し込みはできません。",
    "MESG-E555" : "現在サービスのご利用はございません。<br/>接続サービスと同時に「マカフィー マルチ デバイス セキュリティ」を申し込まれたお客さまは<a href=\"http://www.so-net.ne.jp/option/security/mcafee/index.html?page=tab_apply#D\">こちら</a>よりお手続きをお願いします。",
    "MESG-E556" : "接続サービスと同時に申し込まれたお客さまは、<a href=\"http://www.so-net.ne.jp/option/support/anshin/index.html?page=tab_apply\">こちら</a>よりキャンセルのお手続きをお願いします。",
    "MSTM-E796" : "{0}に不要な,が含まれています。",
    "MSTM-E797" : "{0}が既に存在する為、登録できません。",
    "MSTM-E798" : "{0}が存在する為、削除できません。",
    "MSTM-E799" : "入力したグループ番号は存在しません。",
    "MSTM-E860" : "{0}場合、{1}と{2}に同じ値は入力出来ません。",
    "MESG-I488" : "{0} を取り消しますが、よろしいですか？",
    "TIKI-W008" : "お手続き中に日付が変わりました。解約希望日を再度ご指定ください。",
    "TIKI-W009" : "以下に表示されている利用者のご利用コースを解約後、再度お申し込み下さい。<br />{0}",
    "TIKI-I010" : "当日の退会を受け付けました。",
    "TIKI-I011" : "翌日の退会処理を受け付けました。",
    "TIKI-E012" : "法人のお客さまは、「<a href=\"http://www.so-net.ne.jp/business/procedure/taikai/index.html#quit\" target=\"_blank\">退会申請用紙</a>」をご請求いただくか、<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>までお問い合わせください。",
    "TIKI-E013" : "管理者以外のお客さまによる退会のお申し込みはできません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E014" : "既に退会のお申し込みを承っておりますので、退会をお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E015" : "既に解約のお申し込みを承っておりますので、解約をお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E016" : "管理者が不在となるため、対象となる会員の解約のお手続きができません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E017" : "既に退会済みのため、お手続きのお申し込みはできません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E018" : "既に退会のお申し込みを承っておりますので、退会をお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E019" : "お客さまは、こちらのページから退会のお手続きができません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E020" : "お客さまは、こちらのページから退会のお手続きができません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "TIKI-E021" : "「auひかり 電話サービス」番号ポータビリティ手続き中のため、退会のお手続きが出来ません。",
    "MESG-E668" : "コース変更手続中のため、この支払方法への変更申し込みはできません。コース変更完了後に再度、支払方法の変更手続きをお願いします。",
    "MESG-E470" : "{0}は選択した{1}に含まれています。<br/>{2}の選択を修正してください。",
    "MESG-E471" : "選択されたオプションの一部またはすべてが{0}に含まれます。<br/>{0}を選択したうえで、必要があればオプションを選択してください。",
    "MESG-E680" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E681" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E682" : "お客さまのユーザーIDでは、現在、選択されたサービスをご利用になれません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E683" : "既に、同一のお客さま名でNURO光の登録があるため、お申し込みいただけません。",
    "MESG-E684" : "既に、同一のお客さま名でNURO光の登録があるため、お申し込みいただけません。<br/>お申し込みいただいた内容を修正する場合は、代理店サポートデスクまでご連絡ください。",
    "MESG-E472" : "アップロードされた画像がありません。再度、画像アップロードを行ってください。",
    "MESG-E473" : "画像アップロ―ド受付済みです。",
    "MESG-E474" : "このアップロード操作は行えません。",
    "MESG-E475" : "MNP電話番号は合計で11桁となるように入力してください。",
    "MESG-E476" : "アップロード済の画像の枚数を減らしてください。",
    "MESG-E477" : "指定ファイルはアップロード不可となります。",
    "MESG-E478" : "指定ファイルはアップロード不可となります。",
    "MESG-E479" : "会社情報が未登録のため、コース変更をお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E480" : "ファイル名に使用できない文字が含まれています。<br/>ファイル名には全角文字、半角英数字、ハイフン「－」・アンダーバー「＿」・ドット「．」のみご使用ください。",
    "MESG-E669" : "お客さまは、「So-netご利用代金」については現在ご登録のお支払い方法、「KDDI各種料金」については、KDDIからの請求となっています。ご請求をまとめる場合は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-I910" : "ご契約全ての退会手続きを{0}月末にて受け付けました。<li>なお、ご利用機器の返却先については、<a target=\"_blank\" href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000009234\" id=\"UIMYP0010_faqLink\">こちらのページ</a>をご確認ください</li>",
    "MESG-I911" : "ご契約全ての退会手続きを{0}月末にて受け付けました。<li><a id=\"UIMYP0010_leaveLink\" onclick=\"window.open('./quitSearchForm.jsp?key=cust_no&amp;text={1}','no2')\" href=\"javascript:void(0)\">詳細確認</a></li><li>なお、ご利用機器の返却先については、<a target=\"_blank\" href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000009234\" id=\"UIMYP0010_faqLink\">こちらのページ</a>をご確認ください</li>",
    "MESG-I912" : "{0}月末にてユーザーIDの廃止手続きを受け付けました。 <li><a id=\"UIMYP0010_leaveLink\" onclick=\"window.open('./quitSearchForm.jsp?key=auth_id&amp;text={1}','no2')\" href=\"javascript:void(0)\">詳細確認</a></li><li>なお、ご利用機器の返却先については、<a target=\"_blank\" href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000009234\" id=\"UIMYP0010_faqLink\">こちらのページ</a>をご確認ください</li>",
    "MESG-I913" : "{0}月末での退会手続きを受付中です。<li><a id=\"UIMYP0010_leaveLink\" onclick=\"window.open('./quitSearchForm.jsp?key=cust_no&amp;text={1}','no2')\" href=\"javascript:void(0)\">詳細確認</a></li>",
    "MESG-I914" : "<li>お客さまのメールアドレスとユーザーIDは同じ文字列です。より安心してご利用いただくために、ユーザーIDの変更をお勧めします。 <a href=\"http://www.so-net.ne.jp/support/information/121029.html\" target=\"_blank\">詳しくはこちら</a></li>",
    "MESG-I915" : "<div class=\"warning\">●ユーザーIDパスワードが長期間変更されていません</div><div class=\"d-news-l\">安全にご利用いただくため、定期的に変更をお願いいたします。(最終変更日:{0})<br/><a href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000012319\" class=\"linkBlank\" target=\"_blank\">ユーザーID/ユーザーIDパスワードについて</a></div>        <div class=\"d-news-r\"><a class=\"btn-highPriority btn-linkBlank\" href=\"./UIMYP0940.xhtml?authId={1}&sessionId={2}&chgMode=1&chgItem=2\" target=\"_blank\">パスワードを変更する</a></div>",
    "MESG-I916" : "<li><font color=#ff0000><b>お客さまは現在、So-netの各種サービスをご利用いただけない状態となっております。詳細の理由につきましては、So-netまでお問い合わせください。</b> </font><a href=\"https://support.so-net.ne.jp/ask_tel\" target=\"_blank\">お問い合わせはこちら</a></li>",
    "MESG-I917" : "<div class=\"warning\">●サービスのご利用を停止させていただいております</div><div class=\"d-news-l\">ご利用料金のお支払いが確認できないため各種サービスをご利用いただけない状態となっております。<br/>サービス再開のお手続きについては、下記ページをご参照ください。<br/><a href=\"https://support.so-net.ne.jp/supportsitedetailpage?id=000012666\" class=\"linkBlank\" target=\"_blank\">So-netのサービスが利用できない</a></div>",
    "MESG-E557" : "お客さまのお支払い方法ではお手続きできません。<br/>お申し込みをご希望される方は、マイページからお支払い方法をクレジットカードに変更後、<br/>再度お申し込み手続きを行ってください。",
    "MESG-E670" : "ファミリーパック解約手続中のため、コース変更をお申し込みいただけません。<br/>ファミリーパック解約手続き完了後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E558" : "お客さまのお支払い方法ではお手続きできません。",
    "MESG-E671" : "モバイル・ダイアルアップ以外のコースをお申し込み中またはご利用中の子会員が存在するため、コース変更をお申し込み頂けません。",
    "MESG-E672" : "管理者ユーザーが複数存在するため、のコース変更をお申し込み頂けません。",
    "MESG-E673" : "ファミリーパックコースをお申し込みまたはご利用中の子会員と、ファミリーパック以外のコースをお申し込みまたはご利用中の子会員が存在するため、のコース変更をお申し込み頂けません。<br/>子会員のお申し込みコースをすべてファミリーパックコースに変更するか、すべてファミリーパック以外のコースに変更後、再度お申し込みください。",
    "TIKI-E022" : "So-net モバイル LTE（データ+音声）プランをご利用中のため、退会をお申し込みいただけません。<br />So-net モバイル LTE（データ+音声）プランの解約完了後、お手続きください。",
    "MESG-E559" : "お客さまのお支払い方法ではお手続きできません。",
    "MESG-I918" : "現在NTT請求でお支払されておりますが、このまま再度NTT請求で登録した場合審査が確定するまで手続き中コンビニでのお支払いとなります。必ずお客さまへご案内ください。",
    "MESG-E560" : "お客さまのお支払い方法ではお手続きできません。",
    "MESG-E674" : "お客さまは、本ページからのコース変更がお申し込みいただけません。<br/>詳しくは、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-W690" : "お客様がお申込・ご利用中の接続コースは、So-net長割対象外コースのため、お申込みいただけません。",
    "MESG-W691" : "お客さまのコースでは「So-net 長割 for フレッツ」をお申込みいただくことはできません。<a href=\"https://www.so-net.ne.jp/access/change/tel.html\">コース変更ダイヤル</a> 0120-080-790までお電話ください",
    "MESG-W692" : "お客様はSo-net 長割をお申込み済み、またはご利用中です。<br/>So-net 長割のお申込み・ご利用状況はマイページよりご確認いただけます。",
    "MESG-E561" : "既にお申し込みのお手続きが完了しています。<br/>お申し込み内容の変更をされたいお客さまは、So-netサポートデスクへご連絡ください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-I919" : "※特に重要なお知らせのうち、送信から60日以内のメールを表示しています",
    "MESG-W693" : "検索必須項目を1つ以上入力してください。",
    "MESG-W694" : "セッションID、リクエストID、操作ユーザ、対象ユーザのいずれかを入力してください。",
    "MESG-W695" : "検索に時間がかかっているので、タイムアウトしました。",
    "MESG-W696" : "入力した条件に一致するアプリログは見つかりませんでした。",
    "MESG-W697" : "お客さまのSo-net 長割提供状況では、当画面をご利用になれません。",
    "MESG-W698" : "お手続きが完了しませんでした。<br/>So-net 光 (UCOM)マンションV 100Mコースお申し込みの場合、<br/>So-net フォンの同時お申し込みが必要となります。<br/>So-net フォンを選択の上、再度お申し込みください。",
    "MESG-E562" : "※So-net モバイル LTE（データ＋音声）は、同一名義にて6契約以上のお申し込みはできません。<br/> また、端末セットは同一名義で1契約までとなります。",
    "MESG-E563" : "選択された経路に対象の代理店は登録できません。{0}",
    "MESG-E564" : "選択された代理店は、使用中のため削除できません。{0}",
    "MESG-E675" : "{0}の{1}が重複しています",
    "MESG-E676" : "お客さまの利用中接続コース情報が取得出来ません",
    "MESG-W699" : "現在、類似のセキュリティサービスを複数お申し込みいただいております。<br/>サービスの複数お申し込みやご利用の場合、機能の重複や管理が複雑になることが考えられますので、<br/>マイページにてご利用状況をご確認していただき、不要なセキュリティサービスがございましたら、<br/>ご利用状況の確認、また必要に応じて別途お手続きをお願いいたします。",
    "MESG-I920" : "同時申込と見なせる接続サービスが存在する場合に限り、申込が可能です。<br/>同時申込となるカスペルスキー セキュリティの「代理店コード」「キャンペーン適用基準日」は紐づけ可能な接続サービスと同じ値となります。",
    "MESG-W700" : "本人確認のための情報が不足しています。",
    "MESG-W701" : "入力値が不正です。",
    "MESG-W702" : "本人確認には、お客様番号、サービス専用番号、ユーザーID、メールアドレスのいずれかが必須です。",
    "MESG-W703" : "検索条件に合致する{0}が複数存在します。<br/>検索条件を追加してください。",
    "MESG-W704" : "カスペルスキー セキュリティをすでにご利用中の場合、NURO光をお申し込みいただくと、無料でご利用いただけるようになります。<br/>その他のセキュリティサービスをご利用中の場合、必要に応じてお客さまご自身で解約のお手続きをしてください。",
    "MESG-W705" : "氏名（カナ）で本人確認を行う場合、セイ・メイを両方指定してください。",
    "MESG-W706" : "生年月日で本人確認を行う場合、元号・年・月・日をすべて指定してください。",
    "MESG-E481" : "既に退会済か利用停止のため、処理ができません。",
    "MESG-E482" : "既にユーザ廃止済みのため、処理ができません。",
    "MESG-E483" : "お客さまは本ページでのお手続きができません。",
    "MESG-E484" : "お客さまは本サービスにお申し込みいただいておりません。",
    "MESG-W707" : "変更後の上限金額が、ユーザ設定可能上限金額（最大値）を超えます。",
    "MESG-W708" : "変更後の上限金額が、CS設定可能上限金額（最大値）を超えます。",
    "MESG-W709" : "本人確認には、お客様番号、サービス専用番号、ユーザーID、メールアドレスのいずれかが必須です。",
    "MESG-W710" : "該当のお客さまは、現在利用停止中のため、本サービスがご利用いただけません。",
    "MESG-W711" : "該当のお客さまは、既に退会しており、本サービスがご利用いただけません。",
    "MESG-E485" : "同時申込と見なせる接続サービスが存在しないため、本ページでのお手続きができません。",
    "MESG-W403" : "すでに登録済みのメールアドレスです。入力内容に問題がなければ次のページへ進んでください。",
    "MESG-E677" : "期限切れのため、そのURLはご利用できません。",
    "MESG-E678" : "既に再発行処理が完了しているため、そのURLはご利用できません。",
    "MESG-E679" : "すでに本登録手続きされているURLはご利用できません。",
    "MSTM-E794" : "表示順のみが入力されています。オプション名：{0}",
    "MSTM-E795" : "オプション内で表示順が重複しています。",
    "MESG-E930" : "サポート番号は{0}で入力してください。",
    "MESG-E931" : "担当者名は全角/半角で入力してください。",
    "MESG-E932" : "設定サポート済みのサポート番号です。",
    "MESG-E933" : "メニューがありません。",
    "MESG-I934" : "メニューが選択されていません。",
    "MESG-E935" : "サポート種別を選択してください。",
    "MESG-E936" : "メニューを選択してください。",
    "MESG-E937" : "サポート事業者IDまたはサポート事業者IDパスワードを正しく入力してください。",
    "MESG-E944" : "手続種別を選択してください。",
    "MESG-E945" : "手続種別が「その他」の場合は、理由を記入してください。",
    "MESG-E946" : "実施年月日は今日以前の日付を yyyymmdd 形式で入力してください。",
    "MESG-E947" : "事業者を選択してください。",
    "MESG-E948" : "該当データはありません。",
    "MESG-E590" : "認証区分として、{0}または{1}を選択してください。",
    "MESG-E938" : "継続利用する電話番号は異なる番号を指定してください。",
    "MESG-E939" : "現在{0}可能な状態ではございません。接続サービスの開始後にお申し込みください。",
    "MESG-E940" : "ご利用可能な{0}がないため、本サービスをご利用いただけません。",
    "MESG-I935" : "お申し込み中の接続サービスがあります。開通までの進捗状況は<a id='riyojokyoInfo' href='#service-setsuzoku' onclick='javascript:scrollServiceStatus();'>こちら</a>からご確認ください。",
    "MESG-E941" : "末尾が「00」の代理店コードは指定できません。",
    "MESG-E942" : "So-net モバイル LTEのお手続きが重複している可能性があります。<br/>お申し込みのお手続きにつきましては、再度、お申し込み画面の先頭よりお手続きください。",
    "MESG-E565" : "接続コースが開通していないためお申し込みいただけません。<br/>開通後、お申し込みください。",
    "MESG-E566" : "接続コースの申込日がつながる機器補償のサービス提供前のため、お申し込みいただけません。",
    "MESG-I921" : "同時申込と見なせる接続サービスが存在する場合に限り、申込が可能です。<br/>同時申込となるSo-net つながる機器補償の「代理店コード」「キャンペーン適用基準日」は紐づけ可能な接続サービスと同じ値になります。",
    "MESG-E567" : "入力された決済IDは紐付可能なステータスではありません。",
    "MESG-E568" : "入力された決済IDは、ログインされている代理店でご利用できる決済IDではありません。",
    "MESG-E569" : "決済IDに紐付いているカナ氏名と入力されたカナ氏名が一致いたしません。",
    "MESG-E570" : "決済IDに紐付いている連絡先電話番号と入力されたご連絡先電話番号が一致いたしません。",
    "MESG-E571" : "入力された{0}は存在していません。",
    "MESG-W943" : "2番号のうち片方の電話番号で継続利用をご選択された場合、残りの番号に対して移転アナウンスはご利用いただけません。<br/>必ず「希望しない」を選択してください。<br/>なお移転アナウンスを希望される場合、Webページからはお手続きを行えませんので、<a target=\"_blank\" href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a>までお電話ください。（ba001）",
    "MESG-I922" : "{0}を選択した場合は、{1}の選択または入力が必須となります。",
    "MESG-I923" : "大変申し訳ございませんが、18歳未満のお客さまの承継・譲渡は承っておりません。",
    "MESG-I924" : "顧客区分 10：個人(一般)に変更します。",
    "MESG-I925" : "顧客区分 10：個人(一般)に変更しました。",
    "MESG-I926" : "キャリア連携が必要なため、チケット対応依頼をしてください。",
    "MESG-I927" : "{0}",
    "MESG-E928" : "ご本人さま確認ができませんでした。再度お手続きいただくか、お手数ですが個人のお客さまは「<a href=\"https://support.so-net.ne.jp/ask_select\" class=\"d-blanklink-mark\" target=\"_blank\">So-net サポートデスク</a>」に、法人のお客さまは「<a href=\"https://www.so-net.ne.jp/business/support/inquiry/form_inq/inquiry0.html\" class=\"d-blanklink-mark\" target=\"_blank\">So-net 法人サポートデスク</a>」にご連絡ください。",
    "MESG-E929" : "カナ氏名、電話番号、生年月日は3項目すべて入力してください。",
    "MESG-E572" : "「So-net代理店番号」と「KDDIエントリーコード」の経路が矛盾しています。<br/>「So-net代理店番号」または、「KDDIエントリーコード」を確認して入力してください。",
    "MESG-E573" : "KDDIサービスとまとめる場合、以下のどちらかは必須となります。<br/>・ご契約者氏名印鑑有無とご請求先のお客様氏名印鑑有無とお支払者氏名印鑑有無が共に有<br/>・申込者誓約有無と申込者印鑑有無が共に有",
    "MESG-E574" : "入力されたメールアドレスのユーザが見つかりません。メールアドレスをご確認のうえ、再度入力してください。",
    "MESG-E575" : "入力されたユーザIDのユーザが見つかりません。ユーザIDをご確認のうえ、再度入力してください。",
    "MESG-E576" : "入力されたお名前、生年月日、ご連絡先のユーザが見つかりません。各項目をご確認のうえ、再度入力してください。",
    "MESG-E577" : "複数会員が一致するため、会員を特定できません。<br/>「メールアドレスで認証」または「ユーザIDで認証」を選択のうえ、再度本人性確認を行ってください。",
    "MESG-E578" : "お名前が会員情報と一致しません。",
    "MESG-E579" : "生年月日が会員情報と一致しません。",
    "MESG-E580" : "ご連絡先が会員情報と一致しません。",
    "MESG-E581" : "この顧客には管理者が複数います。本サービスの管理を行う管理者のユーザーIDで、申込手続きをやり直してください。",
    "MESG-E582" : "該当データはありません。",
    "MESG-E583" : "管理者が違うため、基本契約者変更のお手続きができません。",
    "MESG-E584" : "指定のユーザーIDが現基本契約者と同じため、基本契約者変更のお手続きができません。",
    "MESG-E585" : "お支払い方法が登録されていないため、コース変更手続きを承ることができません。",
    "MESG-E586" : "指定されたメニューコードは設定済みです。該当メニューコード：{0}",
    "MESG-E587" : "指定されたコードは既に設定済みか、または、存在しません。該当メニューコード：{0}",
    "MESG-E588" : "{0}が指定されていません。",
    "MESG-E589" : "1メニューあたりの上限金額を超えております。ご確認のうえ、正しい金額を入力してください。",
    "MESG-E591" : "金額に不正な文字が含まれています。",
    "MESG-E592" : "メニュー名に使用できない文字が含まれています。",
    "MESG-E593" : "メニュー名が長すぎます。",
    "AGTS-I001" : "CSVの作成を開始しました。一度ホーム画面に戻り、再度「登録情報の確認・修正」ページに入って下さい。「ダウンロード」ボタンが表示されていれば、CSV出力完了です。",
    "MESG-E594" : "お申し込み可能期間外の商品が選択されています。",
    "MESG-E595" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E596" : "同一商品をすでにお申し込み済みのため、お申し込みいただけません。",
    "MESG-E597" : "一度にお申し込みいただける商品数を超過しています。",
    "MESG-E598" : "入力されたサービス契約番号に誤りがあります。",
    "MESG-E599" : "お申し込みいただけない商品が選択されています。",
    "DVPF-E001" : "タブレット商品をすでにお申し込み済みのため、お申し込みいただけません。",
    "MESG-E690" : "お客さまは法人会員のため、ホワイトコール24にお申し込みいただけません。<br/>お申し込みの条件は以下となります。<br/><br/>1.個人会員である<br/>2.「NURO 光 でんわ」の申込がある",
    "MESG-E691" : "お客さまは「NURO 光 でんわ」をお申し込みいただいていないため、<br/>ホワイトコール24にお申し込みいただけません。お申し込みの条件は以下となります。<br/><br/>1.個人会員である<br/>2.「NURO 光 でんわ」の申込がある",
    "MESG-E692" : "お客さまは「NURO 光 でんわ」付加サービスの「着信転送サービス」「パック1」「パック2」の<br/>いずれかをお申し込みいただいているため、ホワイトコール24にお申し込みいただけません。<br/>お申し込みの条件は以下となります。<br/><br/>1.個人会員である<br/>2.「NURO 光 でんわ」の申込がある",
    "MESG-E693" : "お客さまは本日すでに申込書取り寄せの手続きが完了しています。<br/>お手数ですが明日以降に再度お手続きください。<br/><br/>※取り寄せのお手続きは1日1回までとなります。",
    "MESG-E694" : "{0}に値を入力してください。",
    "TIKI-E023" : "「NURO 光」の屋外工事予定日の前日以降のため、退会手続きは承れません。<br/>「NURO 光」開通後に再度お手続きください。",
    "TIKI-E024" : "「NURO 光 でんわ」が利用開始前のため、退会手続きは承れません。<br/>「NURO 光 でんわ」の利用開始以降に再度お手続きください。<br/>お急ぎの場合はNUROサポートデスク（0120-65-3810）までお問い合わせください。",
    "TIKI-E025" : "現在ご利用（お申込み）いただいているSo-net for ドコモ光コースを事前に解約する必要がございます。<br/>解約についてはお近くのドコモショップにお問い合わせください。",
    "TIKI-E026" : "So-net 光の退会手続きを承ることができません。<br/>不明点などについては、弊社サポートデスクまでご連絡をお願い致します。",
    "TIKI-E027" : "既に退会のお申込みをいただいております。<br/>インターネット回線の廃止完了後、退会完了となりますので、あらかじめご了承ください。",
    "MESG-I928" : "同時申込と見なせる接続サービスが存在する場合に限り、申込が可能です。<br/>同時申込となる{0}の「代理店コード」「キャンペーン適用基準日」は紐づけ可能な接続サービスと同じ値になります。",
    "MESG-E695" : "こんてんつコースをご利用のお客さまのため、コース変更手続きを承ることができません。",
    "MESG-E696" : "ポイント残高がありません。<br>ポイント移動はできません。",
    "MESG-E697" : "移動先ユーザーがありません。<br>ポイント移動はできません。",
    "MESG-E698" : "顧客番号が異なるユーザー間のポイント移動はできません。<br/> お手数ですが最初の画面に戻り、再度手続きを行ってください。",
    "MESG-W944" : "どちらかの電話番号で「継続利用する」を選択してください。<br/>2番号とも「継続利用しない」を希望する場合、「解約時期」を選択し直してください。",
    "PHON-E001" : "「So-netフォン」のお申込手続き中です。<BR>「So-net フォン ご利用登録完了確認」メールが届きましたら、通話明細がご確認いただけます。",
    "MESG-E943" : "大量のお申し込みが行われた、または過去に大量のお申し込みをされた可能性があるため、お申し込みできません。",
    "MESG-E750" : "ユーザーID、メールアドレス又は接続用IDのいずれかを入力してください。",
    "MESG-E751" : "{0}に誤りがあります。{1}文字以上、{2}文字以内で入力下さい。",
    "MESG-E752" : "{0}に誤りがあります。ご利用可能文字は、半角のアルファベット小文字、数字、-(ハイフン)、_(アンダーバー)と.(ドット)です。",
    "MESG-E753" : "{0}に誤りがあります。先頭の文字はアルファベット小文字のみご利用可能です。",
    "MESG-E754" : "{0}に誤りがあります。.(ドット)の連続は指定できません。",
    "MESG-E755" : "{0}に誤りがあります。最後尾に.(ドット)を指定できません",
    "MESG-E756" : "{0}に誤りがあります。ご利用可能文字は、半角のアルファベット大文字・小文字、数字、-(ハイフン)と_(アンダーバー)です。",
    "MESG-E757" : "{0}に誤りがあります。先頭の文字は必ずアルファベットあるいは数字にしてください。",
    "MESG-E758" : "{0}に誤りがあります。必ずアルファベットと数字を混在させてください。",
    "MESG-E759" : "「{0}」と「{1}」が一致しません。",
    "MESG-E760" : "いずれかの自動のチェックを選択してください。",
    "MESG-E761" : "{0}と{1}に、同じ文字列は指定できません。{0}と{1}は別の文字を入力してください。",
    "MESG-E762" : "現在の{0}と、変更後の{1}が同じです。",
    "MESG-E763" : "お客様情報は、既に変更されています。",
    "MESG-E764" : "お客様がご希望のユーザーIDはご利用いただけません。",
    "MESG-E765" : "お客様がご希望のメールアドレスはご利用いただけません。",
    "MESG-E766" : "お客様がご希望の接続用IDはご利用いただけません。",
    "MESG-E767" : "お客様がご希望のユーザーID/メールアドレスはご利用いただけません。",
    "MESG-E768" : "お客様がご希望のユーザーID/接続用IDはご利用いただけません。",
    "MESG-E769" : "お客様がご希望のメールアドレス/接続用IDはご利用いただけません。",
    "MESG-E770" : "お客様がご希望のユーザーID/メールアドレス/接続用IDはご利用いただけません。",
    "MESG-E771" : "メールアドレスは既に変更済です。再度変更される場合は、マイページに戻ってお手続きください。",
    "MESG-E772" : "ユーザーIDは既に変更済です。再度変更される場合は、マイページに戻ってお手続きください。",
    "MESG-E773" : "接続用IDは既に変更済です。再度変更される場合は、マイページに戻ってお手続きください。",
    "MESG-E950" : "お客様番号、カナ氏名、電話番号のうち2点以上入力してください。",
    "MESG-E951" : "入力内容に不備があります。カナ氏名・電話番号の入力内容を確認してください。",
    "MESG-E685" : "「会員さま限定WiMAXアップグレードキャンペーン」のお申し込み条件を満たしていないため、お申し込みできません。",
    "MESG-E952" : "お客様番号には、数字、-(ハイフン)のみご利用いただけます。",
    "MESG-E953" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E954" : "既に選択されたコースをご利用いただいているか、選択されたコースへのコース変更のお申し込みを承っているため、<br/>お申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MATI-E101" : "ログインIDまたは、パスワードが正しくありません。",
    "MATI-E201" : "項番{0}の事業者内通番または受注契約番号が未入力です。",
    "MATI-E202" : "項番{0}の事業者内通番は半角数字で入力して下さい。",
    "MATI-E203" : "項番{0}の受注契約番号は半角数字で入力して下さい。",
    "MATI-E204" : "項番{0}の事業者内通番は5桁で入力して下さい。",
    "MATI-E205" : "項番{0}の受注契約番号は9桁で入力して下さい。",
    "MATI-E207" : "事業者内通番に同じ値が入力されています。",
    "MATI-E208" : "受注契約番号に同じ値が入力されています。",
    "MATI-E209" : "項番{0}で使用可能な固定IPアドレスは在庫不足です。回線種別をご確認ください。",
    "MATI-E210" : "項番{0}で使用可能な固定IPアドレスは売り切れです。2日～3日で追加予定です。",
    "MATI-E211" : "項番{0}の事業者内通番はすでに登録済みです。",
    "MATI-E212" : "項番{0}の受注契約番号はすでに登録済みです。",
    "MATI-E213" : "登録できるID数が上限に達しました。So-netにご連絡ください。",
    "MATI-E501" : "パスワードは6桁以上128桁以下で入力して下さい。",
    "MATI-E502" : "パスワードは英数混合で入力して下さい。",
    "MATI-E503" : "IDとパスワードは同じ文字列はご利用できません。",
    "MATI-E504" : "入力したIDは存在しません。",
    "MATI-E505" : "入力したIDは存在しません。",
    "MATI-E506" : "対象IDのパスワード変更は行えません。",
    "MATI-E507" : "パスワードとパスワード（確認用）に異なる文字列が入力されています。",
    "MATI-E214" : "追加ID情報が入力されていません。",
    "MESG-W712" : "現在、類似のサポートサービスにお申し込みいただいております。<br/>マイページで、ご利用状況をご確認いただき、必要に応じて別途お手続きをお願いいたします。",
    "MESG-I929" : "{0}{1}日 09:00以降、{2}日以内にお手続きください",
    "MESG-I930" : "{0}～{1}",
    "MESG-I931" : "お申し込みのコース開通後に確定します",
    "MESG-I932" : "{0}13日 （自動加算） ※手続きは不要です。",
    "MESG-I933" : "{0}～",
    "MESG-I937" : "{0} 発行予定",
    "MESG-I938" : "{0} 発行済み(有効期限のある場合がございます)",
    "MESG-E955" : "入力された{0}はご利用できません。 ご入力内容をご確認ください。",
    "MESG-E956" : "現在ご利用いただいているコースは、マイページからコース変更手続きを承ることができません。<br/>不明点などについては、弊社サポートデスク（0120-80-7761)までご連絡をお願致します。",
    "MESG-E957" : "既にコース変更のお申し込みを承っておりますので、コース変更をお申し込みいただけません。<br/>お申し込み中コースのご利用開始後、再度お申し込みください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E958" : "リクエスト情報の代理店コードが不正です。",
    "MESG-E959" : "現在ご利用いただいているコースは、So-net メンバーズコースへのコース変更手続きを承ることができません。<br/>不明点などについては、弊社サポートデスク（0120-80-7761)までご連絡をお願致します。",
    "MESG-E960" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E961" : "持ち家または分譲マンションの場合、公営住宅であるは選択できません。",
    "MESG-E962" : "工事希望日＋工事希望時間(第1希望~第3希望)は重複して選択できません。",
    "MESG-E963" : "So-net 光 電話が申込されていないため、無線LANカードは選択できません。",
    "MESG-E964" : "建物が選択されていないため、公営住宅は選択できません。",
    "MESG-E965" : "第2工事希望日を選択してください。",
    "MESG-E966" : "第2工事希望時間帯を選択してください。",
    "MESG-E967" : "第3工事希望日を選択してください。",
    "MESG-E968" : "第3工事希望時間帯を選択してください。",
    "MESG-E969" : "第2工事希望日を選択してください。", 
    "MESG-E780" : "既に退会済か利用停止中のため、処理ができません。",
    "MESG-E781" : "現在、サービスのご利用はございません。",
    "MESG-E782" : "本サービスへのお申し込み中のため、手続きができません。サービス開始後にお申し込みください。",
    "MESG-E783" : "既に{0}をお申し込みいただいています。",
    "MESG-E784" : "{0}はまだご利用いただけません。サービス開始月の2ヶ月後以降に再度お申し込みください。",
    "MESG-E785" : "「So-net 光×auセット割」のお申込ができません。理由は下記の通りです。<br/>・すでに申込済みの場合（お手続き中含む）<br/>・「So-net 光」をご利用中でない場合<br/>・ご利用停止中の場合　など",
    "MSTM-I901" : "{0}が完了しました。",
    "MSTM-I902" : "内容を確認したうえで、「{0}」ボタンをクリックしてください。",
    "MSTM-E903" : "「{0}」は「{1}」以下の値を設定してください。",
    "MESG-E786" : "決済IDに紐付く口座情報が取得出来ません。",
    "MESG-E787" : "口座情報の銀行情報が取得出来ません。",
    "MSTM-E904" : "「在庫グループ設定」は{0}つ以上の商品を選択してください。",
    "MESG-W788" : "DNSへのSo-net レンタルサーバーHSのサーバー環境設定は完了しています。",
    "RNSV-W007" : "レンタルサーバのDNS設定に必要なFTPのAレコードが、既に登録されております。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "RNSV-W008" : "レンタルサーバのDNS設定に必要なmxのAレコードが、既に登録されております。<br/>DNS設定の切り替えを行う前に、重複しているレコードを削除してください。",
    "MSTM-E905" : "オプション区分が存在しません。",
    "MESG-E221" : "{0}には本日以前の日付を入力してください。",
    "MESG-E222" : "{0}には当月以前の年月を入力してください。",
    "MSTM-E906" : "マスタ情報が既に更新されています。再度一覧検索から実行して下さい。",
    "MSTM-E907" : "「宛先メールアドレス」が未入力です。",
    "MSTM-E908" : "「宛先メールアドレス」は末尾が「so-net.co.jp」となるメールアドレスのみ登録可能です。",
    "MSTM-E909" : "「宛先メールアドレス」に重複するメールアドレスが入力されています。",
    "RNSV-E101" : "追加容量が{0}の上限を超えています。",
    "MESG-W900" : "申し訳ございません。サービス解約をされている為、本画面はご利用いただけません。",
    "MESG-W901" : "{0}には{1}は使用できません。",
    "MESG-W902" : "検索条件に合致する{0}が複数存在します。",
    "DVPF-E002" : "ご好評により、お申し込みの受付を終了いたしました。",
    "MESG-I497" : "割引パックPlusを選択した場合、あんしん電話着信サービス／発信者番号表示サービス／非通知着信拒否サービス／割込電話サービス／迷惑電話拒否サービス／転送電話サービスのお申し込みはできません。",
    "RSHS-E001" : "現在お客さまのDNS設定上、レコードを追加設定するための空き枠がないため、追加設定することができません。<br/>※So-net  レンタルサーバーHSのDNSレコードを設定する場合、空き枠が1レコード分必要となります。<br/><br/>不要なDNSレコードを削除いただくか、登録可能なレコード数の追加申し込みを<a href=\"https://www.so-net.ne.jp/option/domain/dns/administration.html\">こちら</a>より行っていただき、再度DNS設定のお手続きを行ってください。",
    "MESG-E789" : "初期契約解除期間でないため、プラン変更申込キャンセルをご利用下さい。",
    "MESG-E790" : "初期契約解除期間でないため、01日09:30以降にご利用下さい。",
    "MESG-E923" : "お申し込み受付は完了しておりますが、現在工事日予約システムをご利用いただくことができません。<br/>大変申し訳ございませんが、NURO開通センターからのご連絡をお待ちいただきますようお願いいたします。",
    "MESG-E791" : "初期契約解除期間を過ぎたため、初期契約解除できません。",
    "MESG-E792" : "お客さまがご利用されているコースは、本ページからのコース変更がお申し込みいただけません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a>",
    "AGTS-E001" : "回答先リクエストが存在しません。",
    "AGTS-E002" : "リクエスト中ステータスから回答済みへは更新できません。",
    "AGTS-E003" : "存在しない代行OLSUIDが含まれています。:{0}",
    "MESG-E970" : "入力されたユーザーIDでは登録出来ないサポート番号です。",
    "AGTS-W001" : "現在処理が混み合っております。お手数おかけしますが、しばらく経ってから実行してください。",
    "MESG-E986" : "「So-net 光」退会受付中のため、コース変更をお申し込みいただけません。<br/>お申し込みいただくためには、退会の受付をキャンセルしていただく必要がございます。<br/>以下のサポート窓口までお問い合わせください。<br/>個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E971" : "So-netより申し込み内容の確認のお電話をさせて頂く場合があります。",
    "MESG-E972" : "ご利用予定場所の建物名を選択してください。",
    "MESG-E975" : "システムエラーが発生しました。",
    "MESG-E976" : "現在の設定と変更ありません。",
    "MESG-E977" : "お客さまのユーザーIDではSo-netのメールアドレスは選択できません。連絡先メールアドレスを選択してください。",
    "MESG-E978" : "連絡先メールアドレスが登録されておりません。マイページで連絡先メールアドレスを登録後、選択してください。",
    "MESG-E979" : "お客さまIDは、「CAF」＋数字１０桁または「COP」＋数字８桁で入力してください。",
    "MESG-E980" : "お客さまを特定できませんでした。ご入力内容をご確認ください。",
    "MESG-E981" : "お客さまIDに誤りがあります。ご入力内容をご確認ください。または、移転/品目変更/廃止といったお手続き中の場合、お手続きが完了するまでお申し込みできません。",
    "MESG-E982" : "氏名（漢字）、氏名（カナ）に誤りがあります。ご入力内容をご確認ください。",
    "MESG-E983" : "郵便番号に誤りがあります。ご入力内容をご確認ください。",
    "MESG-E984" : "電話番号に誤りがあります。ご入力内容をご確認ください。",
    "MESG-E985" : "お手続きが完了しませんでした。しばらくしてから再度実行してください。",
    "MESG-E987" : "お手続きが完了しませんでした。すでにお手続き済みの場合があります。<br/>お手続き前の場合は、しばらくしてから再度実行してください。",
    "MESG-I936" : "<div class=\"warning\">●サービスのご利用を停止させていただいております</div><div class=\"d-news-l\">各種サービスをご利用いただけない状態となっております。<br/>恐れ入りますが、下記のSo-netサポートデスクへお問い合わせください。<br/><a href=\"https://support.so-net.ne.jp/ask_select\" class=\"linkBlank\" target=\"_blank\">So-netサポートデスク</a></div>",
    "MESG-E988" : "半角スペースは使用できません。",
    "MESG-E989" : "お客さまはKasperskyサービスを解約またはキャンセル済みのため、ダウンロードのお手続きができません。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-E990" : "Kasperskyのダウンロードお手続きが完了しませんでした。しばらくしてから再度実行してください。<br/>ご不明な点は、以下のサポート窓口までお問い合わせください。<br/>&nbsp;&nbsp;&nbsp;個人のお客さま：<a href=\"https://support.so-net.ne.jp/ask_select\">So-net サポートデスク</a><br/>&nbsp;&nbsp;&nbsp;法人のお客さま：<a href=\"http://www.so-net.ne.jp/business/contactus/\">So-net 法人サポートデスク</a>",
    "MESG-I936" : "<span class=\"warning\">●サービスのご利用を停止させていただいております</span><div class=\"d-news-l\">各種サービスをご利用いただけない状態となっております。<br/>恐れ入りますが、下記のSo-netサポートデスクへお問い合わせください。<br/><a href=\"https://support.so-net.ne.jp/ask_select\" class=\"link-mark\" target=\"_blank\">So-netサポートデスク</a></span></div>",
    "MESG-W903" : "現在、変更予約中です（変更予定日：{0}年{1}月{2}日）",
    "MESG-E991" : "auスマートバリューのお申し込みにはSo-net 光のお申し込みが必要です。",
    "MESG-E992" : "「auスマートバリュー」は「So-net 光」のみお申し込みできます。",
    "MESG-E993" : "auスマートバリューのお申し込みにはSo-net 光 電話のお申し込みが必要です。",
    "MESG-E994" : "コンサル窓口で即決した場合は「後で工事日を決める」を選択してください。<br/>そうでない場合は、「コンサル窓口にて既に決定済み」のチェックを外してください。",
    "MESG-E995" : "くらしのお守りとくらしのお守りワイドは同時に解約キャンセルできません。",
    "MESG-I996" : "以下の電話番号をもとに、サービス提供状況を表示しています。",
    "MESG-E997" : "ご利用ありがとうございます。<br/>お申し込みの回線はすでに開通しております。",
    "MESG-E998" : "システムエラーが発生したため、工事日設定機能をご利用できません。<br/>弊社よりお客さまにご連絡いたします。",
    "MESG-E999" : "お客さまの情報を確認できませんでした。<br/>各項目をご確認のうえ、再度入力してください。",
    "MESG-E1000" : "候補日を取得できませんでした。<br/>しばらく経ってから再度お試しください。",
    "MESG-E1001" : "システムエラーが発生したため、工事日設定機能をご利用できません。<br/>弊社よりお客さまにご連絡いたします。",
    "MESG-E1002" : "申し訳ございません。2カ月先までご予約が埋まっておりますので、<br/>弊社よりお客さまにご連絡いたします。",
    "MESG-E1003" : "SMS/メールの送信に失敗しました。<br/><br/>マイページでも工事予定日のご確認とご変更ができます。<br/>※入会証に記載されている「ユーザーID」と「ユーザーIDパスワード」のご入力が必要となります。<br/><br/>マイページでお手続きができない方は、下記の問い合せ先までご連絡ください。<br/><br/>So-net&nbsp;&nbsp;サポート窓口<br/>【受付時間】 9：00～18：00 (1 月 1 日、2 日および弊社指定のメンテナンス日を除く)<br/>【フリーダイヤル】 0120-80-7761"
    "MESG-E1004" : "FVNOと重複したお申し込みのため、お申し込みいただけません。"
};
