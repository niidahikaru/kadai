function sc_trackAdCV(pid){
	sc_tagPageName=document.URL;
	if(pid=="personal"){
		if(typeof sc_gdn=="function"){
			sc_gdn(1056115045,"7jpRCP_6uAQQ5ZLM9wM","3",false,sc_tagPageName);	//brand
			sc_gdn(1058391107,"Jde3CI20iQQQw4jX-AM","3",false,sc_tagPageName);	//hikari one
			sc_gdn(992102960,"FV3mCNDytwQQsJSJ2QM","3",false,sc_tagPageName);	//nuro listing
		}
		if(typeof sc_ydn=="function"){
			sc_ydn(1000044207,"4xH4CK3S3wMQ67eT5QM",sc_tagPageName,"listing");	//brand word
			sc_ydn(1000044206,"EvmGCKfnpQMQgceA5wM","","listing");	//au
			sc_ydn(1000057370,"kPYxCOf2qAUQueSU2QM","","listing");	//nuro
			sc_ydn("Fj4kMT4OLDXMGvA5plm2","","","network");//YDN slp
		}
	}else if(pid=="complete"){
		if(typeof sc_gdn=="function"){
			sc_gdn(1058391107,"Jde3CI20iQQQw4jX-AM","3",false,sc_tagPageName);	//hikari one
			sc_gdn(992102960,"FV3mCNDytwQQsJSJ2QM","3",false,sc_tagPageName);	//nuro listing
      if(typeof getSmRlogs === "function"){
        var l=getSmRlogs();
        if(l.course.indexOf("HCO")>-1){
          sc_gdn(1056115045,"irLECKe3uHoQ5ZLM9wM","3",false,sc_tagPageName);
          sc_gdn(1056115045,"7jpRCP_6uAQQ5ZLM9wM","3",false,sc_tagPageName); //Common
        }else if(l.course.indexOf("AUHK")>-1){
          sc_gdn(1056115045,"Tsu5CKCbpXoQ5ZLM9wM","3",false,sc_tagPageName);
          sc_gdn(1056115045,"7jpRCP_6uAQQ5ZLM9wM","3",false,sc_tagPageName); //Common
        }else if(l.course.indexOf("WX2P")>-1){
          sc_gdn(1056115045,"X8tOCJ6fpXoQ5ZLM9wM","3",false,sc_tagPageName);
          sc_gdn(1056115045,"7jpRCP_6uAQQ5ZLM9wM","3",false,sc_tagPageName); //Common
        }else if(l.course.indexOf("WFS")>-1){
          sc_gdn(1056115045,"wnwxCIHW3n0Q5ZLM9wM","",false);
          sc_gdn(1056115045,"7jpRCP_6uAQQ5ZLM9wM","",false,sc_tagPageName); //flets
        }
      }
    }
		if(typeof sc_ydn=="function"){
			sc_ydn(1000044207,"4xH4CK3S3wMQ67eT5QM",sc_tagPageName,"listing");	//brand word
			sc_ydn(1000044206,"EvmGCKfnpQMQgceA5wM","","listing");	//au
			sc_ydn(1000057370,"kPYxCOf2qAUQueSU2QM","","listing");	//nuro
			sc_ydn("Fj4kMT4OLDXMGvA5plm2","","","network");//YDN slp
			if(window.getSmRlogs && window.getSmRlogs().option && window.getSmRlogs().option.indexOf("VNUS")>-1)sc_ydn("eLjTz_4OLDWQV6E3r1v8","","","network");
            else if(getSmRlogs().course.indexOf("WFS")>-1){
                sc_ydn("Fj4kMT4OLDXMGvA5plm2","JQQ1ZNOY6NJ7W75NZ9E438959","","network");
                sc_ydn(1000044207,"DBE2CJrq8n0Q67eT5QM",sc_tagPageName,"listing"); //flets
            }
                
		}
	}
}
