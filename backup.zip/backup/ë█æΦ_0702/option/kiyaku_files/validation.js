var validate = {config:{}};

// JSValidator機能の無効化フラグ（true：無効, false:有効）
validate.allDisable = false;

//submit時のvalidationエラー時刻
validate.lastSubmitTimeValidateError;

//============================= 単項目 チェック部品 =======================================
/**
 * （半角・全角）カナチェック。 半角・全角スペースが含まれててもOKとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isKana = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();
	// 全角カナ \u30A0-\u30FF  半角カナ\uFF61-\uFF9F
	if (value.match(/^([\u30A0-\u30FF]|[\uFF61-\uFF9F]|(\u0020|\u3000))+$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E161);
		result.state = false;
	}
	return result;
}

/**
 * （半角・全角）カナ+Asciiチェック。 半角・全角スペースが含まれててもOKとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isKanaAscii = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();
	// カナ＋Asciiの全角半角
	if (value.match(/^([\u30A0-\u30FF]|[\uFF61-\uFF9F]|[\u0021-\u007E]|[\uFF01-\uFF5E]|(\u0020|\u3000|￥))+$/)) {
		var isMatchQuotationMarksComma = false;
		for (var i = 0; i < value.length; i++ ) {
			if (value.charAt(i) == '“' || value.charAt(i) == '”' || value.charAt(i) == '‘' || value.charAt(i) == '’' || value.charAt(i) == '，') {
				// ”(全角ダブルクォーテーション)と’(全角シングルクォーテーション)は使用してはいけない[sybaseの禁則文字]
				// ”(全角カンマ)は使用してはいけない[OSMの禁則文字]
				isMatchQuotationMarksComma = true;
			}
		}
		if(isMatchQuotationMarksComma){
			result.msg = com.getMessage(msg.MESG_E162);
			result.state = false;			
		} else {
			result.state = true;
		}
	} else {
		result.msg = com.getMessage(msg.MESG_E162);
		result.state = false;
	}
	return result;
}

/**
 * （半角・全角）カナ+「カッコ」チェック。 半角・全角が含まれててもOKとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isKanaParentheses = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();
	// カナ＋カッコの全角半角
	if (value.match(/^([\u30A0-\u30FF]|[\uFF61-\uFF9F]|(\uFF08|\uFF09|\u0028|\u0029))+$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E217);
		result.state = false;
	}
	return result;
}

/**
 * （半角・全角）asciiチェック。 半角・全角が含まれててもOKとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isAscii = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();
	// asciiの全角半角
	if (value.match(/^([\u0021-\u007E]|[\uFF01-\uFF5E]|(\s|　|”|’|￥))+$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E163);
		result.state = false;
	}
	return result;
}

/**
 * （半角・全角）英数チェック。 半角・全角が含まれててもOKとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isEisu = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();
	// asciiの全角半角
	if (value.match(/^([\u0030-\u0039]|[\u0041-\u005A]|[\u0061-\u007A]|[\uFF10-\uFF19]|[\uFF21-\uFF3A]|[\uFF41-\uFF5A])+$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E164);
		result.state = false;
	}
	return result;
}

/**
 * 半角カナはNGとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.noHanKana = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();

	for(var i = 0; i < value.length; i++) {
		if (value.charAt(i).match(/[\uFF61-\uFF9F]/) ) {
			result.msg = com.getMessage(msg.MESG_E165);
			result.state = false;
			break;
		}
		result.state = true;
	} 
	return result;
}

/**
 * 半角スペースはNGとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.noHanSpace = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();

	for(var i = 0; i < value.length; i++) {
		if (value.charAt(i).match(/[\u0020]/) ) {
			result.msg =com.getMessage(msg.MESG_E988);
			result.state = false;
			break;
		}
		result.state = true;
	} 
	return result;
}

/**
 * 半角全角カンマはNGとする。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.noComma = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();

	if (value.indexOf(",") != -1 || value.indexOf("，") != -1) {
		result.msg = com.getMessage(msg.MESG_E188);
		result.state = false;
	} else {
		result.state = true;
	}
	return result;
}

/**
 * （半角・全角）数値チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isNum = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	log("数値チェック");
	if (value.match(/^[0-9０-９]+$/g) ){
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E166);
		result.state = false;
	}		
	return result;
}

/**
 * （半角・全角）数値チェック(下限チェック)
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.minNumValidator = function(target$, minNum) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());	

	var floatValue = null;
	var isInput = false;
	if (value) {
		isInput = true;
		if(value.match(/^-?[0-9０-９]+$/g) || value.match(/^-?[0-9０-９]+(\.|．)[0-9０-９]+$/g) ){
			floatValue = parseFloat(value);
		}
	}

	if (isInput == false || (floatValue != null && minNum <= floatValue)){
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E167, minNum);
		result.state = false;
	}		
	return result;
}

/**
 * （半角・全角）数値チェック(上限チェック)
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.maxNumValidator = function(target$, maxNum) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());	

	var floatValue = null;
	var isInput = false;
	if (value) {
		isInput = true;
		if(value.match(/^-?[0-9０-９]+$/g) || value.match(/^-?[0-9０-９]+(\.|．)[0-9０-９]+$/g) ){
			floatValue = parseFloat(value);
		}
	}

	if (isInput == false || (floatValue != null && floatValue <= maxNum)){
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E168, maxNum);
		result.state = false;
	}		
	return result;
}

/**
 * （半角・全角）数・小数点チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @param pointLen 小数点以下の桁数
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isDecimal = function(target$, pointLen) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	log("小数点チェック");
	if (value.match(/^[0-9０-９]+$/g) ){
		// 小数点なし
		result.state = true;
	} else if(value.match(/^[0-9０-９]+(\.|．)[0-9０-９]+$/g) ){
		// 小数点あり
		var removeInteger = value.replace(/^[0-9０-９]+(\.|．)/, "");
		if(removeInteger.length > pointLen) {
			result.msg = com.getMessage(msg.MESG_E169, pointLen);
			result.state = false;
		} else {
			result.state = true;
			
		}
		
	} else {
		result.msg = com.getMessage(msg.MESG_E170);
		result.state = false;
	}		
	return result;
}

/**
 * 文字数チェック。文字数が指定文字数範囲内か
 * @param target$ チェック対象のJqueryオブジェクト
 * @param len 文字数
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.lengthValidator = function(target$, len) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	if(value.length > len) {
		result.msg = com.getMessage(msg.MESG_E171, len);
		result.state = false;
	} else {
		result.state = true;
	}		
	return result;
}

/**
 * 文字数チェック。文字数が指定文字数か
 * @param target$ チェック対象のJqueryオブジェクト
 * @param len 文字数
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.fixLengthValidator = function(target$, len) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	if(value.length == len) {
		result.state = true;
	} else {
		result.msg = len + "文字で入力して下さい";
		result.msg = com.getMessage(msg.MESG_E172, len);
		result.state = false;
	}		
	return result;
}

/**
 * バイトサイズチェック。SJISでのバイト数が指定範囲内かをチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @param len バイトサイズ
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.byteLengthValidator = function(target$, len) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	if(com.getByteLength(value) > len) {
		var strArray = new Array();
		strArray.push(len / 2);
		strArray.push(len);
		result.msg = com.getMessage(msg.MESG_E173, strArray);
		result.state = false;
	} else {
		result.state = true;
	}		
	return result;
}

/**
 * バイトサイズチェック。SJISでのバイト数が指定バイト数かをチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @param len バイトサイズ
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.fixByteLengthValidator = function(target$, len) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	if(com.getByteLength(value) != len) {
		var strArray = new Array();
		strArray.push(len / 2);
		strArray.push(len);
		result.msg = com.getMessage(msg.MESG_E174, strArray);
		result.state = false;
	} else {
		result.state = true;
	}		
	return result;
}

/**
 * 文字列が jisX0208範囲文字か検証する 
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.jisX0208Validator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();
	result.state = com.isJisx0208(value);
	if (!result.state) {
		result.msg = com.getMessage(msg.MESG_E175);
	}
	return result;
}

/**
 * 文字列が jisX0208範囲文字かのみ検証する
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.jisX0208RangeValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();
	result.state = com.isJisx0208Range(value);
	if (!result.state) {
		result.msg = com.getMessage(msg.MESG_E175);
	}
	return result;
}

/**
 * 正規表現
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */ 
validate.regexValidator = function(target$, pattern) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();	
	result.state = value.match(pattern);
	if (!result.state) {
		result.msg = com.getMessage(msg.MESG_E176);
	}
	return result;
}

/**
 * 電話番号・特殊番号NG（0120,0800, ,000）
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.corpTelValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());
	// ハイフンの有無で分岐
	if(value.indexOf("-") > 0) {
		if(value.match(/^[0-9]+\-[0-9]+\-[0-9]+$/) != null) {
			// 特殊番号チェック
			if(value.startsWith("0120") || value.startsWith("0800") || 
					value.startsWith("000")) {
				result.msg = com.getMessage(msg.MESG_E177);
				result.state = false;
				return result;
			} else {
				result.state = true;
				return result;
			}
		} else {
			result.msg = com.getMessage(msg.MESG_E177);
			result.state = false;
			return result;
		}
		
	} else {
		if (value.match(/^[0-9０-９]+$/g) ){
			// 特殊番号チェック
			if(value.startsWith("0120") || value.startsWith("0800") || 
					value.startsWith("000")) {
				result.msg = com.getMessage(msg.MESG_E177);
				result.state = false;
				return result;
			} else {
				result.state = true;
				return result;
			}
		} else {
			result.msg = com.getMessage(msg.MESG_E177);
			result.state = false;
			return result;
		}
	}
}

/**
 * 通常の電話番号チェック
 * 数値のみ。 数値-数値-数値 形式をチェック 
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.telValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());
	// ハイフンの有無で分岐
	if(value.indexOf("-") > 0) {
		if(value.match(/^[0-9]+\-[0-9]+\-[0-9]+$/) != null) {
			result.state = true;
			return result;
		} else {
			result.msg = com.getMessage(msg.MESG_E178);
			result.state = false;
			return result;
		}
		
	} else {
		if (value.match(/^[0-9０-９]+$/g) ){
			result.state = true;
			return result;
		} else {
			result.msg = com.getMessage(msg.MESG_E178);
			result.state = false;
			return result;
		}		
	}
}


/**
 * 顧客番号チェック
 * 数字が必須で、ハイフンはあってもなくても可。ただし、ハイフンのみは不可。
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.custNoValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());
	// ハイフンのみの場合はfalse
	if(value.match(/^-+$/g)){
		result.msg = com.getMessage(msg.MESG_E952);
		result.state = false;
		return result;
	}
	// ハイフンと数字はOK
	if (value.match(/^[0-9０-９-]+$/g) ){
		result.state = true;
		return result;
	} else {
		result.msg = com.getMessage(msg.MESG_E952);
		result.state = false;
		return result;
	}		
}

/**
 * 携帯電話番号チェック
 * 090または080のみOK
 * @param target$ チェック対象のJqueryオブジェクト(先頭の3ケタを入力するtextbox)
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.cellValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());

	if (value.match(/^[0０][7-9７-９][0０]$/)){
		result.state = true;
		return result;
	} else {
		result.msg = com.getMessage(msg.MESG_E709);
		result.state = false;
		return result;
	}
}

/**
 * telValidator + 数値の桁数チェック(10,11桁のみOK)
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.telWithSizeCheckValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.toHankaku(com.getInputValue(target$).trim());

	// ハイフンの有無で分岐
	if(value.indexOf("-") > 0) {
		if(value.match(/^[0-9]+\-[0-9]+\-[0-9]+$/) != null) {
			// ハイフンを除いた桁数が10or11じゃない場合はNG
			if (value.split('-').join('').length != 10 && value.split('-').join('').length != 11) {
				result.msg = com.getMessage(msg.MESG_E178);
				result.state = false;
				return result;
			}

			if (value.split('-').join('').indexOf("0") != 0) {
				result.msg = com.getMessage(msg.MESG_E185);
				result.state =  false;
				return result;
			}

			if (value.split('-').join('').indexOf("00") == 0) {
				result.msg = com.getMessage(msg.MESG_E178);
				result.state =  false;
				return result;
			}

			result.state = true;
			return result;
		} else {
			result.msg = com.getMessage(msg.MESG_E178);
			result.state = false;
			return result;
		}
		
	} else {
		if (value.match(/^[0-9０-９]+$/g) ){
			// 桁数が10or11じゃない場合はNG
			if (value.length != 10 && value.length != 11) {
				result.msg = com.getMessage(msg.MESG_E178);
				result.state = false;
				return result;
			}

			if (value.indexOf("0") != 0) {
				result.msg = com.getMessage(msg.MESG_E185);
				result.state =  false;
				return result;
			}

			if (value.indexOf("00") == 0) {
				result.msg = com.getMessage(msg.MESG_E178);
				result.state =  false;
				return result;
			}

			result.state = true;
			return result;
		} else {
			result.msg = com.getMessage(msg.MESG_E178);
			result.state = false;
			return result;
		}		
	}
}

/** 
 * ニックネームチェック
 * 以下のチェックは、個別ルールで対応
 *   全角16文字(半角32文字)以内 -> byteLen ルールで対応
 *   機種依存文字 NG  -> sjisルールで対応
 *   半角カタカナ NG  -> hanKanaNgルールで対応
 * 下記のみnicknameチェックとして検証する。
 *   半角記号「#」「?」「%」「@」「;」「'」「""」「<」「>」「,」「/」「|」「\」「&」 NG
 * 
 *  
 */
validate.nickname = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();
	if(value.indexOf("#") >= 0 || 
		value.indexOf("?") >= 0 ||	
		value.indexOf("%") >= 0 ||	
		value.indexOf("@") >= 0 ||	
		value.indexOf(";") >= 0 ||	
		value.indexOf("'") >= 0 ||	
		value.indexOf("\"") >= 0 ||	
		value.indexOf("<") >= 0 ||	
		value.indexOf(">") >= 0 ||	
		value.indexOf(",") >= 0 ||	
		value.indexOf("/") >= 0 ||	
		value.indexOf("|") >= 0 ||	
		value.indexOf("\\") >= 0 ||	
		value.indexOf("&") >= 0 ) {
		result.msg = com.getMessage(msg.MESG_E179);
		result.state = false;
	} else {
		result.state = true;
	}
	return result;
}

/**
 * メールアドレスフォーマットチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.mailAddressFormatValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// 「任意の文字 + @ or ＠ + 任意の文字」のフォーマットにあっているか
	if (value.match(/^[a-z][0-9a-z_.\-]*(@|＠)[0-9a-z_.\-]+$/g)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E180);
		result.state = false;
	}
	return result;
}

/**
 * メールアドレスフォーマットチェック（フォーマットのみ）
 * <pre>Step1.5対応。<br/>英数記号@英数記号かどうかのみチェック。<br/>先頭数字を許可する。</pre>
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.simpleMailAddressFormatValidator = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// 「任意の文字 + @ or ＠ + 任意の文字」のフォーマットにあっているか
	if (value.match(/^[0-9A-Za-z_.\-]*(@|＠)[0-9A-Za-z_.\-]+$/g)) {
		result.state = true;
	} else {
		result.state = false;
	}
	return result;
}

/**
 * メールアドレスフォーマットチェック（ドメイン有効チェック付き）
 * ▼入力されたメールアドレス全体に対してチェック内容
 * ・メールアドレスが半角であること 
 * ・メールアドレスに「@」が１つだけ存在すること 
 * ・メールアドレスの先頭が「@」でないこと 
 * ・「.」が連続していないこと 
 * 
 * ▼ユーザ名(＠前)に対してのチェック内容
 * ・ユーザー名の先頭および最後尾が「.」でないこと
 * ・ユーザー名は以下の文字であること 
 * ・＠前チェック　=~ /[^a-zA-Z0-9._-]+/
 * 
 * ▼ドメインに対してのチェック
 * ・jsでは行わず、サーバサイドでのみ実行する
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.mailAddressFormatValidatorWithDomainCheck = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	if (value.match(/^[\w-]+[\w\.-]*@[\w\.-]+$/)) {
		if(value.match(/(\.\.|\.@)/)){
			result.msg = com.getMessage(msg.MESG_E180);
			result.state = false;
		} else {
			result.state = true;
		}
	} else {
		result.msg = com.getMessage(msg.MESG_E180);
		result.state = false;
	}

	return result;
}


/**
 * ひらがなチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.hiragana = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// 長音または、ひらがなか
	if (value.match(/^([ー]|[ぁ-ん])+$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E209);
		result.state = false;
	}
	return result;
}

/**
 * 英語表記チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isEigoHyoki = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// 英数か._- (スペース)
	if (value.match(/^[0-9A-Za-z０-９Ａ-Ｚａ-ｚ._\- ．＿‐　]*$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E213);
		result.state = false;
	}
	return result;
}

/**
 * 英字大文字または数字チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isCapitalAndNum = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// 英字大文字または数字
	if (value.match(/^[0-9A-Z０-９Ａ-Ｚ]*$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E214);
		result.state = false;
	}
	return result;
}

/**
 * 英字チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isEiji = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// 英字
	if (value.match(/^[A-Za-zＡ-Ｚａ-ｚ]*$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E215);
		result.state = false;
	}
	return result;
}

/**
 * 属性型JPドメインかなチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.kanaATTR = function(target$) {
	var result = { state:false, msg:"" };

	var value = com.getInputValue(target$).trim();

	// ひらがな、全半角スペース、全角記号(、。・ー「」『』)
	if (value.match(/^([ぁ-ん]|[ 　]|[、]|[。]|[・]|[ー]|[「-』])+$/)) {
		result.state = true;
	} else {
		result.msg = com.getMessage(msg.MESG_E211);
		result.state = false;
	}
	return result;
}

/**
 * 属性型JPドメインの日本語項目チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.attr = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();

	// sjisチェック
	result.state = com.isJisx0208(value);
	if (!result.state) {
		result.msg = com.getMessage(msg.MESG_E175);
		return result;
	}

	for(var i = 0; i < value.length; i++) {
		// 半角カナ、半角記号"<>は不許可
		if (value.charAt(i).match(/[\uFF61-\uFF9F]|[\u0022]|[\u003C]|[\u003E]/)) {
			result.msg = com.getMessage(msg.MESG_E212);
			result.state = false;
			break;
		}
		// 全角記号≪≫￣‐―“”〔〕〈〉《》【】＜＞≪≫は不許可
		if (value.charAt(i).match(/[\u226A]|[\u226B]|[\uFFE3]|[\u2010]|[\u2015]|[\u201C]|[\u201D]|[\u3014]|[\u3015]|[\u3008]|[\u3009]|[\u300A]|[\u300B]|[\u3010]|[\u3011]|[\uFF1C]|[\uFF1E]|[\u226A]|[\u226B]/)) {
			result.msg = com.getMessage(msg.MESG_E212);
			result.state = false;
			break;
		}
		result.state = true;
	}
	return result;
}

/**
 * 属性型JPドメインの英語項目チェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.asciiAttr = function(target$) {
	var result = { state:false, msg:"" };
	var value = com.getInputValue(target$).trim();

	// ascii
	result =validate.isAscii(target$);
	if (result.state) {
		// 半角記号"<>全角記号”“＜＞
		if (value.match(/[\u0022]|[\u003C]|[\u003E]|[\u201C]\[\u201D]|[\uFF1C]|[\uFF1E]/)) {
			result.msg = com.getMessage(msg.MESG_E212);
			result.state = false;
		}else{
			result.state = true;
		}
	} else {
		result.msg = com.getMessage(msg.MESG_E212);
		result.state = false;
	}
	
	return result;
}

/**
 * URLチェック
 * 有効とみなすプロトコルはhttp/httpsのみ
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.isUrl = function(target$) {
	var result = { state:false, msg:"" };
	var orgValue = com.getInputValue(target$).trim();
	var value = encodeURI(orgValue); // URLには漢字が含まれる可能性があるのでURLエンコードする。

	if (value.match(/^https?(:\/\/[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#]+)$/)) {
		result.state = true;
	}else{
		result.msg = com.getMessage(msg.MESG_E212);
		result.state = false;
	}
	return result;
}

//単項目チェックの関数定義	// 各種関数定義後でないとダメ。。 記述順に左右される
// IE6だとJSONが厳密なので最終要素のカンマはきちんと取り除くこと
validate.memberValidateFuncConfig = {
		num: 					validate.isNum,
		minNum:					validate.minNumValidator,
		maxNum:					validate.maxNumValidator,
		decimal:				validate.isDecimal,
		kana:					validate.isKana,
		kanaAscii:				validate.isKanaAscii,
		ascii:					validate.isAscii,
		eisu:					validate.isEisu,
		len:					validate.lengthValidator,
		fixLen:					validate.fixLengthValidator,
		regex:					validate.regexValidator,
		corpTel:				validate.corpTelValidator,
		tel:					validate.telValidator,
		custNo:					validate.custNoValidator,
		cell:					validate.cellValidator,
		telWSizeChck:			validate.telWithSizeCheckValidator,
		nicknmKigou:			validate.nickname,
		byteLen:				validate.byteLengthValidator,
		fixByteLen:				validate.fixByteLengthValidator,
		sjis:					validate.jisX0208Validator,
		sjisRange:				validate.jisX0208RangeValidator,
		mailAddress:			validate.mailAddressFormatValidator,
		simpleMailAddress:   	validate.simpleMailAddressFormatValidator,
		mailAddressWDomainChck:	validate.mailAddressFormatValidatorWithDomainCheck,
		noComma:				validate.noComma,
		noHanKana:				validate.noHanKana,
		noHanSpace:				validate.noHanSpace,
		hiragana:				validate.hiragana,
		eigoHyoki:				validate.isEigoHyoki,
		capitalAndNum:			validate.isCapitalAndNum,
		eiji:					validate.isEiji,
		kanaATTR:				validate.kanaATTR,
		attr:					validate.attr,
		asciiAttr:		validate.asciiAttr,
		url:			validate.isUrl,
		kanaParentheses:		validate.isKanaParentheses
}

// 単項目チェック関数定義追加関数
validate.addValidateFunc = function(name, func) {
	validate.memberValidateFuncConfig[name] = func;
}


//=============================  関連 チェック部品 =======================================
//全部埋まってればOK
validate.allfill = function(target$Array) {
	var result = { state:false, msg:"" };
	for(var i = 0; i < target$Array.length; i++) {
		//一つでも埋まってなかったら NA扱いとする
		if(com.getInputValue(target$Array[i]) == "") {
			result.state = "NA"; 
			return result;
		}
	}
	result.state = "valid";
	return result;
}
//1つでも埋まってたらOK
validate.partfill = function(target$Array) {
	var result = { state:false, msg:"" };
	for(var i = 0; i < target$Array.length; i++) {
		if(com.getInputValue(target$Array[i]) != "") {
			result.state = "valid"; 
			return result;
		}
	}
	// 上記を満たさない場合は、エラーではなく、初期状態に戻す。（blankにする）
	// →Form送信時の必須チェックに引っ掛けるため。
	result.state = "blank"; 
	return result;
}

// YYYYMMが別入力欄の関連チェック
validate.dateYYYYMMValidate = function(target$Array, isOnsubmit) {
	var result = { state:false, msg:"" };
	if (isOnsubmit) {
		//すべて埋まってなかったら NA扱いとする
		var isInput = false;
		for(var i = 0; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]) != "") {
				isInput = true;
			}
		}
		if (!isInput) {
			result.state = "NA"; 
			return result;
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]) == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}
	var yyyy = com.toHankaku(target$Array[0].val());
	var mm  = com.toHankaku(target$Array[1].val());
	mm = mm-1;
	
	var dateObj = new Date(yyyy, mm);
    if(dateObj.getFullYear() == yyyy && dateObj.getMonth() == mm)  {
		result.state = "valid"; 
		return result;
    } else {
    	result.msg = com.getMessage(msg.MESG_E181);
    	result.state = "invalid"; 
		return result;
    }	
}

// 郵便番号が別入力欄の関連チェック */
validate.zipCdValidate = function(target$Array, isOnsubmit) {
	var result = { state:false, msg:"" };
	if (isOnsubmit) {
		//すべて埋まってなかったら NA扱いとする
		var isInput = false;
		for(var i = 0; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]) != "") {
				isInput = true;
			}
		}
		if (!isInput) {
			result.state = "NA"; 
			return result;
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]) == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}

	var zip1 = target$Array[0].val();
	var zip2  = target$Array[1].val();

	if(zip1.match(/^[０-９0-9]{3}$/) && zip2.match(/^[０-９0-9]{4}$/)) {
		result.state = "valid"; 
		return result;
	} else {
    	result.msg = com.getMessage(msg.MESG_E182);
		result.state = "invalid"; 
		return result;
	}
}


/**
 * 即時・日時指定（明日-90日）関連チェック
 * @param target$Array グループ項目JQueryオブジェクト配列
 * @returns  { state: ステータス(NA/valid/invalid), msg:エラーメッセージ };
 */
validate.validateUpdateStartDate = function(target$Array){
	var result = { state: "NA", msg:"" };
	var changeKbn1 =  com.getInputValue(target$Array[0]);
	var changeKbn2 =  com.getInputValue(target$Array[1]);
	var changeYYYY =  com.getInputValue(target$Array[2]);
	var changeMM =  com.getInputValue(target$Array[3]);
	var changeDD =  com.getInputValue(target$Array[4]);
	
	if(changeKbn1 == "0") {
		result.state =  "valid";
		return result;
	} else if(changeKbn2 == "1" && changeYYYY != "" && changeMM != "" && changeDD != "") {

		if(!com.isValidYYYYMMDD(com.toHankaku(changeYYYY),com.toHankaku(changeMM),com.toHankaku(changeDD))) {
	    	result.msg = com.getMessage(msg.MESG_E183);
			result.state =  "invalid";
			return result;
		}
		var date = com.parseDate(com.toHankaku(changeYYYY),com.toHankaku(changeMM),com.toHankaku(changeDD));
		var today = com.getToday();
		var after90 = com.addDaysNow(90);
		// 本日はNG. 90日後までOK
		if(today.getTime() >= date.getTime() || date.getTime() > after90.getTime()) {
			
			var tommorowday = com.addDaysNow(1);
			var tommorowyy = tommorowday.getYear();
			var tommorowmm = tommorowday.getMonth() + 1;
			var tommorowdd = tommorowday.getDate();
			
			if (tommorowyy < 2000) { tommorowyy += 1900; }
			if (tommorowmm < 10) { tommorowmm = "0" + tommorowmm; }
			if (tommorowdd < 10) { tommorowdd = "0" + tommorowdd; }
			
			var tommorowdaystr = tommorowyy + "/" + tommorowmm + "/" + tommorowdd;
			
			var afteryy = after90.getYear();
			var aftermm = after90.getMonth() + 1;
			var afterdd = after90.getDate();
			
			if (afteryy < 2000) { afteryy += 1900; }
			if (aftermm < 10) { aftermm = "0" + aftermm; }
			if (afterdd < 10) { afterdd = "0" + afterdd; }			
			
			var afterdaystr = afteryy + "/" + aftermm + "/" + afterdd;
			
			var strArray = new Array();
			strArray.push(tommorowdaystr);
			strArray.push(afterdaystr);
			result.msg = com.getMessage(msg.MESG_E184, strArray);
			result.state =  "invalid";
			return result;
		}
		result.state =  "valid";
		return result;
	} else {
		result.state =  "NA";
		return result;
	}
}


/**
 * 元号・年・月・日のチェック(small date time)
 * @param target$Array グループ項目JQueryオブジェクト配列
 * @returns  { state: ステータス(NA/valid/invalid), msg:エラーメッセージ };
 */
validate.dateValidate = function(target$Array, isOnsubmit) {
	var result = { state:false, msg:"" };
	if (isOnsubmit) {
		//すべて未入力の場合、 NA扱いとし、本チェックを行わない
		if (com.getInputValue(target$Array[1]) == ""
			&& com.getInputValue(target$Array[2]) == ""
			&& com.getInputValue(target$Array[3]) == "") {
			result.state = "NA";
			return result;
		}

		// すべて未入力の場合は上記でNAとなるため、本個所に到達した場合はすべてうまっていることが前提となる
		// 一つでも埋まってなかったら エラーとする
		for(var i = 1; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]) == "") {
				result.msg = com.getMessage(msg.MESG_E183);
				result.state =  "invalid";
				return result;
			}
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]) == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}

	var gengo =  com.getInputValue(target$Array[0]);
	var year =  com.toHankaku(com.getInputValue(target$Array[1]));
	var month =  com.toHankaku(com.getInputValue(target$Array[2]));
	var day =  com.toHankaku(com.getInputValue(target$Array[3]));
	var cyear = com.wareki2seireki(gengo, year);
	
	var isSmallDateTime = true;
	if(com.isValidYmdWithGengo(gengo, year, month, day, isSmallDateTime)) {
		result.state =  "valid";
	} else {
    	result.msg = com.getMessage(msg.MESG_E183);
		result.state =  "invalid";
	}
	return result;
}

/**
 * 年・月・日のチェック(small date time)
 * @param target$Array グループ項目JQueryオブジェクト配列
 * @returns  { state: ステータス(NA/valid/invalid), msg:エラーメッセージ };
 */
validate.dateValidateSeireki = function(target$Array, isOnsubmit) {
	var result = { state:false, msg:"" };
	if (isOnsubmit) {
		//すべて未入力の場合、 NA扱いとし、本チェックを行わない
		if (com.getInputValue(target$Array[0]) == ""
			&& com.getInputValue(target$Array[1]) == ""
			&& com.getInputValue(target$Array[2]) == "") {
			result.state = "NA";
			return result;
		}

		// すべて未入力の場合は上記でNAとなるため、本個所に到達した場合はすべてうまっていることが前提となる
		// 一つでも埋まってなかったら エラーとする
		for(var i = 0; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]) == "") {
				result.msg = com.getMessage(msg.MESG_E183);
				result.state =  "invalid";
				return result;
			}
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]) == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}

	var gengo =  "C";
	var year =  com.toHankaku(com.getInputValue(target$Array[0]));
	var month =  com.toHankaku(com.getInputValue(target$Array[1]));
	var day =  com.toHankaku(com.getInputValue(target$Array[2]));
	var cyear = com.wareki2seireki(gengo, year);

	var isSmallDateTime = true;
	if(com.isValidYmdWithGengo(gengo, year, month, day, isSmallDateTime)) {
		result.state =  "valid";
	} else {
    	result.msg = com.getMessage(msg.MESG_E183);
		result.state =  "invalid";
	}
	return result;
}

/**
 * 元号・年・月・日のチェック(date time)
 * @param target$Array グループ項目JQueryオブジェクト配列
 * @returns  { state: ステータス(NA/valid/invalid), msg:エラーメッセージ };
 */
validate.dateValidateForDateTime = function(target$Array, isOnsubmit) {
	var result = { state:false, msg:"" };
	if (isOnsubmit) {
		//すべて未入力の場合、 NA扱いとし、本チェックを行わない
		if (com.getInputValue(target$Array[1]) == ""
			&& com.getInputValue(target$Array[2]) == ""
			&& com.getInputValue(target$Array[3]) == "") {
			result.state = "NA";
			return result;
		}

		// すべて未入力の場合は上記でNAとなるため、本個所に到達した場合はすべてうまっていることが前提となる
		// 一つでも埋まってなかったら エラーとする
		for(var i = 1; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]) == "") {
				result.msg = com.getMessage(msg.MESG_E183);
				result.state =  "invalid";
				return result;
			}
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]) == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}

	var gengo =  com.getInputValue(target$Array[0]);
	var year =  com.toHankaku(com.getInputValue(target$Array[1]));
	var month =  com.toHankaku(com.getInputValue(target$Array[2]));
	var day =  com.toHankaku(com.getInputValue(target$Array[3]));
	var cyear = com.wareki2seireki(gengo, year);
	
	var isSmallDateTime = false;
	if(com.isValidYmdWithGengo(gengo, year, month, day, isSmallDateTime)) {
		result.state =  "valid";
	} else {
    	result.msg = com.getMessage(msg.MESG_E183);
		result.state =  "invalid";
	}
	return result;
}

/**
 * 固定電話番号チェック
 * 電話番号1が「0」始まりであるかチェック
 * 電話番号1～2（ハイフンは除く）の合計桁数が6桁であるかチェック
 * 電話番号1～3（ハイフンは除く）の合計桁数が10桁であるかチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.fixTelValidator = function(target$Array, isOnsubmit) {
	var result = { state: "NA", msg: "" };

	if (isOnsubmit) {
		//すべて埋まってなかったら NA扱いとする
		var isInput = false;
		for(var i = 0; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]).trim() != "") {
				isInput = true;
			}
		}
		if (!isInput) {
			result.state = "NA"; 
			return result;
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]).trim() == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}
	
	var num1Str =  com.toHankaku(com.getInputValue(target$Array[0]).trim()).toString();
	var num2Str =  com.toHankaku(com.getInputValue(target$Array[1]).trim()).toString();
	var num3Str =  com.toHankaku(com.getInputValue(target$Array[2]).trim()).toString();

	if (num1Str.indexOf("0") != 0) {
    	result.msg = com.getMessage(msg.MESG_E185);
		result.state =  "invalid";
		return result;
	}

	if (num1Str.indexOf("00") == 0) {
    	result.msg = com.getMessage(msg.MESG_E178);
		result.state =  "invalid";
		return result;
	}

	if (num1Str.concat(num2Str).length != 6) {
    	result.msg = com.getMessage(msg.MESG_E186);
		result.state =  "invalid";
		return result;
	}

	if (num1Str.concat(num2Str).concat(num3Str).length != 10) {
    	result.msg = com.getMessage(msg.MESG_E187);
		result.state =  "invalid";
		return result;
	}

	result.state = "valid";
	return result;
}

/**
 * 関連項目の電話番号チェック
 * 0番始まりであるかチェック
 * 電話番号1～3の合計桁数が10桁以上11桁以下であるかチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.telMultiInputValidator = function(target$Array, isOnsubmit) {
	var result = { state: "NA", msg: "" };

	if (isOnsubmit) {
		//すべて埋まってなかったら NA扱いとする
		var isInput = false;
		for(var i = 0; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]).trim() != "") {
				isInput = true;
			}
		}
		if (!isInput) {
			result.state = "NA"; 
			return result;
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]).trim() == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}

	var num1Str =  com.toHankaku(com.getInputValue(target$Array[0]).trim()).toString();
	var num2Str =  com.toHankaku(com.getInputValue(target$Array[1]).trim()).toString();
	var num3Str =  com.toHankaku(com.getInputValue(target$Array[2]).trim()).toString();

	if (num1Str.indexOf("0") != 0) {
    	result.msg = com.getMessage(msg.MESG_E185);
		result.state =  "invalid";
		return result;
	}

	if (num1Str.indexOf("00") == 0) {
    	result.msg = com.getMessage(msg.MESG_E178);
		result.state =  "invalid";
		return result;
	}

	if (num1Str.concat(num2Str).concat(num3Str).length != 10 && num1Str.concat(num2Str).concat(num3Str).length != 11) {
    	result.msg = com.getMessage(msg.MESG_E208);
		result.state =  "invalid";
		return result;
	}

	result.state = "valid";
	return result;
}

/**
 * 関連項目のMNP電話番号チェック
 * 070、080、090番始まりであるかチェック
 * 電話番号1～3の合計桁数が11桁であるかチェック
 * @param target$ チェック対象のJqueryオブジェクト
 * @returns {state:結果(true/false), msg:"エラーメッセージ"}
 */
validate.mnpMultiInputValidator = function(target$Array, isOnsubmit) {
	var result = { state: "NA", msg: "" };

	if (isOnsubmit) {
		//すべて埋まってなかったら NA扱いとする
		var isInput = false;
		for(var i = 0; i < target$Array.length; i++) {
			if(com.getInputValue(target$Array[i]).trim() != "") {
				isInput = true;
			}
		}
		if (!isInput) {
			result.state = "NA"; 
			return result;
		}
	} else {
		for(var i = 0; i < target$Array.length; i++) {
			//一つでも埋まってなかったら NA扱いとする
			if(com.getInputValue(target$Array[i]).trim() == "") {
				result.state = "NA"; 
				return result;
			}
		}
	}

	var num1Str =  com.toHankaku(com.getInputValue(target$Array[0]).trim()).toString();
	var num2Str =  com.toHankaku(com.getInputValue(target$Array[1]).trim()).toString();
	var num3Str =  com.toHankaku(com.getInputValue(target$Array[2]).trim()).toString();

	if (num1Str.match(/^[0０][7-9７-９][0０]$/) == null){
		result.msg = com.getMessage(msg.MESG_E709);
		result.state = "invalid";
		return result;
	}

	if (num1Str.concat(num2Str).concat(num3Str).length != 11) {
    	result.msg = com.getMessage(msg.MESG_E475);
		result.state =  "invalid";
		return result;
	}
	
	result.state = "valid";
	return result;
}

//グループ検証 関数定義
//IE6だとJSONが厳密なので最終要素のカンマはきちんと取り除くこと
validate.groupValidateFuncConfig = {
		fillAll				: validate.allfill , 
		dateYYYYMM			: validate.dateYYYYMMValidate , 
		zip					: validate.zipCdValidate ,
		validateUpdateStartDate:validate.validateUpdateStartDate,	
		fillPart			: validate.partfill , 
		dateValidate		: validate.dateValidate ,
		dateValidateSeireki	: validate.dateValidateSeireki ,
		dateValidateForDateTime		: validate.dateValidateForDateTime,
		fixTel				: validate.fixTelValidator,
		mnpMultiInput		: validate.mnpMultiInputValidator,
		telMultiInput		: validate.telMultiInputValidator
}

//グループチェック関数定義追加関数
validate.addGroupValidateFunc = function(name, func) {
	validate.groupValidateFuncConfig[name] = func;
}

// グループのメッセージを置き換える。
validate.setGroupErrMessage = function(groupName, message) {
	validate.config[groupName].errmsg = message;
}

//--------------------------------------------------------------------
//Validation初期化処理
validate.initValidation = function() {
	try {
		log("validation init start");
		// jsonファイルがなく、独自チェックを行う場合もあるため、validateLoadJsonが存在しない場合がある
		if (typeof validateLoadJson != "undefined") {
			for(jsonId in validateLoadJson) {
				validate.addConfig(validateLoadJson[jsonId]);
			}
			validateLoadJson = null;
		}
		
		var config = validate.config;
		
		// Validate定義から、存在しないID項目の定義を削除
		for(group in config) {
			var members = config[group].member;
			for(i in members) {
				// フォーム入力エレメントとして存在しなければ削除
				if($("#" + members[i].name +  ":input"  ).length == 0) {
					log("delete from target:" + members[i].name);
					delete config[group].member[i];
				}
			}
		}
		
		// メンバーが空になったら定義自体削除
		for(group in config) {
			if($.isEmptyObject(config[group].member)) {
				delete config[group];
			}
		}
	
		//ステータス初期化
		for(group in config) {
			var members = config[group].member;
			config[group].groupState = "blank";	// グループ定義初期化
			for(i in members) {
				//個別の入力チェックステータス初期化
				if(typeof config[group].member[i].state === "undefined") {
					// 初期状態がない場合のみ初期化
					config[group].member[i].state = "blank";
				}
			}
		}
		// フォーカスアウト イベント設定
		for(group in config) {
			var members = config[group].member;
			for(i in members) {
				var target = $("#" + members[i].name);
				if(target.length) {
					// イベントの設定（ラジオ、チェックボックス、SELECTはchangeイベント）   
					if(com.isRadio(target) || com.isCheckbox(target)|| com.isSelect(target) ) {
						target.change(function(event){
							// submit時validationエラー直後のblur,change validationは行わない
							if (validate.isJustAfterSubmitValidationError()) {
								return;
							}
							try {
								validate.doValidate($(this), event);
							} catch (e) {
								log(e.name);
								log(e.message);
							}
						});
					} else {
						target.blur(function(event){
							// submit時validationエラー直後のblur,change validationは行わない
							if (validate.isJustAfterSubmitValidationError()) {
								return;
							}
							try {
								validate.doValidate($(this), event);
							} catch (e) {
								log(e.name);
								log(e.message);
							}
						});
					}
				}
			}
		}
		
		
		// 「送信ボタン」へイベント設定（Validatorオフ指定ボタン用）
		// 送信ボタンに validatorOff クラスが指定されているとValidationは実施しない
		$("input:submit").click(function(){
			if ($(this).hasClass("validatorOff")) {
				$("form").data("validatorOff", true);

				// サーバーサイドValidator無効化（サーバーサイドvalidatorオフhidden項目があればtrue設定。無ければ追加）
				var validatorOffElm = $("#validatorOff");
				if(validatorOffElm.size() > 0) {
					$("#validatorOff").val("true");
				} else {
					$("form").append("<input type='hidden' id='validatorOff' name='validatorOff' value='true' />");
				}
			} else {
				$("form").removeData("validatorOff");
				// サーバーサイドValidator有効化（サーバーサイドvalidatorオフを無効）
				var validatorOffElm = $("#validatorOff");
				if(validatorOffElm.size() > 0) {
					$("#validatorOff").val("false");
				}
			}
		});

		// フォームイベント設定
		$("form").submit(function(e) {
			// d-articleクラスを使用していないFormではそのまま抜ける。
			if(($(this).find(".d-article")).length == 0) {
				return;
			}

			// formのtargetが指定されていた場合は、新規Window表示と判断し抜けイベント実行
			if($(this).attr("target")) {
				return true;
			}

			// 共通側で入れたフォーム2重送信のステータスを除去
			$(this).removeData("lastSubmitTime");
			
			var isSubmit = true;
			var lastTime = $(this).data("lastSubmitTimeValidate");
			if (lastTime && typeof lastTime === "object") {
				var now = new Date();
				if ((now - lastTime) > env.preventDoubleFormSubmitTimeOut) // TimeOut指定
					isSubmit =  true;
				else
					isSubmit = false;
			}
			if(isSubmit) {
				var validatorOff = $(this).data("validatorOff");
				if(validatorOff) {
					$(this).data("lastSubmitTimeValidate", new Date());
					// 入力チェックしない。かつKPIのフォーム送信OKの通知も行わない
				} else {
					if(!validate.doValidateAll(true, e)) {
						// submit時のvalidationエラー時刻
						validate.lastSubmitTimeValidateError = new Date();

						// JSエラー発生時にエラーになった最初の項目へフォーカスセット。
						var errElements = $(".d-err");
						if(errElements.length > 0) {
							// errElementsの中から最初に表示が有効な物（座標が0以外）へフォーカスセット
							var firstView$Obj = com.retrieveFirstViewElement(errElements);
							if(firstView$Obj) {
								com.smoothFocusSelect(firstView$Obj);
							}
						}
						e.preventDefault();
					} else {
						$(this).data("lastSubmitTimeValidate", new Date());
						// 入力チェックOK。 KPIログへフォーム入力チェック情報を送信する。
						kpiLog.sendSmRData(e.target);
					}
				}
			} else {
				e.preventDefault();
			}
		});

		log("validation init end");
	} catch (e) {
		log(e.name);
		log(e.message);
	}
}

/** 項目IDから項目メンバー定義を返す */
validate.getMemberConfig = function(id) {
	var groupConfig = validate.getGroupConfig(id); 
	for(i in groupConfig.member) {
		if(groupConfig.member[i].name == id) {
			return groupConfig.member[i];
		}
	}
}

//====================== メイン処理 
//--------------------------------------------------------------------
//検証メイン処理
//引数：TargetのJQueryオブジェクト
validate.doValidate = function(target, event, isOnsubmit) {
	// JS Validator機能全体の有効・無効の確認
	if(this.allDisable == true) {
		return;
	}
	var startTime = new Date();
	try {
		log("doValidate start");
		
		if(target.length == 0) {
			log("要素なし:" + target.selector);
			return;
		}
	
		var id = $(target).attr("id");
		var val = com.getInputValue(target);
	
		// 検証定義の取得
		var groupConfig = validate.getGroupConfig(id); 
		if(groupConfig == null || typeof groupConfig === "undefined") {
			log("チェック定義が無い:" + id);
			return;
		}

		// validation対象外の場合はチェックを行わない
		var ignoreValidateListValue = $("#ignoreValidateList").val();
		if (ignoreValidateListValue && "" != ignoreValidateListValue) {
			var ignoreValidateListValueArray = ignoreValidateListValue.split(",");
			for (var i = 0; i < ignoreValidateListValueArray.length; i++) {
				if (ignoreValidateListValueArray[i] == groupConfig.groupid) {
					log("validation対象外:" + groupConfig.groupid);
					return;
				}
			}
		}

		// 入力を空にした場合の判断（ラジオとチェックボックスは除外）
		if((val == "" && !com.isRadio(target) && !com.isCheckbox(target))) {
			//背景色クリアし、初期状態へ戻す
			if(validate.getMemberConfig(id).state != "requiredError") {
				UiUtils.clearErrField(target);
				validate.getMemberConfig(id).state = "blank";
			}
		} else {
			//単項目チェック
			var memberValidateResult = validate.memberValidate(validate.getMemberConfig(id).validate, target);
			if(memberValidateResult.state != true) {
				// 単項目エラー
				UiUtils.showErrField(target);
				UiUtils.showErrMsg(target, memberValidateResult.msg); // 単項目エラーのエラーメッセージを優先して表示。
				validate.getMemberConfig(id).state = "invalid";
				groupConfig.groupState = "invalid";
				
			} else {
				// 単項目OK
				UiUtils.clearErrField(target);
				validate.getMemberConfig(id).state = "valid";
	
			}
		}
		//グループ内にエラーがある場合は、グループチェックをしないで抜ける
		for(var elm in groupConfig.member) {
			if(groupConfig.member[elm].state == "invalid") {
				UiUtils.removeReqChkMark(target);
				return;
			}
		}
	
		// グループレベルでのチェック
		var grpValidateResult = validate.doGrpValidate(groupConfig, isOnsubmit);
		if(grpValidateResult.state == "valid") {
			//OK
			UiUtils.clearErrMsg(target);
			groupConfig.groupState = "valid";
			for(var elm in groupConfig.member) {
				UiUtils.clearErrField($("#" + groupConfig.member[elm].name));
			}
		} else 	if(grpValidateResult.state == "invalid") {
			//NG
			var errMessage = grpValidateResult.msg != "" ? grpValidateResult.msg : groupConfig.errmsg; 
			UiUtils.showErrMsg(target, errMessage);
			// グループの全項目の背景色をエラーにする
			for(var elm in groupConfig.member) {
				UiUtils.showErrField($("#" + groupConfig.member[elm].name));
			}
			
			groupConfig.groupState = "invalid";
			
		} else 	if(grpValidateResult.state == "NA") {
			//NA チェック不要。グループ内の他の項目でエラーが無ければエラーメッセージのクリア、グループ検証定義のクリア
			if(!this.isExistMemberInvalid(groupConfig)) {
				UiUtils.clearErrMsg(target);
				groupConfig.groupState = "blank";
				for(var elm in groupConfig.member) {
					UiUtils.clearErrField($("#" + groupConfig.member[elm].name));
				}
			}
			
		} else {
			throw {
				name: "グループ検証結果が不正",
				message: "グループ検証結果が不正:" +  grpValidateResult
			};
		}
	
		//必須指定項目の場合は、グループの検証結果から OKマーク制御 
		if(groupConfig.required == true) {
			if(groupConfig.groupState == "valid") {
				UiUtils.setReqChkMark(target);
				// グループレベルで検証OKなので、グループ内の項目のステータスを空ならblank値ありならvalidに設定。
				for(var elm in groupConfig.member) {
					var val = com.getInputValue($("#" + groupConfig.member[elm].name));
					if(val == "") {
						 groupConfig.member[elm].state = "blank";
					} else {
						 groupConfig.member[elm].state = "valid";
					}
				}
			} else {
				UiUtils.removeReqChkMark(target);
			} 
		}
		log("doValidate end");
		// log(validate.config);
		
		
		log((new Date() - startTime) + "ミリ秒 -" + id);
		
	} catch (e) {
		log(e.name);
		log(e.message);
	}
}



//単項目検証
//@validateKbn カンマ区切りで複数の検証処理を指定可能   
//@target 対象のJQueryオブジェクト
//@returns {state: true:検証OK false:検証NG , msg: エラーメッセージ}
validate.memberValidate = function(validateKbn, target$) {
	var result = { state:false, msg:"" };
	if(validateKbn == "") {
		result.state=  true;	//検証不要
	} else {
		var validateKbnArray = validateKbn.split(",");
		for(var i = 0; i < validateKbnArray.length; i++) {
			var funcExpr = validateKbnArray[i].trim();
			if(funcExpr.indexOf("(") > 0) {
				var m = funcExpr.match(/([_a-zA-Z]+)\((.+)\)/);
				var funcName = m[1];
				var args =  m[2];
			} else {
				var funcName = funcExpr;
				var args = "";
			}
			// 単項目検証関数取得
			var targetFunc = validate.memberValidateFuncConfig[funcName];
			if(targetFunc) {
				result = targetFunc(target$, args);
				// チェック関数側でメッセージが設定されていなければ、メッセージ取得
				if(result.state == false) {
					// KPIログへ入力エラー情報をスタック
					kpiLog.stackInputError(target$.attr("id"),  funcExpr);

					return result;
				} else {
					continue;
				}
			} else {
				log("対象の単項目検証関数が無い:" + funcName);
				result.state=  true;
			} 		
		}
	}
	return result ;
}


/**
 * グループ検証
  @returns {state: "NA": 項目不足等でValidationできない場合に指定 , "valid":検証OK, "invalid": 検証NG}  
 */
validate.doGrpValidate = function(groupConfig, isOnsubmit) {

	var result = { state:false, msg:"" };
	  
	// グループ用に対象データJQueryオブジェクト配列を生成
	var value$Array = new Array();
	for(var i in groupConfig.member) {
		value$Array.push($("#" + groupConfig.member[i].name));
	}
	
	var grpValidateRule = groupConfig.validate;
	if(grpValidateRule == "") {
		result.state=  "valid";
	} else {
		// 関連チェックは、値ではなくJQueryオブジェクトの配列として渡す。順序は項目定義順
		// グループ 検証関数取得
		var targetFunc = validate.groupValidateFuncConfig[groupConfig.validate];
		if(targetFunc) {
			result = targetFunc(value$Array, isOnsubmit);
			if(result.state == "invalid") {
				// KPIログへ入力エラー情報をスタック
				kpiLog.stackInputErrorArray(groupConfig.groupid,  value$Array, groupConfig.validate);
			}
			
		} else {
			log("対象のグループ検証関数が無い:" + groupConfig.validate);
			result.state=  "valid";
		} 		
	}
	return result;
}

// 初期表示時、フォーム送信前の総チェック処理
validate.doValidateAll = function(isOnsubmit, event) {
	// KPI必須エラー送信フラグの初期化
	validate.isKpiSendedRequredError = false;	
	
	// JS Validator機能全体の有効・無効の確認
	if(this.allDisable == true) {
		return true;
	}

	log("validatea all start");
	var isAllValid = true;
	var startTime = new Date();
	// 全メンバーをvalidate実行
	var config = validate.config;

	//ステータス初期化
	for(group in config) {
		var members = config[group].member;
		config[group].groupState = "blank";	// グループ定義初期化
		for(i in members) {
			//個別の入力チェックステータス初期化
			config[group].member[i].state = "blank";
		}
	}	

	for(group in config) {
		var members = config[group].member;
		for(i in members) {
			var target = $("#" + members[i].name);
			if(target.length) {
				// グループチェックでNGになった場合はチェックしない
				if(config[group].groupState && config[group].groupState == "invalid") {
					continue;
				}
				// すでにメンバーエラーの場合はチェックしない
				if(members[i].state && members[i].state == "invalid") {
					continue;
				}
				this.doValidate(target, null, isOnsubmit);
			}
		}
	}

	// 必須項目が全てOKか。必須かつ初期状態の場合に必須マーク設定
	for(group in validate.config) {
		// validation対象外の場合はチェックを行わない
		var ignoreValidateListValue = $("#ignoreValidateList").val();
		if (ignoreValidateListValue && "" != ignoreValidateListValue) {
			var ignoreValidateListValueArray = ignoreValidateListValue.split(",");
			var isIgnore = false;
			for (var i = 0; i < ignoreValidateListValueArray.length; i++) {
				// validation対象外の場合はチェックを行わない
				if (ignoreValidateListValueArray[i] == group) {
					isIgnore = true;
					log("必須validation対象外:" + group);
					break;
				}
			}
			if (!isIgnore) {
				// チェックを行う
				if(validate.config[group].required == true && validate.config[group].groupState == "blank") {
					// フォーム送信時は、必須項目エラー表示
					if(isOnsubmit) {
						this.setRequiredError(validate.config[group]);
						validate.config[group].groupState == "invalid";
						isAllValid = false;
					}
				}
			}
		}　else {
			// チェックを行う
			if(validate.config[group].required == true && validate.config[group].groupState == "blank") {
				// フォーム送信時は、必須項目エラー表示
				if(isOnsubmit) {
					this.setRequiredError(validate.config[group]);
					validate.config[group].groupState == "invalid";
					isAllValid = false;
				}
			}
		}
	}

	for(group in validate.config) {
		if(validate.config[group].groupState == "invalid") {
			// エラーがあったらNG
			isAllValid = false;
		}
	}

	// 独自チェック（送信ボタン押下時のみ）
	if(isOnsubmit) {
		for (var i = 0; i < orgValidate.pageValidate.length; i++) {
			var orgValidateFunc = orgValidate.pageValidate[i];
			if (orgValidateFunc && typeof orgValidateFunc == "function") {
				if (!orgValidateFunc()) {
					isAllValid = false;
				}
			}
		}
	}

	log("---" + (new Date() - startTime) + "ミリ秒かかりました");
	
	if(isAllValid) {
		log("====Validateion TRUE====");
		return true;
	} else {
		log("====Validateion FALSE====");
		return false;
	}
}


//定義を追加する。
validate.addConfig = function(configJson) {
	//オブジェクトのDeepコピー
	$.extend(true, this.config, configJson);
}

//validation対象外リストに項目を追加する
validate.addToIgnoreValidateList = function(addValue) {
	var value = $("#ignoreValidateList").val();
	if (addValue instanceof Array) {
		for(var i = 0; i < addValue.length; i++) {
			if (!$.isEmptyObject(value) && "" != value) {
				if (validate.existsInIgnoreValidateList(addValue[i])) {
					// 重複の場合は足さない
					continue;
				}
				value = value + "," + addValue[i];
			} else {
				value = addValue[i];
			}
		}
	} else {
		if (!$.isEmptyObject(value) && "" != value) {
			if (!validate.existsInIgnoreValidateList(addValue)) {
				// 重複でない場合のみ足す
				value = value + "," + addValue;
			}
		} else {
			value = addValue;
		}
	}
	$("#ignoreValidateList").val(value);

	// ignoreValidateListに入っているルールのgroupState、メンバのstateをblankに初期化する
	for(group in validate.config) {
		// validation対象外の場合はチェックを行わない
		var ignoreValidateListValue = $("#ignoreValidateList").val();
		if (ignoreValidateListValue && "" != ignoreValidateListValue) {
			var ignoreValidateListValueArray = ignoreValidateListValue.split(",");
			for (var i = 0; i < ignoreValidateListValueArray.length; i++) {
				// validation対象外の場合はチェックを行わない
				if (ignoreValidateListValueArray[i] == group) {
					var members = validate.config[group].member;
					// グループ定義初期化
					validate.config[group].groupState = "blank";
					for(member in members) {
						// 初期状態がない場合のみ初期化
						validate.config[group].member[member].state = "blank";
					}
				}
			}
		}
	}
}

//validation対象外リストから項目を除去する
validate.removeFromIgnoreValidateList = function(removeValue) {
	var value = $("#ignoreValidateList").val();
	var values = new Array();
	if (!$.isEmptyObject(value) && "" != value) {
		values = value.split(",");
	}

	if (removeValue instanceof Array) {
		for (var i = 0; i < removeValue.length; i++) {
			for (var j = 0; j < values.length; j++) {
				if (removeValue[i] == values[j]) {
					values.splice(j, 1);
					break;
				}
			}
		}
	} else {
		for (var j = 0; j < values.length; j++) {
			if (removeValue == values[j]) {
				values.splice(j, 1);
				break;
			}
		}
	}

	$("#ignoreValidateList").val(values.join(","));
}

//validation対象外リストの中身をクリアする
validate.clearIgnoreValidateList = function() {
	$("#ignoreValidateList").val("");
}

//=============================  内部処理 =======================================
// 指定したグループIDに含まれるメンバーの背景色を必須エラーにする。
validate.setRequiredError = function(group) {
	for(i in group.member) {
		var target = $("#" + group.member[i].name);
		if(group.member[i].state && group.member[i].state == "requiredError") {
			UiUtils.showErrField(target);
			UiUtils.showErrMsg(target, com.getMessage(msg.MESG_E160));
			continue;
		}
		if(com.getInputValue(target) == "") {
			group.member[i].state = "requiredError";
			UiUtils.showErrField(target);
			UiUtils.showErrMsg(target, com.getMessage(msg.MESG_E160));
			// 必須エラーのKPIログ送信（1回のフォーム送信ボタン押下で1度のみ送信）
			if(!validate.isKpiSendedRequredError) {
				kpiLog.stackInputError(target.attr("id"),  "requiredError");
				validate.isKpiSendedRequredError = true;
			}
		}
	}
}
// 必須エラーをKPIエラーログで送信したかのフラグ（true:すでに送信済み、false：未送信）
// KPI必須エラーは、フォーム送信ボタン1回に付き1回のみとする。
validate.isKpiSendedRequredError = false;


//入力項目のIDからIDが含まれているグループ定義を返す（戻りは１つ）
validate.getGroupConfig = function(targetId) {
	for(var e in this.config) {
		var vdCfg = this.config[e];
		for(var i in vdCfg.member) {
			if(vdCfg.member[i].name == targetId) {
				vdCfg.groupid = e;
				return vdCfg;
			}
		}
	}
	return null;
}

// グループ定義の各項目でエラーが有るかを返す。 true: エラーがある。 false：エラーなし
validate.isExistMemberInvalid = function(groupConfig) {
	var result = false;
	for(i in groupConfig.member) {
		if(groupConfig.member[i].state == "invalid" || groupConfig.member[i].state == "requiredError") {
			result = true;
			break;
		}
	}
	return result;
}

// submit時のvalidationエラー直後かどうか判定する
validate.isJustAfterSubmitValidationError = function() {
	var lastTime = validate.lastSubmitTimeValidateError;
	if (lastTime && typeof lastTime === "object") {
		var now = new Date();
		if ((now - lastTime) <= env.preventBlurValidationAfterSubmitValidationErrorTimeOut) {
			// submit時のvalidationエラー直後にblur,changeのvalidationが動いた場合はスルーさせる
			// フィールドにフォーカスがあたっている状態でエンター押下し、submitした場合の対応
			// 特定のブラウザ(すべてのブラウザをためしていないが、IE8はNG、chrome,firefoxはOK)で
			// 上記のとおりエンター押下した場合、submit時のチェックが動いた後に
			// submitボタンにフォーカスが移る処理が動くため、submit時のチェックでエラーと表示していても、
			// blur,changeのチェックでエラーとしていた個所を正常になおされてしまうため
			// (submitとblur,changeで挙動が若干違うgroupチェックでエラーとなった場合のみの動き)
			return true;
		}
	}
	return false;	
}

validate.existsInIgnoreValidateList = function(addValue) {
	var value = $("#ignoreValidateList").val();
	var values = new Array();
	if (!$.isEmptyObject(value) && "" != value) {
		values = value.split(",");
	}
	for (var i = 0; i < values.length; i++) {
		if (values[i] == addValue) {
			return true;
		}
	}
	return false;
}

//-------------------------------------------------------------
//必須OKマークセット(直近のd-dataのクラス変更)
var UiUtils = {}; 

UiUtils.setReqChkMark = function(target) {
	//	var mark = $(target).closest("td.d-data");
		var mark = $(target).parents("td.d-data");
		mark.addClass("d-data-ok").removeClass("d-data");
};
//必須OKを取り除く(直近のd-data-okのクラス変更)	
UiUtils.removeReqChkMark = function(target) {
//	var mark = $(target).closest("td.d-data-ok");
	var mark = $(target).parents("td.d-data-ok");
	mark.removeClass("d-data-ok").addClass("d-data");
};
//エラーメッセージを表示
UiUtils.showErrMsg = function(target, msg) {
	// 直近のd-cautionエリア
	var msgObj = $(target).parents("td").find(".d-caution");

	// targetが含まれる検証定義の取得
	var id = $(target).attr("id");
	var groupConfig = validate.getGroupConfig(id); 
	if(groupConfig != null && typeof groupConfig != "undefined") {
		// 検証定義が取得できた場合は、「検証定義のID + _msg」の文字列でメッセージ表示エリアを探す
		var groupIdMsgObj = $("#" + groupConfig.groupid + "_msg");
		if (groupIdMsgObj.length > 0) {
			msgObj = groupIdMsgObj;
		}
	}

	msgObj.removeClass("d-hide").html(msg);
};
//エラーメッセージを表示(メッセージ表示targetのID指定)
UiUtils.showErrMsgById = function(targetId, msg) {
	$("#" + targetId).removeClass("d-hide").html(msg);
};
//エラーメッセージをクリア
UiUtils.clearErrMsg = function(target) {
	// 直近のd-cautionエリア
	var msgObj = $(target).parents("td").find(".d-caution");

	// targetが含まれる検証定義の取得
	var id = $(target).attr("id");
	var groupConfig = validate.getGroupConfig(id); 
	if(groupConfig != null && typeof groupConfig != "undefined") {
		// 検証定義が取得できた場合は、「検証定義のID + _msg」の文字列でメッセージ表示エリアを探す
		var groupIdMsgObj = $("#" + groupConfig.groupid + "_msg");
		if (groupIdMsgObj.length > 0) {
			msgObj = groupIdMsgObj;
		}
	}

	msgObj.addClass("d-hide").text("");
};
//エラーメッセージをクリア(メッセージ表示targetのID指定)
UiUtils.clearErrMsgById = function(targetId) {
	$("#" + targetId).addClass("d-hide").text("");
};
//入力コントロールの背景をエラー色変更 
UiUtils.showErrField = function(target) {
	$(target).addClass("d-err");
};
//入力コントロールの背景色クリア 
UiUtils.clearErrField = function(target) {
	$(target).removeClass("d-err");
};
//「Name属性指定」入力コントロールの背景をエラー色変更 
UiUtils.showErrFieldByName = function(name) {
	$.each($("*[name=" + name + "]"), function(){ $(this).addClass("d-err") });
};
//「Name属性指定」入力コントロールの背景色クリア 
UiUtils.clearErrFieldByName = function(name) {
	$.each($("*[name=" + name + "]"), function(){ $(this).removeClass("d-err") });
};


// 独自チェック
var orgValidate = {};
orgValidate.pageValidate = new Array();
