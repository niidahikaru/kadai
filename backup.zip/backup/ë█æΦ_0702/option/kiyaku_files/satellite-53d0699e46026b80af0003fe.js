window.WRInitTime=(new Date()).getTime();
