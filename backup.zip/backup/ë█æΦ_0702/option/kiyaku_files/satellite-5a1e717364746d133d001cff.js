_satellite.pushBlockingScript(function(event, target, $variables){
  (function(){
  if(typeof getSmRlogs==="function"){
    var log = getSmRlogs();
    if(log && log.id==="UICHG0230" && log.action==="CHG" && log.course && log.course.match(/^.+,HCO[EW]/)!=null){

      document.write('<scr' + 'ipt src="//platform.twitter.com/oct.js" type="text/javascript"></scr' + 'ipt>');
      document.write('<scr' + 'ipt type="text/javascript">twttr.conversion.trackPid("nyijh", { tw_sale_amount: 0, tw_order_quantity: 0 });</scr' + 'ipt>');
    }
  }
})();
});
