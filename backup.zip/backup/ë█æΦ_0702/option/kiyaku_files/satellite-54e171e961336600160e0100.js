var glb_pageName,
    glb_prtcl=location.protocol,
    glb_domain=location.hostname,
    glb_path=location.pathname,
    glb_query=location.search;
glb_path=glb_path.replace(/\/index\.\w+/,"");
glb_path=glb_path.replace(/\/$/,"");
glb_pageName=glb_prtcl+"//"+glb_domain+glb_path;

var sc_leanSect={
	"news":"event901",
	"search":"event902",
	"travel":"event903",
	"job":"event904",
	"webmail":"event905",
	"anyone":""
}

function sc_surviceLean(sect){
	if(!sect)return "";
	var sc_sect=sect;
		sc_lean=sc_getCk("sc_lean"),
		sc_leanAry=new Array(),
		sc_leanAry2=new Array(),
		sc_leanEvt=sc_leanSect[sect],
		sc_baseDate=new Date(),
		sc_timeStp=sc_baseDate.getTime(),
		sc_ckyTime=sc_baseDate.setTime(sc_timeStp+(1000*60*60*24*30)),
		sc_date1st=sc_baseDate.getFullYear()+"/"+sc_baseDate.getMonth()+"/"+sc_baseDate.getDate(),
		sc_leanNewFlg=true;
	if(typeof sc_leanEvt=="undefined")return "";
	if(sc_lean!=""){
		sc_leanAry=sc_lean.split(">");
		for(var i=0;sc_leanAry.length>i;i++){
			var sc_leanObj=sc_leanAry[i].split(":")[0],
				sc_leanVal=sc_leanAry[i].split(":")[1]-0,
				sc_leanTst=sc_leanAry[i].split(":")[2]-0;
			if(sc_leanObj==sc_sect){
				//if(43200000<(sc_timeStp-sc_leanTst)){
				if(10800000<(sc_timeStp-sc_leanTst)){//3 hours gap
					sc_leanVal++;
					SmR.events=SmR.events?SmR.events+","+sc_leanEvt:sc_leanEvt;
				}
				sc_leanNewFlg=false;
				sc_lean=sc_sect+":"+sc_leanVal+":"+sc_timeStp;
			}else{
				sc_leanAry2.push(sc_leanAry[i]);
			}
		}
		if(sc_leanNewFlg){
			SmR.eVar76=sc_sect+"_"+sc_date1st;
			SmR.events=SmR.events?SmR.events+","+sc_leanEvt:sc_leanEvt;
			sc_setCk("sc_lean",sc_lean+">"+sc_sect+":1:"+sc_timeStp,sc_ckyTime,"so-net.ne.jp");
		}else{
			sc_leanAry2.push(sc_lean);
			sc_lean=sc_leanAry2.join(">");
			sc_setCk("sc_lean",sc_lean,sc_ckyTime,"so-net.ne.jp");
		}
	}else{
		sc_setCk("sc_lean",sc_sect+":1:"+sc_timeStp,sc_ckyTime,"so-net.ne.jp");
		SmR.events=SmR.events?SmR.events+","+sc_leanEvt:sc_leanEvt;
		SmR.eVar76=sc_sect+"_"+sc_date1st;
	}
}
