_satellite.pushAsyncScript(function(event, target, $variables){
  (function(){
  var w=window,
      uid= -1;
  if(typeof getSmRlogs==="function"){
    var log = getSmRlogs();
    if(log && log.course && log.course.match(/^.+,HCO[EW]/)!==null){
      uid=24144;
    }else if(log && log.course && log.course.match(/^.+,AUHK/)!==null){
      uid=24138;
    }else if(log && log.course && log.course.match(/^.+,WM2P/)!==null){
      uid=24142;
    }

    if(uid>-1){
      if(!w._fout_queue) w._fout_queue = {};
      if(!w._fout_queue.segment) w._fout_queue.segment = {};
      if(!w._fout_queue.segment.queue) w._fout_queue.segment.queue = [];

      w._fout_queue.segment.queue.push({
        'user_id': uid
      });

      var el = document.createElement('script');
      el.type = 'text/javascript'; el.async = true;
      el.src = (('https:' == document.location.protocol) ? 'https://' : 'http://') + 'js.fout.jp/segmentation.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(el, s);
    }
  }
})();
});
