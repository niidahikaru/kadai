﻿var SOAC_Sales = function() {};
SOAC_Sales.prototype.salesOnLoad = function() {
	soacCommon.searchButtonEvent();
	soacSales.initChangeRecommend();
	soacCommon.getAllTabElements();
	soacSales.initBaynoteTab1();
	soacSales.getQuickSearchCookie();
	soacSales.displayQuickSearch({fade:true});
	soacSales.initBoxToggle();
}
SOAC_Sales.prototype.initChangeRecommend = function() {
	var urlStr = location.href;
	var urlSplitted = urlStr.split("://")[1];
	var urlSplitted = urlSplitted.split("?")[0].split("#")[0];
	var urlSplitted = urlSplitted.split("/index.html")[0];
	if (urlSplitted.indexOf("www.ntel-signup.com") >= 0){
	} else {
		var urlFolders = urlSplitted.split("/");
		var newUrlFolders = new Array();
		for (var i = 0; i < urlFolders.length; i++){
			if (i > 0){
				newUrlFolders.push(urlFolders[i]);
			}
		}
		urlSplitted = newUrlFolders.join("/");
		if (urlSplitted.indexOf(".htm") >= 0){
			urlSplitted = "/" + urlSplitted;
		} else if (newUrlFolders.length > 0 && !newUrlFolders[newUrlFolders.length - 1]){
			urlSplitted = "/" + urlSplitted;
		} else {
			urlSplitted = "/" + urlSplitted + "/";
		}
		if (urlSplitted == "/access/change/"){
			var newRecDom = document.getElementById("baynote_canprec_new");
			var changeRecDom = document.getElementById("baynote_canprec_member");
			if (newRecDom){
				soacCommon.setCss({
					dom:				newRecDom,
					cssProperties:		[
						{"key":"display",			"value":"none"}
					]
				});
			}
			if (changeRecDom){
				soacCommon.setCss({
					dom:				changeRecDom,
					cssProperties:		[
						{"key":"display",			"value":"block"}
					]
				});
			}
		}
	}
}
SOAC_Sales.prototype.initBaynoteTab1 = function() {
	soacCommon.baynoteTabBtn01 = document.getElementById("baynote_tab_btn01");
	soacCommon.baynoteTabBtn02 = document.getElementById("baynote_tab_btn02");
	soacCommon.baynoteTabBtn03 = document.getElementById("baynote_tab_btn03");
	if (soacCommon.baynoteTabBtn01 && soacCommon.baynoteTabBtn02 && soacCommon.baynoteTabBtn03){
		soacCommon.baynoteTabBtn01.onclick = soacSales.onClickBaynoteTabBtn01;
		soacCommon.baynoteTabBtn02.onclick = soacSales.onClickBaynoteTabBtn02;
		soacCommon.baynoteTabBtn03.onclick = soacSales.onClickBaynoteTabBtn03;
	}
}
SOAC_Sales.prototype.getBaynoteTabContents = function() {
	if (!soacCommon.baynoteTabcanprecNewHikari){
		soacCommon.baynoteTabcanprecNewHikari = document.getElementById("baynote_tabcanprec_new_hikari");
	}
	if (!soacCommon.baynoteTabcanprecNewAdsl){
		soacCommon.baynoteTabcanprecNewAdsl = document.getElementById("baynote_tabcanprec_new_adsl");
	}
	if (!soacCommon.baynoteTabcanprecNewMobile){
		soacCommon.baynoteTabcanprecNewMobile = document.getElementById("baynote_tabcanprec_new_mobile");
	}
	if (!soacCommon.baynoteTabcanprecMemberHikari){
		soacCommon.baynoteTabcanprecMemberHikari = document.getElementById("baynote_tabcanprec_member_hikari");
	}
	if (!soacCommon.baynoteTabcanprecMemberAdsl){
		soacCommon.baynoteTabcanprecMemberAdsl = document.getElementById("baynote_tabcanprec_member_adsl");
	}
	if (!soacCommon.baynoteTabcanprecMemberMobile){
		soacCommon.baynoteTabcanprecMemberMobile = document.getElementById("baynote_tabcanprec_member_mobile");
	}
	if (!soacCommon.baynoteTabcanprecServiceHikari){
		soacCommon.baynoteTabcanprecServiceHikari = document.getElementById("baynote_tabcanprec_service_hikari");
	}
	if (!soacCommon.baynoteTabcanprecServiceAdsl){
		soacCommon.baynoteTabcanprecServiceAdsl = document.getElementById("baynote_tabcanprec_service_adsl");
	}
	if (!soacCommon.baynoteTabcanprecServiceMobile){
		soacCommon.baynoteTabcanprecServiceMobile = document.getElementById("baynote_tabcanprec_service_mobile");
	}
}
SOAC_Sales.prototype.onClickBaynoteTabBtn01 = function() {
	soacSales.getBaynoteTabContents();
	var iev = soacCommon.getIeVersion();
	soacCommon.baynoteTabBtn01.className = "btn01on";
	soacCommon.baynoteTabBtn02.className = "btn02";
	soacCommon.baynoteTabBtn03.className = "btn03";
	if (soacCommon.baynoteTabcanprecNewHikari && soacCommon.baynoteTabcanprecNewAdsl && soacCommon.baynoteTabcanprecNewMobile){
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecNewHikari,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecNewHikari,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecNewHikari});
		}
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecNewAdsl,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecNewMobile,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
	}
	if (soacCommon.baynoteTabcanprecMemberHikari && soacCommon.baynoteTabcanprecMemberAdsl && soacCommon.baynoteTabcanprecMemberMobile){
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecMemberHikari,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecMemberHikari,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecMemberHikari});
		}
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecMemberAdsl,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecMemberMobile,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
	}
	if (soacCommon.baynoteTabcanprecServiceHikari && soacCommon.baynoteTabcanprecServiceAdsl && soacCommon.baynoteTabcanprecServiceMobile){
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecServiceHikari,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecServiceHikari,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecServiceHikari});
		}
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecServiceAdsl,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecServiceMobile,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
	}
	return false;
}
SOAC_Sales.prototype.onClickBaynoteTabBtn02 = function() {
	soacSales.getBaynoteTabContents();
	var iev = soacCommon.getIeVersion();
	soacCommon.baynoteTabBtn01.className = "btn01";
	soacCommon.baynoteTabBtn02.className = "btn02on";
	soacCommon.baynoteTabBtn03.className = "btn03";
	if (soacCommon.baynoteTabcanprecNewHikari && soacCommon.baynoteTabcanprecNewAdsl && soacCommon.baynoteTabcanprecNewMobile){
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecNewHikari,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecNewAdsl,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecNewAdsl,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecNewAdsl});
		}
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecNewMobile,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
	}
	if (soacCommon.baynoteTabcanprecMemberHikari && soacCommon.baynoteTabcanprecMemberAdsl && soacCommon.baynoteTabcanprecMemberMobile){
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecMemberHikari,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecMemberAdsl,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecMemberAdsl,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecMemberAdsl});
		}
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecMemberMobile,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
	}
	if (soacCommon.baynoteTabcanprecServiceHikari && soacCommon.baynoteTabcanprecServiceAdsl && soacCommon.baynoteTabcanprecServiceMobile){
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecServiceHikari,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecServiceAdsl,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecServiceAdsl,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecServiceAdsl});
		}
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecServiceMobile,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
	}
	return false;
}
SOAC_Sales.prototype.onClickBaynoteTabBtn03 = function() {
	soacSales.getBaynoteTabContents();
	var iev = soacCommon.getIeVersion();
	soacCommon.baynoteTabBtn01.className = "btn01";
	soacCommon.baynoteTabBtn02.className = "btn02";
	soacCommon.baynoteTabBtn03.className = "btn03on";
	if (soacCommon.baynoteTabcanprecNewHikari && soacCommon.baynoteTabcanprecNewAdsl && soacCommon.baynoteTabcanprecNewMobile){
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecNewHikari,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecNewAdsl,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecNewMobile,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecNewMobile,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecNewMobile});
		}
	}
	if (soacCommon.baynoteTabcanprecMemberHikari && soacCommon.baynoteTabcanprecMemberAdsl && soacCommon.baynoteTabcanprecMemberMobile){
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecMemberHikari,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecMemberAdsl,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecMemberMobile,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecMemberMobile,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecMemberMobile});
		}
	}
	if (soacCommon.baynoteTabcanprecServiceHikari && soacCommon.baynoteTabcanprecServiceAdsl && soacCommon.baynoteTabcanprecServiceMobile){
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecServiceHikari,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		soacCommon.setCss({
			dom:				soacCommon.baynoteTabcanprecServiceAdsl,
			cssProperties:		[
				{"key":"display",			"value":"none"}
			]
		});
		if (iev > 5 && iev < 9){
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecServiceMobile,
				cssProperties:		[
				{"key":"opacity",			"value":"1.0"},
				{"key":"display",			"value":"block"}
				]
			});
		} else {
			soacCommon.setCss({
				dom:				soacCommon.baynoteTabcanprecServiceMobile,
				cssProperties:		[
				{"key":"opacity",			"value":"0"},
				{"key":"display",			"value":"block"}
				]
			});
			soacCommon.fadeInTab({dom:soacCommon.baynoteTabcanprecServiceMobile});
		}
	}
	return false;
}
SOAC_Sales.prototype.resetQuickSearchCriterior = function() {
	soacSales.quickSearchCriterior = new Object();
	soacSales.quickSearchCriterior.status = "newer"; //newer:新規、member:会員
	soacSales.quickSearchCriterior.course = 0;
	soacSales.quickSearchCriterior.optionList = new Array();
	
	// 2012/09/20 ひかり側で下記修正。
	if(soacCommon.quickSearchOptionList) {
		for (var i = 0; i < soacCommon.quickSearchOptionList.length; i++){
			soacSales.quickSearchCriterior.optionList[soacCommon.quickSearchOptionList[i].id] = 0; //0:なし、1:あり
		}
	}
}
SOAC_Sales.prototype.onClickQuickSearchTab = function(e) {
	e = soacCommon.getEvent(e);
	var status = e.target.className;
	if (soacSales.quickSearchCriterior.status != status){
		soacSales.resetQuickSearchCriterior();
		soacSales.quickSearchCriterior.status = status;
		soacSales.displayQuickSearch({fade:true});
	}
	soacSales.setQuickSearchCookie();
	return false;
}
SOAC_Sales.prototype.onClickQuickSearchCourse = function(e) {
	e = soacCommon.getEvent(e);
	var tObj = e.target;
	var tIds = tObj.id.split("_");
	if (tIds && tIds[1]){
		var course = tIds[1];
		if (soacSales.quickSearchCriterior.course != course){
			soacSales.quickSearchCriterior.course = course;
			soacSales.displayQuickSearch({fade:false});
		}
		soacSales.setQuickSearchCookie();
		return false;
	}
}
SOAC_Sales.prototype.onClickQuickSearchOption = function(e) {
	e = soacCommon.getEvent(e);
	var tObj = e.target;
	if (tObj.tagName == "SPAN"){
		tObj = tObj.parentNode;
	}
	var tIds = tObj.id.split("_");
	if (tIds && tIds[1]){
		var option = tIds[1];
		for (var i = 0; i < soacCommon.quickSearchOptionList.length; i++){
			if (soacCommon.quickSearchOptionList[i].id == option){
				if (soacSales.quickSearchCriterior.optionList[option]){
					soacSales.quickSearchCriterior.optionList[option] = 0;
				} else {
					soacSales.quickSearchCriterior.optionList[option] = 1;
				}
				soacSales.displayQuickSearch({fade:false});
				break;
			}
		}
		soacSales.setQuickSearchCookie();
		return false;
	}
}
SOAC_Sales.prototype.getQuickSearchCookie = function() {
	soacSales.resetQuickSearchCriterior();
	var cookieQsc = "";
	if (document.cookie) {
		var cookies = document.cookie.split("; ");
		for (var i = 0; i < cookies.length; i++) {
			var str = cookies[i].split("=");
			if (str.length > 1){
				if (str[0] == "_soacQSC") {
					cookieQsc = decodeURIComponent(str[1]);
					break;
				}
			}
		}
	}
	if (cookieQsc){
		cookieQscList = cookieQsc.split(",");
		for (var i = 0; i < cookieQscList.length; i++){
			var qscList = cookieQscList[i].split(":");
			if (qscList[0] == "s"){
				if (qscList[1]){
					soacSales.quickSearchCriterior.status = qscList[1];
				}
			} else if (qscList[0] == "c"){
				if (qscList[1]){
					soacSales.quickSearchCriterior.course = qscList[1];
				}
			} else if (qscList[0] == "o"){
				if (qscList[1]){
					soacSales.quickSearchCriterior.optionList[qscList[1]] = 1;
				}
			}
		}
	}
}
SOAC_Sales.prototype.setQuickSearchCookie = function() {
	if (window.navigator.cookieEnabled) {
		if (soacSales.quickSearchCriterior.course){
			var qsc = "s:" + soacSales.quickSearchCriterior.status;
			qsc += ",c:" + soacSales.quickSearchCriterior.course;
			for (var i = 0; i < soacCommon.quickSearchOptionList.length; i++){
				if (soacSales.quickSearchCriterior.optionList[soacCommon.quickSearchOptionList[i].id] == 1){
					qsc += ",o:" + soacCommon.quickSearchOptionList[i].id;
				}
			}
			document.cookie = "_soacQSC=" + encodeURIComponent(qsc) + "; path=/";
		} else {
			document.cookie = "_soacQSC=; path=/";
		}
	}
}
SOAC_Sales.prototype.displayQuickSearch = function(args) {
	var fade = false;
	if (args.fade){
		fade = args.fade;
	}
	var iev = soacCommon.getIeVersion();
	var qsDom = soacSales.getQuickSearchDOM();
	if (qsDom){
		var qsHtml = '<div class="box_quickSearch">';
		qsHtml += '<div class="box_quickSearch-inner">';
		qsHtml += '<h3>So-net会員の方</h3>';
		qsHtml += '<p class="catchcopy">あなたにおすすめのコースを素早く見つけ出します</p>';
		qsHtml += '<ul class="box_quickSearch_tab">';
		if (soacSales.quickSearchCriterior.status == "newer"){
			qsHtml += '<li class="ui-state-default ui-corner-top ui-tabs-selected ui-state-active"><a href="#" class="newer">新規入会</a></li>';
			qsHtml += '<li class="ui-state-default ui-corner-top"><a href="#member" class="member">So-net会員</a></li>';
		} else {
			qsHtml += '<li class="ui-state-default ui-corner-top"><a href="#newer" class="newer">新規入会</a></li>';
			qsHtml += '<li class="ui-state-default ui-corner-top ui-tabs-selected ui-state-active"><a href="#member" class="member">So-net会員</a></li>';
		}
		qsHtml += '</ul>';
		qsHtml += '<div class="tab_quicksearch" ';
		if (iev > 5 && iev < 9){
		} else {
			if (fade){
				qsHtml += 'style="opacity:0" ';
			}
		}
		if (soacSales.quickSearchCriterior.status == "newer"){
			qsHtml += 'id="newer">';
			qsHtml += '<p>まずはつなごう！<strong>回線種類</strong><br />';
			qsHtml += '<em>ご希望の回線をお選びください。</em></p>';
		} else {
			qsHtml += 'id="member">';
			qsHtml += '<p><strong>回線種類</strong><br />';
			qsHtml += '<em>ご利用いただいている回線をお選びください。</em></p>';
		}
		qsHtml += '<div class="linetype">';
		for (var i = 0; i < soacCommon.quickSearchCourseList.length; i++){
			if (soacSales.quickSearchCriterior.status == soacCommon.quickSearchCourseList[i].status){
				qsHtml += '<a id="qsc_' + soacCommon.quickSearchCourseList[i].id + '" ';
				if (soacSales.quickSearchCriterior.course == soacCommon.quickSearchCourseList[i].id){
					qsHtml += 'class="selected" ';
				}
				qsHtml += 'href="#">' + soacCommon.quickSearchCourseList[i].disp + '</a>';
			}
		}
		qsHtml += '</div>';
		qsHtml += '<p>いろいろできる！<strong class="option">オプションサービス</strong><br />';
		qsHtml += 'あなたのご希望は？</p>';
		qsHtml += '<form>';
		for (var i = 0; i < soacCommon.quickSearchOptionList.length; i++){
			qsHtml += '<div id="qso_' + soacCommon.quickSearchOptionList[i].id + '" style="cursor:pointer">';
			if (soacSales.quickSearchCriterior.optionList[soacCommon.quickSearchOptionList[i].id] == 0){
				qsHtml += '<span class="checkbox" style="background-position: 0px 0px;">';
			} else {
				qsHtml += '<span class="checkbox" style="background-position: 0px -50px;">';
			}
			qsHtml += '</span>' + soacCommon.quickSearchOptionList[i].disp + '</div>';
		}
		qsHtml += '</form>';
		qsHtml += '</div>';
		qsHtml += '<div id="qs_result" class="tab_quicksearch" ';
		if (iev > 5 && iev < 9){
		} else {
			if (fade){
				qsHtml += 'style="opacity:0" ';
			}
		}
		qsHtml += '>';
		if (soacSales.quickSearchCriterior.course){
			var mxId = soacSales.quickSearchCriterior.course;
			for (var i = 0; i < soacCommon.quickSearchOptionList.length; i++){
				if (soacSales.quickSearchCriterior.optionList[soacCommon.quickSearchOptionList[i].id] == 1){
					mxId += "_" + soacCommon.quickSearchOptionList[i].id;
				}
			}
			var resultList = soacCommon.quickSearchMatrix[mxId];
			if (resultList && resultList.length > 0){
				for (var i = 0; i < resultList.length; i++){
					if (i == 0){
						qsHtml += '<div class="recommendService">';
						qsHtml += '<h4>あなたにオススメのサービスはコレ！</h4>';
						qsHtml += '<div class="course">';
						qsHtml += '<div class="' + resultList[i].imgClass + '" style="background-image:url(' + resultList[i].imgUrl + ');background-repeat:no-repeat;no-repeat;background-position:4px 4px;"><span class="vm"></span><a href=' + resultList[i].url + '>' + resultList[i].disp + '</a></div>';
						qsHtml += '</div>';
						qsHtml += '<div class="option">';
					} else {
						qsHtml += '<div class="' + resultList[i].imgClass + '" style="background-image:url(' + resultList[i].imgUrl + ');background-repeat:no-repeat;no-repeat;background-position:4px 4px;"><span class="vm"></span><a href=' + resultList[i].url + '>' + resultList[i].disp + '</a></div>';
					}
					if (i == resultList.length - 1){
						qsHtml += '</div>';
						qsHtml += '</div>';
					}
				}
			}
		}
		qsHtml += '</div>';
		qsHtml += '</div><!-- / .box_quickSearch-inner -->';
		qsHtml += '</div><!-- / .box_quickSearch -->';
		qsDom.innerHTML = qsHtml;
		if (iev > 5 && iev < 9){
		} else {
			if (fade){
				var tabdom = document.getElementById(soacSales.quickSearchCriterior.status);
				soacCommon.fadeInTab({dom:tabdom});
			}
			var resultDom = document.getElementById("qs_result");
			soacCommon.fadeInTab({dom:resultDom});
		}
		var newerDoms = soacCommon.getElementsByClass({className:"newer",dom:qsDom});
		for (var i = 0; i < newerDoms.length; i++){
			newerDoms[i].onclick = soacSales.onClickQuickSearchTab;
		}
		var memberDoms = soacCommon.getElementsByClass({className:"member",dom:qsDom});
		for (var i = 0; i < memberDoms.length; i++){
			memberDoms[i].onclick = soacSales.onClickQuickSearchTab;
		}
		for (var i = 0; i < soacCommon.quickSearchCourseList.length; i++){
			if (soacSales.quickSearchCriterior.status == soacCommon.quickSearchCourseList[i].status){
				var courseDom = document.getElementById("qsc_" + soacCommon.quickSearchCourseList[i].id);
				courseDom.onclick = soacSales.onClickQuickSearchCourse;
			}
		}
		for (var i = 0; i < soacCommon.quickSearchOptionList.length; i++){
			var optionDom = document.getElementById("qso_" + soacCommon.quickSearchOptionList[i].id);
			optionDom.onclick = soacSales.onClickQuickSearchOption;
		}
	}
}
SOAC_Sales.prototype.getQuickSearchDOM = function() {
	if (!soacSales.quickSearchDOM){
		soacSales.quickSearchDOM = document.getElementById("quickSearchArea");
	}
	return soacSales.quickSearchDOM;
}
SOAC_Sales.prototype.initBoxToggle = function() {
	soacSales.boxToggleList = new Array();
	var boxToggleList = soacCommon.getElementsByClass({className:"box_toggle"});
	if (boxToggleList && boxToggleList.length > 0){
		for (var i = 0; i < boxToggleList.length; i++){
			var tObj = new Object();
			tObj.dom = boxToggleList[i];
			tObj.status = "toggle_close";
			for (var j = 0; j < boxToggleList[i].attributes.length; j++){
				if (boxToggleList[i].attributes[j] && boxToggleList[i].attributes[j].nodeName && boxToggleList[i].attributes[j].nodeName == "soacmode"){
					tObj.status = boxToggleList[i].attributes[j].nodeValue;
					break;
				}
			}
			for (var j = 0; j < tObj.dom.childNodes.length; j++){
				var cn = tObj.dom.childNodes[j];
				if (cn.tagName == "DIV" && cn.className == "toggle_contents"){
					tObj.contentsHeight = cn.offsetHeight - 20;
					tObj.contentsDom = cn;
					if (tObj.status == "toggle_close"){
						soacCommon.setCss({
							dom:				cn,
							cssProperties:		[
								{"key":"display",			"value":"none"}
							]
						});
					}
				}
				if (cn.tagName == "DIV" && cn.className.indexOf("toggle_trigger") >= 0){
					cn.onclick = soacSales.onClickToggle;
					tObj.triggerDom = cn;
					if (tObj.status == "toggle_close"){
						cn.className = "toggle_trigger toggle_trigger_closed";
					}
				}
			}
			soacSales.boxToggleList.push(tObj);
		}
	}
}
SOAC_Sales.prototype.initCatalogBoxToggle = function() {
	soacCommon.searchButtonEvent();
	soacSales.boxToggleList = new Array();
	var boxToggleList = new Array();
	var accessList = soacCommon.getElementsByClass({className:"accordion access"});
	if (accessList && accessList.length > 0){
		for (var i = 0; i < accessList.length; i++){
			boxToggleList.push(accessList[i]);
		}
	}
	var optionList = soacCommon.getElementsByClass({className:"accordion option"});
	if (optionList && optionList.length > 0){
		for (var i = 0; i < optionList.length; i++){
			boxToggleList.push(optionList[i]);
		}
	}
	if (boxToggleList && boxToggleList.length > 0){
		for (var i = 0; i < boxToggleList.length; i++){
			var tObj = new Object();
			tObj.dom = boxToggleList[i];
			tObj.status = "toggle_close";
			for (var j = 0; j < boxToggleList[i].attributes.length; j++){
				if (boxToggleList[i].attributes[j] && boxToggleList[i].attributes[j].nodeName && boxToggleList[i].attributes[j].nodeName == "soacmode"){
					tObj.status = boxToggleList[i].attributes[j].nodeValue;
					break;
				}
			}
			for (var j = 0; j < tObj.dom.childNodes.length; j++){
				var cn = tObj.dom.childNodes[j];
				if (cn.tagName == "DD"){
					tObj.contentsHeight = cn.offsetHeight;
					tObj.contentsDom = cn;
					if (tObj.status == "toggle_close"){
						soacCommon.setCss({
							dom:				cn,
							cssProperties:		[
								{"key":"display",			"value":"none"}
							]
						});
					}
				}
				if (cn.tagName == "DT"){
					cn.onclick = soacSales.onClickToggle;
					tObj.triggerDom = cn;
					if (tObj.status == "toggle_close"){
						cn.className = "toggle_trigger toggle_trigger_closed";
					}
				}
			}
			soacSales.boxToggleList.push(tObj);
		}
	}
}
SOAC_Sales.prototype.onClickToggle = function(e) {
	e = soacCommon.getEvent(e);
	var tDom = e.target.parentNode;
	var interval = 10;
	for (var i = 0; i < soacSales.boxToggleList.length; i++){
		if (soacSales.boxToggleList[i].dom == tDom){
			var tObj = soacSales.boxToggleList[i];
			if (tObj.status == "toggle_close"){
				tObj.status = "toggle_open";
				soacCommon.setCss({
					dom:				tObj.contentsDom,
					cssProperties:		[
						{"key":"height",			"value":"0px"},
						{"key":"display",			"value":"block"}
					]
				});
				tObj.triggerDom.className = "toggle_trigger";
				setTimeout(function() {soacSales.moveToggle({obj:tObj,mvVal:"+"});}, interval);
			} else {
				tObj.status = "toggle_close";
				tObj.triggerDom.className = "toggle_trigger toggle_trigger_closed";
				setTimeout(function() {soacSales.moveToggle({obj:tObj,mvVal:"-"});}, interval);
			}
			break;
		}
	}
}
SOAC_Sales.prototype.moveToggle = function(args) {
	var interval = 10;
	var delta = 30;
	var tObj = args.obj;
	var mvVal = args.mvVal;
	if (mvVal == "-"){
		delta = -delta;
	}
	var tHeight = tObj.contentsDom.offsetHeight - 20;
	if (tObj.contentsHeight <= 0){
		tObj.contentsHeight = 0;
		for (var j = 0; j < tObj.contentsDom.childNodes.length; j++){
			var cn = tObj.contentsDom.childNodes[j];
			if (cn.offsetHeight){
				tObj.contentsHeight += cn.offsetHeight;
			}
		}
		tObj.contentsHeight += 20;
	}
	if (tHeight + delta < 0){
		soacCommon.setCss({
			dom:				tObj.contentsDom,
			cssProperties:		[
				{"key":"height",			"value": "0px"},
				{"key":"overflow",			"value":"hidden"},
				{"key":"display",			"value":"none"}
			]
		});
		return;
	} else if (tHeight + delta > tObj.contentsHeight){
		soacCommon.setCss({
			dom:				tObj.contentsDom,
			cssProperties:		[
				{"key":"overflow",			"value":"hidden"},
				{"key":"height",			"value": tObj.contentsHeight + "px"}
			]
		});
		return;
	}
	soacCommon.setCss({
		dom:				tObj.contentsDom,
		cssProperties:		[
			{"key":"overflow",			"value":"hidden"},
			{"key":"height",			"value": (tHeight + delta) + "px"}
		]
	});
	setTimeout(function() {soacSales.moveToggle({obj:tObj,mvVal:mvVal});}, interval);
}

var soacSales = new SOAC_Sales();
