/**
 * 遅延リターゲティング
 */
(function () {
	var url = "//px.ladsp.com/pixel/nm"
			+ "?advertiser_id=" + encodeURIComponent(smnAdvertiserId);
	var maxDelaySecondsLength = 4;
	var minDelaySecondsValue = 0;
	var maxDelaySecondsValue = 999;


	var consoleLog = (typeof(console) === "undefined") ? function () { }
			: (typeof(console.log) === "undefined") ? function () { }
			: function (msg) {
				return console.log(msg);
			};

	var isArray = (typeof(Array.isArray) === "undefined")
			? function (arr) {
				return Object.prototype.toString.call(arr) === "[object Array]";
			}
			: Array.isArray;

	var arraySort = function (a) {
		for (var i = 0; i < a.length - 1; i++) {
			for (j = i + 1; j < a.length; j++) {
				if (a[i] > a[j]) {
					var n = a[i];
					a[i] = a[j];
					a[j] = n;
				}
			}
		}
	};

	var arrayIndexOf = function(a, e) {
		if (typeof (a.indexOf) === "undefined") {
			for (var i = 0; i < a.length; i++) {
				if (a[i] == e) {
					return i;
				}
			}
			return -1;
		} else {
			return a.indexOf(e);
		}
	}

	var makeGetParameterAdd = function (name, val) {
		return (val != null && val.toString().length > 0)
				? "&" + name + "=" + encodeURIComponent(val)
				: "";
	};


	var retargetingParameter =
			(typeof(smnRetargetingParameter) !== "undefined")
					? smnRetargetingParameter
					: null;

	var afterParams = ""
			+ ((typeof(smnLogParameter1) !== "undefined") ? makeGetParameterAdd("lp1",smnLogParameter1) : "")
			+ ((typeof(smnLogParameter2) !== "undefined") ? makeGetParameterAdd("lp2",smnLogParameter2) : "")
			+ ((typeof(smnLogParameter3) !== "undefined") ? makeGetParameterAdd("lp3",smnLogParameter3) : "")
			+ ((typeof(smnLogParameter4) !== "undefined") ? makeGetParameterAdd("lp4",smnLogParameter4) : "")
			+ ((typeof(smnLogParameter5) !== "undefined") ? makeGetParameterAdd("lp5",smnLogParameter5) : "")
			+ ((typeof(smnLogParameter6) !== "undefined") ? makeGetParameterAdd("lp6",smnLogParameter6) : "")
			+ ((typeof(smnLogParameter7) !== "undefined") ? makeGetParameterAdd("lp7",smnLogParameter7) : "")
			+ ((typeof(smnLogParameter8) !== "undefined") ? makeGetParameterAdd("lp8",smnLogParameter8) : "")
			+ ((typeof(smnLogParameter9) !== "undefined") ? makeGetParameterAdd("lp9",smnLogParameter9) : "")
			+ ((typeof(smnLogParameter10) !== "undefined") ? makeGetParameterAdd("lp10",smnLogParameter10) : "")
			+ "&referer=" + encodeURIComponent(document.referrer.toString());

	var delaySeconds = [];
	if (typeof (smnDelaySecondsArray) === "undefined") {
		consoleLog("logicad: smnDelaySecondsArray is not defined.");
		return;
	} else if (!isArray(smnDelaySecondsArray)) {
		consoleLog("logicad: smnDelaySecondsArray is not array.");
		return;
	} else if (smnDelaySecondsArray.length <= 0) {
		consoleLog("logicad: smnDelaySecondsArray is empty.");
		return;
	} else {
		for (var i = 0; i < smnDelaySecondsArray.length; i++) {
			var value = parseInt(smnDelaySecondsArray[i], 10);
			if (isNaN(value)) {
				consoleLog("logicad: smnDelaySecondsArray has invalid value.");
				return;
			}
			if ((value < minDelaySecondsValue) || (value > maxDelaySecondsValue)) {
				console.log("logicad: smnDelaySecondsArray has out of range value.");
				return;
			}
			if (arrayIndexOf(delaySeconds, value) != -1) {
				continue;
			}
			delaySeconds.push(value);
			if (delaySeconds.length >= maxDelaySecondsLength) {
				break;
			}
		}
		arraySort(delaySeconds);
	}

	var img = document.createElement("img");
	img.style.display = "none";
	document.body.appendChild(img);

	var currentIndex = 0;
	var onTimeout = function () {
		img.src = url
				+ ("&rp=" + encodeURIComponent(
						((retargetingParameter != null) ? retargetingParameter : '')
						+ "--d" + delaySeconds[currentIndex] + "s--"))
				+ afterParams;
		currentIndex ++;
	};

	for (var i = 0; i < delaySeconds.length; i++) {
		window.setTimeout(onTimeout, delaySeconds[i] * 1000);
	}
})();
