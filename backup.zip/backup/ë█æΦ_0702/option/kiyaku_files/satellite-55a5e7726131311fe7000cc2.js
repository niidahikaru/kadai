function sc_ydn(y_rt_id,y_rt_label,y_pageName,y_cv){
	var y_id,
		y_label;
	if(!y_rt_id)return;
	else y_id=y_rt_id;
	y_label=y_rt_label?y_rt_label:"";
	var tmp_url=y_pageName?y_pageName:document.URL;
	if(!y_cv){
		if(y_label.length>100)y_label=y_label.substr(0,100)
		var y_encoded_url=encodeURIComponent(tmp_url),
			y_encoded_label=encodeURIComponent(y_label),
			y_time=parseInt((new Date)/1000)+Math.random(),
			ydn_dom=document.getElementsByTagName('script')[0],
			y_src=document.createElement('script');
			y_src.async=true;
		y_src.src='//b92.yahoo.co.jp/search/?p='+y_id+'&label='+y_encoded_label+'&ref='+y_encoded_url+'&r='+y_time;
		ydn_dom.parentNode.insertBefore(y_src,ydn_dom)
	}else if(y_cv=="listing" && typeof sc_gdn=="function"){
		sc_gdn(y_rt_id,y_rt_label,"3",false,tmp_url,true);
	}else if(y_cv=="network"){
		var ydn_cv_dom=document.getElementsByTagName('script')[0],
			y_img=document.createElement('img'),
			y_time=parseInt((new Date)/1000) + Math.random();
		y_img.width=y_img.height=1;
		y_img.border=0;
		//y_img.src="//b90.yahoo.co.jp/c?account_id="+y_id+"&transaction_id="+y_label+"&amount=";
		y_img.src="//b90.yahoo.co.jp/c?yahoo_ydn_conv_io="+y_id+"&yahoo_ydn_conv_label="+y_label+"&yahoo_ydn_conv_transaction_id=&yahoo_ydn_conv_amount=0&r="+y_time;
		ydn_cv_dom.parentNode.insertBefore(y_img,ydn_cv_dom)
	}
}
function sc_gdn(gdn_id,gdn_lbl,gdn_fmt,gdn_rm,gdn_page,y){
	var grm_id="",
		grm_label="",
		grm_format="",
		grm_pass="",
		grm_pid="",
		grm_par="";
	if(gdn_id)grm_id=gdn_id;
	else return;
	grm_label=gdn_lbl?gdn_lbl:"";
	grm_format=gdn_fmt?gdn_fmt:"3";
	if(!gdn_rm){grm_pass=!y?"//www.googleadservices.com/pagead/conversion/":"//b91.yahoo.co.jp/pagead/conversion/"}
	else {grm_pass="//googleads.g.doubleclick.net/pagead/viewthroughconversion/";grm_format="1"}
	if(gdn_page){
		if(gdn_page.match(/^https?:/)!=null)grm_pid=encodeURIComponent(gdn_page);
		else grm_pid=location.protocol.replace(":","%3A%2F%2F")+location.hostname+gdn_page.replace(/\//g,"%2F");
	}else{
		grm_pid=location.protocol.replace(":","%3A//")+location.hostname+location.pathname;
	}
	grm_par="&url="+grm_pid;
	grm_par+=document.referrer?("&ref="+document.referrer.replace(":","%3A")):"";
	var cache_time=Math.floor(1E9*Math.random()),
		grm_body=document.getElementsByTagName("body").item(0),
		grm_img=document.createElement("img");
	grm_img.setAttribute("height","1");
	grm_img.setAttribute("width","1");
	grm_img.setAttribute("style","border-style:none;");
	grm_img.setAttribute("src",grm_pass+grm_id+'/?random='+cache_time+'&value=0&label='+grm_label+'&guid=ON'+grm_par);
	grm_body.appendChild(grm_img);
}
