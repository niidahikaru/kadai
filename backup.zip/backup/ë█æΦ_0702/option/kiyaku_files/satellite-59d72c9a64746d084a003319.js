_satellite.pushBlockingScript(function(event, target, $variables){
  var prj = "",
    c = location.hostname + location.pathname.replace(/\/(index\.html)?$/,""),
    sd = "https://cdnssl.clicktale.net",
    sp = {
      "13882" : "/www08/ptc/c14ad5d3-69d7-4220-9625-6d69c1963563.js", // access
      "13169" : "/www08/ptc/cfb2b7ea-f026-4296-9755-e9521f1b67ff.js", // www
      "14119" : "/www08/ptc/2bbf12e9-4c3c-436d-b6af-1e506fe16976.js", // other
      "13094" : "/www08/ptc/69ff1a15-c209-4924-8684-34786921fef4.js", // CR
      "14515" : "/www08/ptc/15b4f137-155f-49d8-af9f-871b011c35ea.js", // elavel
      "13977" : "/www08/ptc/4f8d169f-1320-4f68-b0fc-bfce392ab6a5.js", // fortunes
      "11110" : "/www08/ptc/928b6553-1d34-4f30-aeaa-987ee0c7b59b.js" // faq
    };
// for support answer pages
if(c==="support.so-net.ne.jp/supportsitedetailpage"){
  var ans_id=location.search.match(/[\?&]id=(\d+)/)?RegExp.$1:'';
}
    
if(c==="www.so-net.ne.jp/access/hikari/collaboration/shinsetsu/select"
   || c==="www.so-net.ne.jp/access/hikari/collaboration/diversion/select"
   || c==="www.so-net.ne.jp/access/hikari/au/select"
   || c==="www.so-net.ne.jp/access/mobile/wimax2/select"
  ){
  prj="13882";
}else if(c==="www.so-net.ne.jp/siteinfo/list"
         || c==="www.so-net.ne.jp/solution"
         || c==="www.so-net.ne.jp/wellness"
         || c.indexOf("www.so-net.ne.jp/touch")>-1
  ){
  prj="13169";
}else if(c.indexOf("www.so-net.ne.jp/cpn/sonystore-cpn")===0
         || c==="www.so-net.ne.jp/option"
         || c==="www.so-net.ne.jp/option/m"
         || c==="www.so-net.ne.jp/training"
         || (c.indexOf("www.so-net.ne.jp/training/sonetore")>-1 &&
             c.indexOf("www.so-net.ne.jp/training/sonetore/service")===-1)
         || c==="www.so-net.ne.jp/option/visual/unext/adlp1"
         || c==="www.so-net.ne.jp/option/security/kaspersky/opklp"
         || c.indexOf("www.so-net.ne.jp/lifesupport")>-1
         || c.indexOf("www.so-net.ne.jp/cpn")>-1
         || c==="www.so-net.ne.jp/hikkosi/lp"
         || c.indexOf("www.so-net.ne.jp/hikkosi/collabo/lp")>-1
        ){
  prj="14119";
}else if(c.match(/^www\.so-net\.ne\.jp\/(point$|mball(\/tokuten|\/goaiko|\/premium|\/gonyukai)?$)/)!==null
        ){
  prj="13094";
}else if(c.indexOf("www.so-net.ne.jp/option/benefit/elavel-club")===0 &&
         c.indexOf("www.so-net.ne.jp/option/benefit/elavel-club/setteitokuten")===-1
        ){
	prj="14515";
}else if(c.match(/^www\.so-net\.ne\.jp\/fortunes(\/today\/DispConstel.cgi)?$/)!==null
        ){
  prj="13977";
}else if(c.match(/^www\.so-net\.ne\.jp\/support\/taikai(\/after)?$/)!=null
         || c.indexOf("www.so-net.ne.jp/bb/ipoe")===0
         || c==="support.so-net.ne.jp"
         || c==="support.so-net.ne.jp/ask_select"
         || c==="support.so-net.ne.jp/ask_select_desk"
         || c==="support.so-net.ne.jp/ask_tel"
         || c==="support.so-net.ne.jp/ask_select_withdrawal"
         || c==="support.so-net.ne.jp/ask_tel_withdrawal"
         || (c==="support.so-net.ne.jp/supportsitedetailpage" &&
             (ans_id==="000011875" ||
              ans_id==="000011839" ||
              ans_id==="000012359" ||
              ans_id==="000011935" ||
              ans_id==="000011924" ||
              ans_id==="000009142" ||
              ans_id==="000009145" ||
              ans_id==="000009257")
            )
        ){
  prj="11110";
}

if(prj){
  if(!window.clickTaleTagInjected){
    !function(d,t,u){
      clickTaleTagInjected = true;function injectTag(){var ns=d.createElementNS;var a=ns?ns.call(d,"http://www.w3.org/1999/xhtml",t):d.createElement(t),s=d.getElementsByTagName(t)[0];a.async=true;a.crossOrigin="anonymous";a.type="text/javascript";a.src=u;s.parentNode.insertBefore(a,s);} if(d.readyState!='loading'){injectTag();} else{d.addEventListener('DOMContentLoaded',function(){setTimeout(injectTag,0)});}
    }(document,'script',sd+sp[prj]);
  }
}
});
