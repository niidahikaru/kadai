﻿var SOAC_Common = function() {};
SOAC_Common.prototype.windowOnLoad = function(args) {
	var tabName = "";
	var anchorName = "";
	soacCommon.searchButtonEvent();
	if (args && args.tabName){
		tabName = args.tabName;
		tabNames = tabName.split("-");
		if (tabNames && tabNames.length > 0){
			if (tabNames.length > 1){
				anchorName = tabName;
			}
			tabName = tabNames[0] + "-h";
		}
	} else {
		var rtnObj = soacCommon.getTabParam();
		if (rtnObj){
			if (rtnObj.tabName){
				tabName = rtnObj.tabName;
			}
			anchorName = rtnObj.anchorName;
		}
	}
	var allTabs = soacCommon.getAllTabElements();
	var iev = soacCommon.getIeVersion();
	if (allTabs && allTabs.length > 0){
		if (!tabName){
			tabName = allTabs[0].id;
		}
		if (soacCommon.selectedTabName){
			if (soacCommon.selectedTabName == tabName) return false;
		}
		soacCommon.selectedTabName = tabName;
		var tabNodeObj = soacCommon.selectMainTabMenu({tabName:tabName});
		var tabNodeValue = tabNodeObj.value;
		var tabNodeType = tabNodeObj.type;
		if (soacCommon.getTopicPathElement()){
			if (tabName == allTabs[0].id){
				for (var i = 0; i < SOAC_Common.topicPathElements.length; i++){
					SOAC_Common.topicPathElements[i].innerHTML = SOAC_Common.initTopicPathNodeValue;
				}
			} else {
				var urls = location.href.split('?');
				if (urls && urls[0]){
					var tpWords = SOAC_Common.initTopicPathNodeValue.split('&nbsp;');
					if (tabNodeType == "sub"){
						tabNodeValue = tabNodeValue.substr(1);
					}
					if (tpWords && tpWords[2]){
						if (location.href.indexOf("/option/gyao/") >= 0){
							if (tpWords && tpWords[2] && tpWords[4]){
								var gUrl = urls[0].split("/gyao/").join("/gyao/");
								var newTopicPath = tpWords[0] + ' &raquo;  ' + '<a href="'+gUrl+'">'+tpWords[2]+'</a>' + ' &raquo;  ' + '<a href="'+urls[0]+'">'+tpWords[4]+'</a>' + ' &raquo;  ' + tabNodeValue;
								for (var i = 0; i < SOAC_Common.topicPathElements.length; i++){
									SOAC_Common.topicPathElements[i].innerHTML = newTopicPath;
								}
							}
						} else {
							var newTopicPath = tpWords[0] + ' &raquo;  ' + '<a href="'+urls[0]+'">'+tpWords[2]+'</a>' + ' &raquo;  ' + tabNodeValue;
							for (var i = 0; i < SOAC_Common.topicPathElements.length; i++){
								SOAC_Common.topicPathElements[i].innerHTML = newTopicPath;
							}
						}
					}
				}
			}
		}
		for (var i = 0; i < allTabs.length; i++){
			if (tabName == allTabs[i].id){
				if (iev > 5 && iev < 9){
					soacCommon.setCss({
						dom:				allTabs[i],
						cssProperties:		[
						{"key":"opacity",			"value":"1.0"},
						{"key":"display",			"value":"block"}
						]
					});
				} else {
					soacCommon.setCss({
						dom:				allTabs[i],
						cssProperties:		[
						{"key":"opacity",			"value":"0"},
						{"key":"display",			"value":"block"}
						]
					});
					soacCommon.fadeInTab({dom:allTabs[i]});
				}
				soacCommon.setCss({
					dom:				allTabs[0].parentNode,
					cssProperties:		[
						{"key":"height",			"value":"auto"}
					]
				});
				if (anchorName){
					var anchorDom = soacCommon.getAnchorElement({anchorName:anchorName,dom:allTabs[i]});
					if (anchorDom){
						var anchorPos = soacCommon.getAbsolutePosition(anchorDom);
						if (anchorPos && anchorPos.y){
							window.scroll(0,anchorPos.y);
						}
					}
				}
			} else {
				soacCommon.setCss({
					dom:				allTabs[i],
					cssProperties:		[
						{"key":"display",			"value":"none"}
					]
				});
			}
		}
	}
}
SOAC_Common.prototype.getIeVersion = function() {
	var msie=navigator.appVersion.toLowerCase();
	msie=(msie.indexOf('msie')>-1)?parseInt(msie.replace(/.*msie[ ]/,'').match(/^[0-9]+/)):0;
	return msie;
}
SOAC_Common.prototype.getTabParam = function() {
	var tabName = "";
	var anchorName = "";
	var urls = location.href.split('?');
	if (urls && urls[1]){
		var params = urls[1].split('#');
		if (params[1]){
			anchorName = params[1];
		}
		var params = params[0].split('&');
		for (var i = 0; i < params.length; i++) {
			var str = params[i].split("=");
			if (str[0] == "page" && str[1]){
				tabName = str[1];
				break;
			}
		}
		var rtnObj = new Object();
		if (tabName){
			var tabNames = tabName.split("-");
			if (tabNames && tabNames.length > 0){
				if (tabNames.length > 1){
					anchorName = tabName;
				}
				tabName = tabNames[0] + "-h";;
			}
			return {tabName:tabName,anchorName:anchorName};
		}
	}
	var urls = location.href.split('#');
	if (urls && urls[1]){
		anchorName = urls[1];
		return {tabName:tabName,anchorName:anchorName};
	}
	return false;
}
SOAC_Common.prototype.selectMainTabMenu = function(args) {
	if (args && args.tabName){
		var tabName = args.tabName;
		if (tabName.indexOf("-h") >= 0){
			tabName = tabName.split("-h").join("");
		}
		var tabNodeValue = "";
		var boxTabMenu = soacCommon.getBoxTabMenu({className:"box_tabMenu"});
		var defSelTab = null;
		var allNotSelFlag = true;
		var mainSubFlag = "";
		if (boxTabMenu && boxTabMenu.childNodes){
			for (var i = 0; i < boxTabMenu.childNodes.length; i++){
				var cn = boxTabMenu.childNodes[i];
				if (cn.className && cn.className.indexOf("ui-tabs-selected") >= 0){
					defSelTab = cn;
				}
				if (cn.tagName == "LI" && cn.childNodes){
					for (var j = 0; j < cn.childNodes.length; j++){
						var ccn = cn.childNodes[j];
						if (ccn.tagName == "A"){
							var exstFlag = false;
							for (var k = 0; k < ccn.attributes.length; k++){
								if (ccn.attributes[k].nodeName == "href" && ccn.attributes[k].nodeValue.indexOf(tabName) >= 0){
									var hrefUrls = ccn.attributes[k].nodeValue.split('?');
									var hrefTabName = "";
									if (hrefUrls && hrefUrls[1]){
										var hrefParams = hrefUrls[1].split('#');
										var hrefParams = hrefParams[0].split('&');
										for (var l = 0; l < hrefParams.length; l++) {
											var hrefStr = hrefParams[l].split("=");
											if (hrefStr[0] == "page" && hrefStr[1]){
												var hrefStrL = hrefStr[1].split('-')[0];
												hrefTabName = hrefStrL;
												break;
											}
										}
										if (tabName == hrefTabName){
											exstFlag = true;
										}
									}
								}
							}
							if (exstFlag){
								if (ccn.firstChild){
									mainSubFlag = "main";
									tabNodeValue = ccn.firstChild.nodeValue;
								}
								allNotSelFlag = false;
								cn.className = "ui-state-default ui-corner-top ui-tabs-selected ui-state-active";
							} else {
								cn.className = "ui-state-default ui-corner-top";
							}
						}
					}
				}
			}
			if (defSelTab && allNotSelFlag){
				defSelTab.className = "ui-state-default ui-corner-top ui-tabs-selected ui-state-active";
			}
		}
		var boxSubMenu = soacCommon.getBoxTabMenu({className:"box_subMenu"});
		defSelTab = null;
		allNotSelFlag = true;
		if (boxSubMenu && boxSubMenu.childNodes){
			for (var i = 0; i < boxSubMenu.childNodes.length; i++){
				var scn = boxSubMenu.childNodes[i];
				if (scn.className && scn.className.indexOf("ui-tabs-selected") >= 0){
					defSelTab = scn;
				}
				if (scn.tagName == "LI" && scn.childNodes){
					for (var j = 0; j < scn.childNodes.length; j++){
						var sccn = scn.childNodes[j];
						if (sccn.tagName == "A"){
							var exstFlag = false;
							for (var k = 0; k < sccn.attributes.length; k++){
								if (sccn.attributes[k].nodeName == "href" && sccn.attributes[k].nodeValue.indexOf(tabName) >= 0){
									var hrefUrls = sccn.attributes[k].nodeValue.split('?');
									var hrefTabName = "";
									if (hrefUrls && hrefUrls[1]){
										var hrefParams = hrefUrls[1].split('#');
										var hrefParams = hrefParams[0].split('&');
										for (var l = 0; l < hrefParams.length; l++) {
											var hrefStr = hrefParams[l].split("=");
											if (hrefStr[0] == "page" && hrefStr[1]){
												var hrefStrL = hrefStr[1].split('-')[0];
												hrefTabName = hrefStrL;
												break;
											}
										}
										if (tabName == hrefTabName){
											exstFlag = true;
										}
									}
								}
							}
							if (exstFlag){
								if (sccn.firstChild){
									mainSubFlag = "sub";
									tabNodeValue = sccn.firstChild.nodeValue;
								}
								allNotSelFlag = false;
								scn.className = "ui-tabs-selected";
							} else {
								scn.className = "";
							}
						}
					}
				}
			}
			if (defSelTab && allNotSelFlag){
				defSelTab.className = "ui-state-default ui-corner-top ui-tabs-selected ui-state-active";
			}
		}
		var tabNodeObj = new Object();
		tabNodeObj.value = tabNodeValue;
		tabNodeObj.type = mainSubFlag;
		return tabNodeObj;
	}
}
SOAC_Common.prototype.getBoxTabMenu = function(args) {
	if (args && args.className){
		var className = args.className;
		var doc = soacCommon.getBaseContentsDOM();
		var result = [];
		var allElements;
		if (doc.all) {
			allElements = doc.all;
		} else {
			allElements = doc.getElementsByTagName("*");
		}
		for (var i = 0; i < allElements.length; i++) {
			if (allElements[i].tagName == "UL" && allElements[i].className && allElements[i].className == className) {
				return allElements[i];
			}
		}
	}
	return false;
}

SOAC_Common.prototype.getAllTabElements = function(args) {
	var doc = null;
	if (args && args.dom && typeof args.dom == "object") {
		doc = args.dom;
	} else {
		doc = soacCommon.getBaseContentsDOM();
	}
	var result = [];
	var allElements;
	if (doc.all) {
		allElements = doc.all;
	} else {
		allElements = doc.getElementsByTagName("*");
	}
	var exstTabFlag = false;
	for (var i = 0; i < allElements.length; i++) {
		if (allElements[i].tagName == "DIV" && allElements[i].id && allElements[i].id.indexOf('tab_') >= 0) {
			result.push(allElements[i]);
			exstTabFlag = true;
		} else if (allElements[i].className && allElements[i].className == "tabEnd"){
			soacCommon.setCss({
				dom:				allElements[i],
				cssProperties:		[
					{"key":"display",			"value":"block"}
				]
			});
		}
	}
	if(!exstTabFlag){
		var boxTabContents = document.getElementById("box_tabContents");
		if(boxTabContents){
			soacCommon.setCss({
				dom:				boxTabContents,
				cssProperties:		[
					{"key":"height",			"value":"auto"}
				]
			});
		}
	}
	return result;
}
SOAC_Common.prototype.getAnchorElement = function(args) {
	var doc = null;
	var anchorName = "";
	if (args && args.anchorName && args.dom && typeof args.dom == "object") {
		doc = args.dom;
		anchorName = args.anchorName;
	} else {
		return false;
	}
	var allElements;
	if (doc.all) {
		allElements = doc.all;
	} else {
		allElements = doc.getElementsByTagName("*");
	}
	for (var i = 0; i < allElements.length; i++) {
		if (allElements[i].tagName == "A" && allElements[i].id && allElements[i].id == anchorName) {
			return allElements[i];
		} else if (allElements[i].tagName == "A" && allElements[i].name && allElements[i].name == anchorName){
			return allElements[i];
		}
	}
	return false;
}
SOAC_Common.prototype.getTopicPathElement = function() {
	if (SOAC_Common.topicPathElements && SOAC_Common.topicPathElements.length > 0){
		return true;
	} else {
		var doc = document.body;
		var allElements;
		if (doc.all) {
			allElements = doc.all;
		} else {
			allElements = doc.getElementsByTagName("*");
		}
		SOAC_Common.topicPathElements = new Array();
		for (var i = 0; i < allElements.length; i++) {
			if (allElements[i].tagName == "P" && allElements[i].className && allElements[i].className == "box_breadCrumbs") {
				if (!SOAC_Common.initTopicPathNodeValue){
					SOAC_Common.initTopicPathNodeValue = allElements[i].innerHTML;
				}
				SOAC_Common.topicPathElements.push(allElements[i]);
			}
		}
		if (SOAC_Common.topicPathElements && SOAC_Common.topicPathElements.length > 0){
			return true;
		}
	}
	return false;
}
SOAC_Common.prototype.getBaseContentsDOM = function() {
	if (!soacCommon.baseContentsDOM){
		soacCommon.baseContentsDOM = document.getElementById("clmn_mainTabs");
	}
	if (!soacCommon.baseContentsDOM){
		soacCommon.baseContentsDOM = document;
	}
	return soacCommon.baseContentsDOM;
}
SOAC_Common.prototype.fadeInTab = function(args) {
	if (args && args.dom){
		var interval = 50;
		var delta = 0.1;
		var dom = args.dom;
		var opacity = soacCommon.getCss({dom:dom,"cssProperty":"opacity"});
		opacity = opacity - 0;
		opacity = opacity + delta;
		if (opacity > 1){
			opacity = 1;
		}
		soacCommon.setCss({
			dom:				dom,
			cssProperties:		[
				{"key":"opacity",			"value":opacity}
			]
		});
		if (opacity < 1){
			setTimeout(function() {soacCommon.fadeInTab({dom:dom});}, interval);
		}
	}
}
SOAC_Common.prototype.setCss = function(args) {
	if ((args && args.dom && args.cssProperties) 
	&& (typeof args.dom == "object" && typeof args.cssProperties == "object")) {
		var dom = args.dom;
		var cssProperties = args.cssProperties;
		if (dom.style) {
			var sameFlag = true;
			for (var i = 0; i < cssProperties.length; i++) {
				if (cssProperties[i] && cssProperties[i].key && cssProperties[i].value) {
					var sk = soacCommon.getDomStylePropertyName({cssProperty:cssProperties[i].key});
					if (sk){
						if (dom.style[sk] != cssProperties[i].value){
							sameFlag = false;
							break;
						}
					}
				}
			}
			if (!sameFlag){
				for (var i = 0; i < cssProperties.length; i++) {
					if (cssProperties[i] && cssProperties[i].key && cssProperties[i].value) {
						var styleKey = soacCommon.getDomStylePropertyName({cssProperty:cssProperties[i].key});
						if (styleKey) {
							try {
								dom.style[styleKey] = cssProperties[i].value;
							} catch (e) {
								//alert(styleKey + "_" + cssProperties[i].value);
							}
						}
					}
				}
			}
		}
	}
}
SOAC_Common.prototype.getCss = function(args) {
	var ret = null;
	if ((args && args.dom && args.cssProperty) 
	&& (typeof args.dom == "object" && typeof args.cssProperty == "string")) {
		var dom = args.dom;
		var cssProperty = args.cssProperty;
		
		var styleKey = soacCommon.getDomStylePropertyName({cssProperty:cssProperty});
		if (styleKey && dom.style && dom.style[styleKey]) {
			ret = dom.style[styleKey];
		}
	}
	
	return ret;
}
SOAC_Common.prototype.getDomStylePropertyName = function(args) {
	if ((args && args.cssProperty) && (typeof args.cssProperty == "string")) {
		var cssProperty = args.cssProperty;
		var ret = "";
		switch (cssProperty) {
			case "float":
				if (window.ActiveXObject !== undefined) {
					// for IE
					ret = "styleFloat";
				} else {
					ret = "cssFloat";
				}
				break;
			default:
				ret = cssProperty;
				break;
		}
		
		return ret;
	}
}
SOAC_Common.prototype.getAbsolutePosition = function(elem) {
	if (elem && typeof elem == "object") {
		var posX = 0;
		var posY = 0;
		while (elem != null) {
			posX += elem.offsetLeft - 0;
			posY += elem.offsetTop - 0;
			elem = elem.offsetParent;
		}
		return {
			x:	posX,
			y:	posY
		};
	}
}
SOAC_Common.prototype.searchButtonEvent = function() {
	var searchButton = document.getElementById("searchsubmit");
	if (!searchButton){
		searchButton = document.getElementById("searchb");
	}
	if (searchButton){
		var searchArea = searchButton.parentNode;
		if (searchArea){
			for (var i = 0; i < searchArea.childNodes.length; i++){
				var cn = searchArea.childNodes[i];
				if (cn.tagName == "LABEL"){
					soacCommon.setCss({
						dom:				cn,
						cssProperties:		[
							{"key":"display",			"value":"none"}
						]
					});
				}
				if (cn.tagName == "INPUT" && cn.type == "text"){
					if (!cn.value){
						cn.value = soacCommon.searchWord;
					}
					cn.className = "input1 inactive active";
					cn.onfocus = function (){soacCommon.onFocusInput(this)};
					cn.onblur = function (){soacCommon.onBlurInput(this)};
				}
			}
		}
	}
}
SOAC_Common.prototype.onFocusInput = function() {
	var searchButton = document.getElementById("searchsubmit");
	if (!searchButton){
		searchButton = document.getElementById("searchb");
	}
	if (searchButton){
		var searchArea = searchButton.parentNode;
		for (var i = 0; i < searchArea.childNodes.length; i++){
			var cn = searchArea.childNodes[i];
			if (cn.tagName == "INPUT" && cn.type == "text"){
				if (cn.value && (cn.value == soacCommon.searchWord || decodeURIComponent(cn.value) == soacCommon.searchWord)){
					cn.value = "";
				}
				cn.className = "input1 focused";
				break;
			}
		}
	}
}
SOAC_Common.prototype.onBlurInput = function() {
	var searchButton = document.getElementById("searchsubmit");
	if (!searchButton){
		searchButton = document.getElementById("searchb");
	}
	if (searchButton){
		var searchArea = searchButton.parentNode;
		for (var i = 0; i < searchArea.childNodes.length; i++){
			var cn = searchArea.childNodes[i];
			if (cn.tagName == "INPUT" && cn.type == "text"){
				if (!cn.value){
					cn.value = soacCommon.searchWord;
				}
				cn.className = "input1 inactive active";
				break;
			}
		}
	}
}
SOAC_Common.prototype.getEvent = function(e) {
	if (!e) {
		return {
			pageX:		document.body.scrollLeft + window.event.clientX,
			pageY:		document.body.scrollTop + window.event.clientY,
			target:		window.event.srcElement
		}
	} else {
		return e;
	}
}
SOAC_Common.prototype.getElementsByClass = function(args) {
	if ((args && args.className)
		&& (typeof args == "object" && typeof args.className == "string")) {
		var cName = args.className;
		
		var doc = null;
		if (args.dom && typeof args.dom == "object") {
			doc = args.dom;
		} else {
			// default
			doc = soacCommon.getBaseContentsDOM();
		}
		
		if (doc.getElementsByClassName) {
			return doc.getElementsByClassName(cName);
		}
		var result = [];
		var allElements;
		if (doc.all) {
			allElements = doc.all;
		} else {
			allElements = doc.getElementsByTagName("*");
		}
		for (var i = 0, len = allElements.length; i < len; i++) {
			if (allElements[i].className && allElements[i].className.indexOf(cName) >= 0) {
				result.push(allElements[i]);
			}
		}
		return result;
	}
	return [];
}
SOAC_Common.prototype.callAjax = function(opts) {
	if (!opts.methodType) return;
	if (!opts.address) return;
	if (!opts.params) opts.params = "";
	if (!opts.resultType) opts.resultType = null;
	if (!opts.onSuccessFunc) opts.onSuccessFunc = function(){};
	if (!opts.onErrorFunc) opts.onErrorFunc = function(){};
	if (!opts.sparams) opts.sparams = "";
	opts.methodType = opts.methodType.toUpperCase();
	
	if (opts.methodType !== "POST" && opts.methodType !== "GET") {
		return;
	}
	
	var httpStatus;
	
	if (typeof opts.params !== "string") {
		return;
	}
	if (opts.params && opts.methodType === "GET") {
		if (/\?/.test(opts.address)) {
			opts.address += "&" + opts.params;
		} else {
			opts.address += "?" + opts.params;
		}
	}
	
	var XMLHttpRequestObj;
	if (window.XMLHttpRequest && (window.location.protocol !== "file:" || !window.ActiveXObject)) {
		XMLHttpRequestObj = new window.XMLHttpRequest();
	} else {
		XMLHttpRequestObj = new window.ActiveXObject("Microsoft.XMLHTTP");
	}
	if (!XMLHttpRequestObj) {
		return;
	}
	
	if (opts.userName) {
		XMLHttpRequestObj.open(opts.methodType, opts.address, true, opts.userName, opts.password);
	} else {
		XMLHttpRequestObj.open(opts.methodType, opts.address, true);
	}
	
	if (opts.contentType) {
		XMLHttpRequestObj.setRequestHeader("Content-Type", opts.contentType);
	} else {
		XMLHttpRequestObj.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	}
	
	if (opts.resultType) {
		if (opts.resultType === "xml") {
			XMLHttpRequestObj.setRequestHeader("Accept", "application/xml, text/xml, */*");
		}
		else if (opts.resultType === "html") {
			XMLHttpRequestObj.setRequestHeader("Accept", "text/html, */*");
		}
		else if (opts.resultType === "text") {
			XMLHttpRequestObj.setRequestHeader("Accept", "text/plain, */*");
		}
		else if (opts.resultType === "json") {
			XMLHttpRequestObj.setRequestHeader("Accept", "application/json, text/javascript, */*");
		} else {
			if (opts.onErrorFunc) {
				opts.onErrorFunc.call(opts, "error", "resultType is Wrong");
			}
		}
	} else {
		XMLHttpRequestObj.setRequestHeader("Accept", "*/*");
	}
	
	var requestFinished = false;
	var onreadystatechange = XMLHttpRequestObj.onreadystatechange = function(nowState) {
		if (!XMLHttpRequestObj || XMLHttpRequestObj.readyState === 0 || nowState === "abort") {
			requestFinished = true;
			if (XMLHttpRequestObj) {
				XMLHttpRequestObj.onreadystatechange = function(){};
			}
		} else if (!requestFinished && XMLHttpRequestObj && (XMLHttpRequestObj.readyState === 4 || nowState === "timeout")) {
			requestFinished = true;
			XMLHttpRequestObj.onreadystatechange = function(){};
			
			var isHttpRequest = function(xhrObj) {
				try {
					return !xhrObj.status && location.protocol === "file:" ||
					(xhrObj.status >= 200 && xhrObj.status < 300) ||
					xhrObj.status === 304 || xhrObj.status === 1223;
				} catch(e) {}
				
				return false;
			}
			
			if (nowState === "timeout") {
				httpStatus = "timeout";
			} else {
				if (!isHttpRequest(XMLHttpRequestObj)) {
					httpStatus = "error";
				} else {
					httpStatus = "success";
				}
			}
			
			var errorMessage;
			if (httpStatus === "success") {
				try {
					var contentType = XMLHttpRequestObj.getResponseHeader("content-type") || "";
					var isXml = opts.resultType === "xml" || !opts.resultType && contentType.indexOf("xml") >= 0;
					if (isXml) {
						resultData = XMLHttpRequestObj.responseXML;
					} else {
						resultData = XMLHttpRequestObj.responseText;
					}
					if (isXml && resultData.documentElement.nodeName === "parseerror") {
						throw "parse error";
					}
					if (typeof resultData === "string") {
						if (opts.resultType === "json" || !opts.resultType && contentType.indexOf("json") >= 0) {
							if (!resultData) {
								resultData = "";
							}
							
							if (String.prototype.trim) {
								resultData = String.prototype.trim.call(resultData);
							} else {
								resultData = resultData.toString().replace(/^\s+/,"").replace(/\s+$/,"");
							}
							
							var forValid = resultData.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@");
							forValid = forValid.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]");
							forValid = forValid.replace(/(?:^|:|,)(?:\s*\[)+/g, "");
							var isValid = /^[\],:{}\s]*$/.test(forValid);
							
							if (isValid) {
								if (window.JSON && window.JSON.parse) {
									resultData = window.JSON.parse(resultData);
								} else {
									if (resultData == "") {
										throw "Empty JSON";
									}
									resultData = (new Function("return " + resultData))();
								}
							} else {
								throw "Invalid JSON: " + resultData;
							}
						}
					}
				} catch(error) {
					httpStatus = "parse error";
					errorMessage = error;
				}
			}
			
			if (httpStatus === "success") {
				opts.onSuccessFunc.call(opts, resultData);
			} else {
				if (opts.onErrorFunc) {
					opts.onErrorFunc.call(opts, httpStatus, errorMessage);
				}
			}
			
			if (nowState === "timeout") {
				returnObj.abort();
			}
			XMLHttpRequestObj = null;
		}
	};	
	
	var returnObj = {
		xhr: XMLHttpRequestObj,
		abort: function() {
			if (XMLHttpRequestObj) {
				XMLHttpRequestObj.abort();
			}
			onreadystatechange("abort");
		}
	};
	
	
	if (opts.timeOutLimit) {
		if (opts.timeOutLimit > 0) {
			setTimeout(function() {
				if (XMLHttpRequestObj && !requestFinished) {
					onreadystatechange("timeout");
				}
			}, opts.timeOutLimit);
		}
	}
	
	try {
		if (opts.methodType === "POST") {
			XMLHttpRequestObj.send(opts.params);
		}
		else if (opts.methodType === "GET") {
			XMLHttpRequestObj.send(null);
		} else {
			throw "methodType is wrong";
		}
	} catch(e) {
		if (opts.onErrorFunc) {
			opts.onErrorFunc.call(opts, "error", e);
		}
	}
	
	return returnObj;
}

function requestFile(xmlPath,tagName)
{
	if (xmlPath && tagName){
      var param = tagName;
      soacCommon.callAjax({
              methodType: "GET",
              address: xmlPath,
              resultType: "xml",
              sparams: param,
              onSuccessFunc: setSideInfo,
              onErrorFunc: errSetSideInfo
      });
    }
}
function setSideInfo(xml)
{
	var tagName = this.sparams;
	if (tagName){
		var targetDom = document.getElementById(tagName);
		if (targetDom){
			var resultStr = targetDom.innerHTML;
			var rowData = xml.getElementsByTagName("row");
			var disp = xml.getElementsByTagName("disp");
			var url = xml.getElementsByTagName("url");
			var tgt = xml.getElementsByTagName("target");
			if (rowData && disp && url && rowData.length > 0 && rowData.length == disp.length && rowData.length == url.length){
				for (var i = 0 ;i < rowData.length ;i++)
				{
				  var target = "_blank";
				  if (tgt[i] && tgt[i].childNodes[0] && tgt[i].childNodes[0].nodeValue == "self"){
				      target = "_self";
				  }
				  resultStr += "<li><a href=\"" + url[i].childNodes[0].nodeValue + "\" target=\"" + target + "\">";
				  resultStr += disp[i].childNodes[0].nodeValue + "</a></li>";
				}
				targetDom.innerHTML = resultStr;
			}
		}
	}
}
function errSetSideInfo(xml)
{
}
function requestFileTopInfo(xmlPath,tagName)
{
	if (xmlPath && tagName){
      var param = tagName;
      soacCommon.callAjax({
              methodType: "GET",
              address: xmlPath,
              resultType: "xml",
              sparams: param,
              onSuccessFunc: setTopInfo,
              onErrorFunc: errSetTopInfo
      });
    }
}
function setTopInfo(xml)
{
	var tagName = this.sparams;
	if (tagName){
		var targetDom = document.getElementById(tagName);
		if (targetDom){
			var resultStr = targetDom.innerHTML;
			var rowData = xml.getElementsByTagName("row");
			var disp = xml.getElementsByTagName("disp");
			var desc = xml.getElementsByTagName("desc");
			var type = xml.getElementsByTagName("type");
			var url = xml.getElementsByTagName("url");
			var tgt = xml.getElementsByTagName("target");
			if (rowData && disp && url && rowData.length > 0 && rowData.length == disp.length && rowData.length == url.length){
				for (var i = 0 ;i < rowData.length ;i++)
				{
				  var target = "_blank";
				  if (tgt[i] && tgt[i].childNodes[0] && tgt[i].childNodes[0].nodeValue == "self"){
				      target = "_self";
				  }
				  resultStr += "<dl class=\"row_infoBox\"><dt><a href=\"" + url[i].childNodes[0].nodeValue + "\" target=\"" + target + "\">";
				  resultStr += disp[i].childNodes[0].nodeValue + "</a><span class=\"hl_label\">"+type[i].childNodes[0].nodeValue+"</span></dt>";
				  resultStr += "<dd>" + desc[i].childNodes[0].nodeValue + "</dd></dl>";
				}
				targetDom.innerHTML = resultStr;
			}
		}
	}
}
function errSetTopInfo(xml)
{
}
var soacCommon = new SOAC_Common();
soacCommon.searchWord = "検索ワードを入力";
